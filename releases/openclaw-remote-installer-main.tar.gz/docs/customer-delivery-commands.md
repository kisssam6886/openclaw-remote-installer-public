# 客户交付版安装命令模板

## 先说清楚

是的，下面这些命令都是**在客户机上运行**的。

也就是：

- 你用 AnyDesk 连到客户的 Mac / Windows
- 在**客户机终端**里执行这些命令
- 命令会从公开分发仓库拉取安装器，然后在**客户机本地**完成 OpenClaw 安装

不是在你自己的电脑本机执行后远程推送过去。

---

## 使用原则

- `AnyDesk ID` 可以写进命令，方便登记客户档案
- `客户名` 可以写进命令，方便后续维护
- `NVIDIA key` 需要替换成真实值
- `AnyDesk 密码` **不要写进命令**
- `AnyDesk 密码` 只用于你远程登录，不属于安装器配置项

---

## 最常用模板

### 模板 1：macOS 快速安装

适合你已经连上客户 Mac，只想尽快装好 OpenClaw。

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_PROVIDER_API_KEY='替换成你的NVIDIA key' bash
```

### 模板 2：macOS 客户交付版

适合正式交付，顺手把客户信息写进 registry。

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_CUSTOMER_NAME='客户名称' OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID='客户AnyDeskID' OPENCLAW_PROVIDER_API_KEY='替换成你的NVIDIA key' bash
```

### 模板 3：Windows 快速安装

在客户 Windows 的 PowerShell 运行：

```powershell
$env:OPENCLAW_PROVIDER_API_KEY='替换成你的NVIDIA key'
irm https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1 | iex
```

### 模板 4：Windows 客户交付版

```powershell
$env:OPENCLAW_CUSTOMER_NAME='客户名称'
$env:OPENCLAW_REMOTE_TOOL='anydesk'
$env:OPENCLAW_REMOTE_ID='客户AnyDeskID'
$env:OPENCLAW_PROVIDER_API_KEY='替换成你的NVIDIA key'
irm https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1 | iex
```

---

## 我建议你以后固定用这两个版本

### Mac 标准版

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_CUSTOMER_NAME='客户名称' OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID='客户AnyDeskID' OPENCLAW_PROVIDER_API_KEY='你的NVIDIA key' bash
```

### Windows 标准版

```powershell
$env:OPENCLAW_CUSTOMER_NAME='客户名称'
$env:OPENCLAW_REMOTE_TOOL='anydesk'
$env:OPENCLAW_REMOTE_ID='客户AnyDeskID'
$env:OPENCLAW_PROVIDER_API_KEY='你的NVIDIA key'
irm https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1 | iex
```

---

## 字段说明

### `OPENCLAW_CUSTOMER_NAME`

建议填：

- 客户公司名
- 或客户昵称
- 或你内部客户编号

例子：

- `Sam Demo 01`
- `深圳王总-MacBook`
- `CUST-2026-001`

### `OPENCLAW_REMOTE_TOOL`

当前固定建议：

- `anydesk`

### `OPENCLAW_REMOTE_ID`

填客户机当前使用的 AnyDesk ID。

这样安装完成后，客户档案里会保留：

- 机器信息
- OpenClaw 版本
- skills
- provider
- model
- AnyDesk ID
- 安装时间

后面排错和二次维护会轻松很多。

---

## 不要写进命令的东西

以下内容不要写进命令：

- AnyDesk 密码
- 客户业务系统密码
- 邮箱密码
- QQ / 微信登录密码
- 长期管理员密码

这些东西不应该进入：

- shell history
- 安装日志
- 诊断包
- GitHub registry

---

## 如果以后换国内镜像域名

如果以后你把公共分发入口换成你自己的域名，例如：

- `https://install.yourdomain.com/bootstrap/remote-install.sh`
- `https://install.yourdomain.com/bootstrap/remote-install.ps1`

那你只需要把上面模板里的下载地址替换掉，其余参数不变。

---

## 当前推荐你实际复制的版本

### 客户 Mac

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_CUSTOMER_NAME='客户名称' OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID='客户AnyDeskID' OPENCLAW_PROVIDER_API_KEY='你的NVIDIA key' bash
```

### 客户 Windows

```powershell
$env:OPENCLAW_CUSTOMER_NAME='客户名称'
$env:OPENCLAW_REMOTE_TOOL='anydesk'
$env:OPENCLAW_REMOTE_ID='客户AnyDeskID'
$env:OPENCLAW_PROVIDER_API_KEY='你的NVIDIA key'
irm https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1 | iex
```
