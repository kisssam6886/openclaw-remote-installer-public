# QQ 接入说明（安装后可一键配置）

当前主安装链已经允许先完成 OpenClaw 安装，再单独接入 QQ Bot。

## 当前建议流程

1. 在客户机运行远程安装命令，完成 OpenClaw 主安装
2. 安装完成后，安装器会默认尝试：
   - 自动执行 `openclaw dashboard`
   - 自动打开 `https://q.qq.com/qqbot/openclaw/login.html`
3. 在 QQ 页面完成登录 / 创建机器人 / 获取 `AppID` 和 `AppSecret`
4. 在客户机执行 QQ 一键接入脚本

## QQ 一键接入脚本

### macOS / Linux

推荐：

```bash
OPENCLAW_QQBOT_APP_ID='你的 AppID' OPENCLAW_QQBOT_APP_SECRET='你的 AppSecret' bash install/enable-qqbot.sh
```

也可以直接运行后按提示输入：

```bash
bash install/enable-qqbot.sh
```

### Windows PowerShell

推荐：

```powershell
$env:OPENCLAW_QQBOT_APP_ID='你的 AppID'
$env:OPENCLAW_QQBOT_APP_SECRET='你的 AppSecret'
powershell -ExecutionPolicy Bypass -File .\install\enable-qqbot.ps1
```

## QQ 一键脚本内部会做什么

1. 安装 QQ Bot 插件
   - `openclaw plugins install @tencent-connect/openclaw-qqbot@latest`
2. 绑定当前 QQ 机器人
   - `openclaw channels add --channel qqbot --token "AppID:AppSecret"`
3. 重启本地 OpenClaw Gateway
   - `openclaw gateway restart`
4. 写入 QQ 已连接标记
5. 做一次基础状态检查

## 注意事项

- `AppSecret` 不要写进公开仓库
- 如果 `AppSecret` 已经出现在截图、聊天记录或公开页面，建议立刻重置
- QQ 接入失败不应该阻塞 OpenClaw 主安装成功

## 当前定位

- OpenClaw 主安装：主链硬条件
- QQ Bot 接入：安装后第二阶段能力
- 如果 QQ 暂时还没接，不影响你先完成 AnyDesk 远程交付
