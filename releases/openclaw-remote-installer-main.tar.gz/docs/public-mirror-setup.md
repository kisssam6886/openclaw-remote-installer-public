# 公开镜像分发方案

## 结论

不用把当前源码仓库公开。

你真正需要公开的是“分发出口”，不是“源码仓库”。
推荐结构是：

- 私有源码仓库：`openclaw-remote-installer`
- 公共分发仓库：例如 `openclaw-remote-installer-public`

这样客户机匿名执行 `curl` / `irm` 时，只访问公共分发仓库；你的源码和内部实现仍然留在私有仓库。

## 为什么现在 raw 是 404

因为你当前仓库是私有仓库，未认证访问私有资源时 GitHub 会返回 `404`。
所以这条匿名安装链：

- `raw.githubusercontent.com/...`
- `curl ... | bash`
- `irm ... | iex`

只有在“公开仓库”或“公开镜像出口”下才可用。

## 推荐做法

### 方案 A：双仓库

- 源码仓库保持私有：`kisssam6886/openclaw-remote-installer`
- 新建一个公开仓库：`kisssam6886/openclaw-remote-installer-public`
- 每次源码仓库更新后，由 GitHub Actions 自动把这些内容同步到公开仓库：
  - `bootstrap/remote-install.sh`
  - `bootstrap/remote-install.ps1`
  - `bootstrap/source-remote-install.sh`
  - `bootstrap/source-remote-install.ps1`
  - `manifest.json`
  - `releases/openclaw-remote-installer-main.tar.gz`
  - `releases/openclaw-remote-installer-main.zip`

### 方案 B：后续再接自定义域名

等你以后要做国内镜像时，可以把公开仓库里的同一批文件同步到：

- 阿里云 OSS
- 腾讯云 COS
- R2 + CDN
- 你自己的下载域名

现有脚本已经支持 `OPENCLAW_INSTALL_ARCHIVE_URL`，所以以后迁移出口不需要重写主链。

## 我已经补好的文件

- 自动打包公开分发内容：`scripts/build-public-dist.sh`
- 自动发布到公开分发仓库的工作流：`.github/workflows/publish-public-mirror.yml`
- 本说明：`docs/public-mirror-setup.md`

## 你要做的一次性设置

### 1. 新建一个公开仓库

例如：

- `kisssam6886/openclaw-remote-installer-public`

必须是 `Public`。

### 2. 在私有源码仓库设置 GitHub Actions 变量

在源码仓库的 `Settings -> Secrets and variables -> Actions -> Variables` 新增：

- `OPENCLAW_PUBLIC_DIST_REPO` = `kisssam6886/openclaw-remote-installer-public`
- `OPENCLAW_PUBLIC_DIST_BRANCH` = `main`

### 3. 在私有源码仓库设置 GitHub Actions Secret

新增：

- `OPENCLAW_PUBLIC_DIST_PAT`

这个 PAT 需要至少能推送到公开分发仓库。

## 发布方式

### 自动发布

- 你 push 到私有源码仓库 `main`
- workflow `Publish Public Mirror` 自动运行
- 自动更新公共分发仓库

### 本地手动预览

在源码仓库根目录运行：

```bash
bash scripts/build-public-dist.sh
```

默认输出到：

- `.dist-public/`

## 发布后客户实际使用的链接

以后客户机不要再用私有源码仓库 raw 地址。
要改用公开分发仓库，例如：

### macOS

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_PROVIDER_API_KEY='你的 NVIDIA key' bash
```

### Windows

```powershell
$env:OPENCLAW_PROVIDER_API_KEY='你的 NVIDIA key'
irm https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1 | iex
```

## 关键回答

### 还需要把现在这个源码仓库公开吗？

不需要。

只要你采用这个“双仓库镜像分发”方案：

- 源码仓库可以继续私有
- 公开的是分发仓库
- 客户机只访问公开分发仓库

### 那什么是必须公开的？

必须公开的是：

- 公开分发仓库
- 或你自己的公开镜像域名 / 对象存储出口

总之，客户匿名下载所访问的那个入口，必须是公开可读的。
