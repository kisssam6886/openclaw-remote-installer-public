# OpenClaw Remote Installer - 开工报告（MVP v0.1）

## 目标
为客户电脑远程部署一套可维护的 OpenClaw 安装体系：
- 先支持 macOS + Windows
- 暂不接入 Codex / Claude Code，先只装 OpenClaw
- 采用“主控端 Jarvis + 客户端 Worker Agent”架构
- 支持自动体检、自动安装、自动校验、基础自动修复
- 支持客户安装档案沉淀，方便后续排错和二次维护

---

## 当前关键决策

### 1. GitHub 是否要用
要用，但不能只依赖 GitHub 直连。

GitHub 在这套系统中的作用：
- 存放 bootstrap / doctor / install / repair 脚本
- 存放默认模板与客户登记结构
- 作为版本控制与更新中心
- 作为错误知识库与修复规则来源

但国内直连 GitHub 不稳定，所以必须设计“多源分发”。

### 2. 国内分发策略
不能假设客户能访问 GitHub，也不能要求客户装代理。

MVP 建议：
- 主源：GitHub repo
- 镜像源：国内可访问对象存储/CDN（如 Cloudflare R2 + 自定义域名、阿里云 OSS、腾讯云 COS）
- 发布物：把 bootstrap、zip 包、版本清单同步到镜像域名
- bootstrap 默认先访问你的镜像域名，再回退 GitHub raw/release

建议结构：
- https://install.yourdomain.com/bootstrap/macos.sh
- https://install.yourdomain.com/bootstrap/windows.ps1
- https://install.yourdomain.com/releases/openclaw-remote-installer-vX.Y.Z.zip
- https://install.yourdomain.com/manifest.json

结论：
- GitHub 继续作为源代码和版本中心
- 客户安装入口默认走你自己的镜像域名

### 3. Worker Agent 模型与 key
MVP 统一使用：
- 模型：NVIDIA Kimi K2.5（nvidia/moonshotai/kimi-k2.5）
- key：使用你的统一服务 key（后续可再拆成客户独立 key 模式）

注意：
- 客户端不应明文长期暴露主 key
- MVP 可先由你托管 key，但建议尽快改为服务端下发短期 token / 中转网关

### 4. 客户端需要装哪些 skills
MVP 先只装必要项，不要贪多。

#### 客户电脑 Worker Agent 必装 skills（建议）
1. agent-browser
   - 用于浏览器交互、网页登录和页面级排错
2. task-status
   - 用于安装与维护任务的状态汇报
3. himalaya
   - 用于邮件与基础信息流处理
4. self-improvement
   - 用于后续维护和自我修正

#### 客户电脑 Worker Agent 暂不默认预装
- supabase（除非客户明确要做 SaaS/数据库）
- linear（除非客户有项目管理需求）
- figma（除非客户有设计稿分析需求）
- notion / obsidian / apple-notes（强环境相关）
- qqbot-media / qqbot-cron（按中国渠道方案再定）

#### 主控端 Jarvis 建议保留的核心能力
- github
- browser / agent-browser
- himalaya
- self-improvement
- task-status
- 远程安装专用 skill（待建）

### 5. 国内对接什么 channel 更合适
MVP 不建议一开始上微信个人号生态，风控和维护复杂度太高。

优先级建议：
1. 飞书（Lark）
   - 企业化、API 和 bot 生态相对清晰
   - 适合售后、通知、工单、状态同步
   - 需要验证 OpenClaw 当前是否已有成熟 channel 接入；若没有，可先走 webhook/机器人桥接
2. QQ Bot
   - 国内覆盖面高，适合 ToC/轻客服
   - 你当前 OpenClaw 已有 qqbot 技能，说明这条线更贴近现有环境
3. Telegram
   - 海外/技术用户可以继续用
4. 微信
   - 可做，但不建议作为 MVP 首发主通道
   - 成本高、风控高、稳定性与账号策略复杂

MVP 建议结论：
- 中国客户主通道优先：QQ Bot 或 飞书
- 如果是企业/团队：优先飞书
- 如果是个人用户/轻交付：优先 QQ Bot

### 6. GitHub 能否记录每个客户资料
可以，建议把 GitHub 当“客户技术档案库”。

建议方式：
- 一个私有 repo：openclaw-client-registry
- 每个客户一个目录或一个 YAML 文件
- 安装成功后由主控端自动写入/更新

建议字段：
- customer_id
- name
- contact
- anydesk_id / rustdesk_id
- os / arch
- machine_name
- installed_at
- last_maintained_at
- openclaw_version
- enabled_skills
- channel_type
- worker_model
- install_source（mirror / github）
- notes
- known_issues
- maintenance_log[]

文件示例：
registry/customers/<customer_id>.yaml

这个非常值得做，因为后面二次维护、批量升级、排错都会轻松很多。

---

## 你可能还没想到，但需要提前设计的点

### A. 安全边界
- 远程代装涉及客户电脑控制权，必须设计：
  - 哪些命令允许自动执行
  - 哪些操作必须人工确认
  - key 怎么存
  - 日志是否包含敏感信息

### B. 回滚能力
- 安装失败时，要能：
  - 回滚配置
  - 标记失败原因
  - 留下可重试状态

### C. 版本兼容矩阵
- macOS Intel / Apple Silicon
- Windows 10 / 11
- 中国网络环境差异
- Node 版本要求

### D. 客户分层模板
建议预设三种安装档：
1. 基础版：只装 OpenClaw
2. 运营版：OpenClaw + 浏览器能力 + QQ/飞书通知
3. 开发版：OpenClaw + 前端/部署相关 skill

### E. 更新策略
- 是否自动升级 OpenClaw
- 是否自动升级技能
- 是否只由你主控端批准后升级

MVP 建议：默认不自动大版本升级，只做手动批准升级。

---

## MVP 第一阶段建议范围

### 支持系统
- macOS
- Windows（优先支持管理员 PowerShell，WSL 可作为第二阶段）

### 安装内容
- OpenClaw
- 必要依赖（git / node）
- 基础 config
- 少量必要 skills
- 1 个国内可用消息通道（QQ Bot 或飞书二选一）

### 基础流程
1. bootstrap
2. doctor
3. install
4. repair
5. verify
6. register client

---

## 下一步工作项
1. 建 GitHub repo / 目录结构
2. 定镜像分发方案（install 域名 + manifest + zip/release）
3. 定 client registry 数据结构
4. 定 Worker Agent 必装 skills 清单
5. 写 bootstrap + doctor 第一版
6. 写安装完成后的自动登记逻辑

---

## 当前建议结论（短版）
- 要用 GitHub，但客户入口不能只靠 GitHub，必须加国内镜像域名
- Worker Agent 先统一 NVIDIA Kimi K2.5 + 你的 key，但后续要做更安全的 token/网关方案
- 客户端必装 skills 先控制在少量：agent-browser、himalaya、self-improvement、task-status
- 国内消息通道 MVP 优先 QQ Bot / 飞书，不建议一开始就主打微信
- GitHub 完全可以做客户安装档案库，强烈建议从第一天就记录
