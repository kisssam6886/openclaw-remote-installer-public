# 安装后检查清单

- `openclaw` 命令可用
- OpenClaw gateway 可启动
- browser capability 可用
- 必需 skills 已安装完成
- 运行时 worker 配置文件已生成
- 本地客户档案已写入 `registry/instances/` 和运行时 registry
- `~/.openclaw/installer-runtime/install-summary.json` 已生成
- `~/.openclaw/installer-runtime/installed.ok` 已生成
- 基础测试任务可以跑通
- 若曾失败，`~/.openclaw/installer-runtime/diagnostics/` 下有诊断包可回看
