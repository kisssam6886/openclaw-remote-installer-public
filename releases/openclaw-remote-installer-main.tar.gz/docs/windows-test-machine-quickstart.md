# Windows 测试机快速开始

## 目标

在正式交付客户前，先在 Windows 测试机验证完整安装链路。

## 步骤

1. 克隆仓库
2. 复制 `.env.example` 为 `.env.local`
3. 填入 `OPENCLAW_PROVIDER_API_KEY`
4. 确认 PowerShell 版本为 5.1+（或 PowerShell 7）
5. 用管理员权限打开 PowerShell
6. 运行 `powershell -ExecutionPolicy Bypass -File .\bootstrap\windows.ps1`
7. 确认 OpenClaw、gateway、browser 均可用
8. 运行 `powershell -ExecutionPolicy Bypass -File .\install\check-delivery.ps1`
9. 查看 `%USERPROFILE%\.openclaw\installer-runtime\install-summary.json`
10. 如失败，查看 `%USERPROFILE%\.openclaw\installer-runtime\diagnostics\`

## 说明

当前默认模型和 provider 已经是 NVIDIA Kimi K2.5，只要补真实 key 即可。


## 版本要求

- 当前 Windows 主链要求 **Windows PowerShell 5.1+** 或 **PowerShell 7**
- 如果终端里连 `irm` 都不存在，通常说明版本太旧，不适合直接跑当前安装器
- 先执行：`$PSVersionTable.PSVersion`
