# 安装流程（当前主线）

1. 远程连入客户电脑
2. 运行 bootstrap 或一键远程安装脚本
3. 检查 Git / Node / 基础环境
4. 进入 `install-runner`
5. 执行 OpenClaw 安装
6. 安装必需 skills
7. 把 worker runtime 配置写入 OpenClaw 正式配置
8. 运行 worker first-run 自检
9. 生成客户 registry 实例
10. 写入安装摘要与交付标记
11. 如果失败，自动收集 diagnostics
12. 按规则执行 repair 并重试
13. 最终通过 `check-delivery` 验收

## Windows 说明

- 需要管理员 PowerShell
- Windows 主链与 macOS 对齐：`bootstrap -> install-runner -> install-openclaw -> skills -> handoff -> first-run -> check-delivery`
