# 交接记录｜2026-03-13

## 当前结论

- macOS 主线已跑通
- 已安装过的 Mac 重跑安装命令通过
- `openclaw` 命令在终端可直接使用
- 安装完成后已接入自动执行 `openclaw dashboard`
- 安装完成后已接入自动打开 QQ 登录页
- 已新增 QQ 一键接入脚本：
  - `install/enable-qqbot.sh`
  - `install/enable-qqbot.ps1`

## 最新远程安装命令

```bash
curl -fsSL 'https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh' | OPENCLAW_CUSTOMER_NAME='sam-imac' OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID='1005755892' OPENCLAW_PROVIDER_API_KEY='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' bash
```

> 说明：下一会话优先以 `main` 最新镜像为准；若担心缓存，可在 URL 后手动追加 `?v=<最新commit>`。

## 明天优先做

1. 干净 Mac 首装测试
2. Windows 主线实机测试
3. QQ 一键接入实测
4. 再决定是否补飞书独立脚本

## 已知注意点

- 用户要求以后文档保持中文
- 回复风格要简洁直接，先讲结果
- 不再讨论 Pages / 域名，重点放安装主链和交付
- QQ 机器人页面人工操作保留，客户机终端命令自动化

## 这次新增文件

- `install/post-install-actions.sh`
- `install/post-install-actions.ps1`
- `install/enable-qqbot.sh`
- `install/enable-qqbot.ps1`
- `install/mark-qq-connected.ps1`

## 这次改动目标

- 安装成功后自动开本地 dashboard
- 安装成功后自动打开 QQ 登录页
- 把 QQ 页面给出的 3 条命令封成一键脚本
