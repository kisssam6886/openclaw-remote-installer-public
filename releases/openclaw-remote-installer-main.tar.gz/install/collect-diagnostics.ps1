param(
    [int]$Attempt = 1,
    [int]$ExitCode = 1,
    [string]$Stage = 'install-openclaw',
    [string]$LogFile = ''
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$reportKey = ((Get-TimestampUtc) + '-' + (Get-MachineId) + '-attempt-' + $Attempt).ToLower().Replace(':', '-').Replace('/', '-').Replace(' ', '-')
$reportDir = Join-Path $env:OPENCLAW_DIAGNOSTICS_DIR $reportKey
$latestPointer = Join-Path $env:OPENCLAW_RUNTIME_DIR 'diagnostics-latest.txt'
$syncStatus = 'skipped'

function Invoke-CaptureCommand {
    param(
        [string]$FileName,
        [scriptblock]$ScriptBlock,
        [string]$CommandLine
    )

    $targetFile = Join-Path (Join-Path $reportDir 'commands') $FileName
    $lines = [System.Collections.Generic.List[string]]::new()
    $lines.Add('$ ' + $CommandLine)

    try {
        $output = & $ScriptBlock 2>&1
        foreach ($line in $output) {
            $lines.Add([string]$line)
        }
    }
    catch {
        foreach ($line in ($_ | Out-String).TrimEnd().Split("`n")) {
            if ($line) {
                $lines.Add($line.TrimEnd())
            }
        }
        $lines.Add('(command failed)')
    }

    Set-Content -Path $targetFile -Value $lines -Encoding utf8
}

function Copy-IfExists {
    param(
        [string]$SourcePath,
        [string]$TargetPath
    )

    if (Test-Path $SourcePath) {
        Ensure-Directory -Path (Split-Path -Parent $TargetPath)
        Copy-Item -Path $SourcePath -Destination $TargetPath -Force
    }
}

Ensure-Directory -Path $reportDir
Ensure-Directory -Path (Join-Path $reportDir 'commands')
Ensure-Directory -Path (Join-Path $reportDir 'runtime')
Ensure-Directory -Path (Join-Path $reportDir 'repo')

Invoke-CaptureCommand -FileName 'systeminfo.txt' -CommandLine 'systeminfo' -ScriptBlock { systeminfo }
Invoke-CaptureCommand -FileName 'node-version.txt' -CommandLine 'node --version' -ScriptBlock { node --version }
Invoke-CaptureCommand -FileName 'npm-version.txt' -CommandLine 'npm --version' -ScriptBlock { npm --version }
Invoke-CaptureCommand -FileName 'git-version.txt' -CommandLine 'git --version' -ScriptBlock { git --version }
Invoke-CaptureCommand -FileName 'openclaw-version.txt' -CommandLine 'openclaw --version' -ScriptBlock { openclaw --version }
Invoke-CaptureCommand -FileName 'openclaw-config-file.txt' -CommandLine 'openclaw config file' -ScriptBlock { openclaw config file }
Invoke-CaptureCommand -FileName 'openclaw-config-validate.txt' -CommandLine 'openclaw config validate' -ScriptBlock { openclaw config validate }
Invoke-CaptureCommand -FileName 'openclaw-doctor.txt' -CommandLine 'openclaw doctor --non-interactive' -ScriptBlock { openclaw doctor --non-interactive }
Invoke-CaptureCommand -FileName 'openclaw-status.txt' -CommandLine 'openclaw status' -ScriptBlock { openclaw status }
Invoke-CaptureCommand -FileName 'openclaw-gateway-status.txt' -CommandLine 'openclaw gateway status' -ScriptBlock { openclaw gateway status }
Invoke-CaptureCommand -FileName 'openclaw-browser-status.txt' -CommandLine 'openclaw browser status' -ScriptBlock { openclaw browser status }

if ($LogFile -and (Test-Path $LogFile)) {
    Copy-Item -Path $LogFile -Destination (Join-Path $reportDir 'runtime/install-attempt.log') -Force
}

$configFile = Get-OpenClawConfigFile
Write-RedactedCopy -SourcePath $configFile -TargetPath (Join-Path $reportDir 'runtime/openclaw.config.redacted.json')

if ($env:OPENCLAW_INSTALLER_ENV_FILE -and (Test-Path $env:OPENCLAW_INSTALLER_ENV_FILE)) {
    Write-RedactedCopy -SourcePath $env:OPENCLAW_INSTALLER_ENV_FILE -TargetPath (Join-Path $reportDir 'runtime/installer-env.redacted')
}

Copy-IfExists -SourcePath (Join-Path $env:OPENCLAW_RUNTIME_DIR 'applied-worker-config.json') -TargetPath (Join-Path $reportDir 'runtime/applied-worker-config.json')
Copy-IfExists -SourcePath $env:OPENCLAW_INSTALL_SUMMARY_FILE -TargetPath (Join-Path $reportDir 'runtime/install-summary.json')
Copy-IfExists -SourcePath (Join-Path $env:OPENCLAW_RUNTIME_DIR 'registry-sync-status.json') -TargetPath (Join-Path $reportDir 'runtime/registry-sync-status.json')
Copy-IfExists -SourcePath (Join-Path $env:OPENCLAW_RUNTIME_DIR 'diagnostics-sync-status.json') -TargetPath (Join-Path $reportDir 'runtime/diagnostics-sync-status.json')
Copy-IfExists -SourcePath (Join-Path $env:OPENCLAW_REGISTRY_DIR ((Get-MachineId) + '.yaml')) -TargetPath (Join-Path $reportDir 'runtime/registry-instance.yaml')
Copy-IfExists -SourcePath (Join-Path $script:RepoRoot ('registry/instances/' + (Get-MachineId) + '.yaml')) -TargetPath (Join-Path $reportDir 'repo/registry-instance.yaml')

if ($env:OPENCLAW_DIAGNOSTICS_GIT_URL) {
    try {
        & (Join-Path $PSScriptRoot 'sync-diagnostics.ps1') -ReportDir $reportDir | Out-Null
        $syncStatus = 'synced'
    }
    catch {
        $syncStatus = 'failed'
    }
}

Write-JsonFile -Path (Join-Path $reportDir 'metadata.json') -Object @{
    generated_at             = Get-TimestampUtc
    machine_id               = Get-MachineId
    machine_name             = Get-MachineName
    os                       = Get-OSLabel
    arch                     = Get-ArchLabel
    openclaw_version         = Get-OpenClawVersion
    install_source           = $(if ($env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE } else { 'repo-local' })
    attempt                  = $Attempt
    exit_code                = $ExitCode
    stage                    = $Stage
    log_file                 = $LogFile
    config_file              = $configFile
    provider_id              = $env:OPENCLAW_PROVIDER_ID
    provider_model_id        = $env:OPENCLAW_PROVIDER_MODEL_ID
    diagnostics_sync_status  = $syncStatus
}

Ensure-Directory -Path (Split-Path -Parent $latestPointer)
Set-Content -Path $latestPointer -Value $reportDir -Encoding utf8
Write-Output $reportDir
