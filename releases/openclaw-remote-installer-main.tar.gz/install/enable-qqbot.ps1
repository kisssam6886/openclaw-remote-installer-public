param(
    [string]$AppId = $env:OPENCLAW_QQBOT_APP_ID,
    [string]$AppSecret = $env:OPENCLAW_QQBOT_APP_SECRET,
    [string]$AccountId = $env:OPENCLAW_QQ_ACCOUNT_ID
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

if (-not $env:OPENCLAW_QQBOT_PLUGIN_SPEC) { $env:OPENCLAW_QQBOT_PLUGIN_SPEC = '@tencent-connect/openclaw-qqbot@latest' }

function Read-SecretText {
    param([string]$Prompt)

    $secure = Read-Host $Prompt -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    }
    finally {
        if ($bstr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }
    }
}

if (-not $AppId -and $Host.Name -ne 'ServerRemoteHost') {
    $AppId = Read-Host '请输入 QQ Bot AppID'
}

if (-not $AppSecret -and $Host.Name -ne 'ServerRemoteHost') {
    $AppSecret = Read-SecretText '请输入 QQ Bot AppSecret'
}

if (-not $AppId) { throw '缺少 OPENCLAW_QQBOT_APP_ID' }
if (-not $AppSecret) { throw '缺少 OPENCLAW_QQBOT_APP_SECRET' }
if (-not $AccountId) { $AccountId = $AppId }

$token = "$AppId`:$AppSecret"

Write-Host '[QQBot] installing plugin...'
& openclaw plugins install $env:OPENCLAW_QQBOT_PLUGIN_SPEC | Out-Null

Write-Host '[QQBot] binding current QQ bot...'
& openclaw channels add --channel qqbot --token $token | Out-Null

Write-Host '[QQBot] restarting OpenClaw gateway...'
try { & openclaw gateway restart | Out-Null } catch { & openclaw gateway start | Out-Null }

Write-Host '[QQBot] writing connected marker...'
$qqStatusFile = $env:OPENCLAW_QQ_STATUS_FILE
Ensure-Directory -Path (Split-Path -Parent $qqStatusFile)
@{
    connected    = $true
    account_id   = $AccountId
    note         = 'QQ Bot token configured and gateway restarted.'
    verified_at  = Get-TimestampUtc
} | ConvertTo-Json -Depth 5 | Set-Content -Path $qqStatusFile -Encoding utf8

Write-Host '[QQBot] verifying channel status...'
try { & openclaw channels status | Out-Null } catch { try { & openclaw status | Out-Null } catch { & openclaw gateway status | Out-Null } }

Write-Host '[QQBot] complete.'
Write-Host '[QQBot] next step: openclaw channels status --deep'
