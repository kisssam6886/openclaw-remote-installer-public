#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

OPENCLAW_QQBOT_PLUGIN_SPEC="${OPENCLAW_QQBOT_PLUGIN_SPEC:-@tencent-connect/openclaw-qqbot@latest}"
APP_ID="${OPENCLAW_QQBOT_APP_ID:-${1:-}}"
APP_SECRET="${OPENCLAW_QQBOT_APP_SECRET:-${2:-}}"
ACCOUNT_ID="${OPENCLAW_QQ_ACCOUNT_ID:-}"

if [ -z "$APP_ID" ] && [ -t 0 ]; then
  printf '请输入 QQ Bot AppID: '
  read -r APP_ID
fi

if [ -z "$APP_SECRET" ] && [ -t 0 ]; then
  printf '请输入 QQ Bot AppSecret: '
  read -rs APP_SECRET
  printf '\n'
fi

[ -n "$APP_ID" ] || { echo '缺少 OPENCLAW_QQBOT_APP_ID'; exit 1; }
[ -n "$APP_SECRET" ] || { echo '缺少 OPENCLAW_QQBOT_APP_SECRET'; exit 1; }

if [ -z "$ACCOUNT_ID" ]; then
  ACCOUNT_ID="$APP_ID"
fi

TOKEN="$APP_ID:$APP_SECRET"

echo '[QQBot] installing plugin...'
openclaw plugins install "$OPENCLAW_QQBOT_PLUGIN_SPEC"

echo '[QQBot] binding current QQ bot...'
openclaw channels add --channel qqbot --token "$TOKEN"

echo '[QQBot] restarting OpenClaw gateway...'
openclaw gateway restart >/dev/null 2>&1 || openclaw gateway start >/dev/null 2>&1

echo '[QQBot] writing connected marker...'
OPENCLAW_QQ_NOTE="QQ Bot token configured and gateway restarted." bash "$REPO_ROOT/install/mark-qq-connected.sh" "$ACCOUNT_ID" >/dev/null 2>&1 || true

echo '[QQBot] verifying channel status...'
openclaw channels status >/dev/null 2>&1 || openclaw status >/dev/null 2>&1 || openclaw gateway status >/dev/null 2>&1 || {
  echo '[QQBot] status check failed'
  exit 1
}

echo '[QQBot] complete.'
echo '[QQBot] next step: openclaw channels status --deep'
