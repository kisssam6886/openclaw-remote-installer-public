param(
    [string]$InstanceFile
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

if (-not $InstanceFile) {
    $InstanceFile = Join-Path $env:OPENCLAW_REGISTRY_DIR ("{0}.yaml" -f (Get-MachineId))
}

if (-not (Test-Path $InstanceFile)) {
    throw "Registry instance file missing: $InstanceFile"
}

if (-not $env:OPENCLAW_REGISTRY_GIT_URL) {
    Write-Host 'Registry sync skipped: OPENCLAW_REGISTRY_GIT_URL not set.'
    exit 0
}

Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR

if (-not (Test-Path (Join-Path $env:OPENCLAW_REGISTRY_GIT_DIR '.git'))) {
    if (Test-Path $env:OPENCLAW_REGISTRY_GIT_DIR) {
        Remove-Item -Path $env:OPENCLAW_REGISTRY_GIT_DIR -Recurse -Force
    }

    & git clone $env:OPENCLAW_REGISTRY_GIT_URL $env:OPENCLAW_REGISTRY_GIT_DIR | Out-Null
}

Push-Location $env:OPENCLAW_REGISTRY_GIT_DIR
try {
    & git remote set-url origin $env:OPENCLAW_REGISTRY_GIT_URL | Out-Null
    & git fetch origin | Out-Null

    $hasRemoteBranch = $false
    try {
        & git rev-parse --verify "origin/$($env:OPENCLAW_REGISTRY_GIT_BRANCH)" | Out-Null
        $hasRemoteBranch = $true
    }
    catch { }

    if ($hasRemoteBranch) {
        & git checkout -B $env:OPENCLAW_REGISTRY_GIT_BRANCH "origin/$($env:OPENCLAW_REGISTRY_GIT_BRANCH)" | Out-Null
    }
    else {
        & git checkout -B $env:OPENCLAW_REGISTRY_GIT_BRANCH | Out-Null
    }

    try { & git pull --ff-only origin $env:OPENCLAW_REGISTRY_GIT_BRANCH | Out-Null } catch { }

    $targetDir = Join-Path $env:OPENCLAW_REGISTRY_GIT_DIR $env:OPENCLAW_REGISTRY_GIT_SUBDIR
    Ensure-Directory -Path $targetDir
    $targetFile = Join-Path $targetDir (Split-Path -Leaf $InstanceFile)
    Copy-Item -Path $InstanceFile -Destination $targetFile -Force

    & git config user.name $env:OPENCLAW_REGISTRY_GIT_AUTHOR_NAME | Out-Null
    & git config user.email $env:OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL | Out-Null
    & git add $targetFile | Out-Null

    & git diff --cached --quiet
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Registry sync unchanged: $targetFile"
        exit 0
    }

    & git commit -m "Sync registry $(Split-Path -Leaf $InstanceFile)" | Out-Null
    & git push -u origin $env:OPENCLAW_REGISTRY_GIT_BRANCH | Out-Null

    Write-Host "Registry sync complete: $targetFile"
}
finally {
    Pop-Location
}
