#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

SKILL_INSTALL_MAX_ATTEMPTS="${SKILL_INSTALL_MAX_ATTEMPTS:-3}"
SKILL_INSTALL_RETRY_DELAY="${SKILL_INSTALL_RETRY_DELAY:-3}"

echo "[Installer] installing required skills..."

if ! command -v npm >/dev/null 2>&1; then
  echo "npm not found. Please install Node.js first."
  exit 1
fi

ensure_dir "$OPENCLAW_SHARED_SKILLS_DIR"

if ! command -v clawhub >/dev/null 2>&1; then
  npm install -g clawhub >/dev/null 2>&1 || true
fi

install_skill_once() {
  local skill="$1"

  if command -v clawhub >/dev/null 2>&1; then
    clawhub install "$skill" --workdir "$OPENCLAW_STATE_DIR" --force --no-input >/dev/null 2>&1 || true
  else
    npx -y clawhub install "$skill" --workdir "$OPENCLAW_STATE_DIR" --force --no-input >/dev/null 2>&1 || true
  fi

  if ! skill_installed "$skill"; then
    npx -y skills add "$skill" >/dev/null 2>&1 || true
  fi
}

for skill in "${REQUIRED_SKILLS[@]}"; do
  if skill_installed "$skill"; then
    echo "Skill already available: $skill -> $(skill_path "$skill")"
    continue
  fi

  echo "Installing skill: $skill"

  attempt=1
  while [ "$attempt" -le "$SKILL_INSTALL_MAX_ATTEMPTS" ]; do
    install_skill_once "$skill"

    if skill_installed "$skill"; then
      break
    fi

    if [ "$attempt" -lt "$SKILL_INSTALL_MAX_ATTEMPTS" ]; then
      echo "Skill not ready yet: $skill (attempt $attempt/$SKILL_INSTALL_MAX_ATTEMPTS), retrying in ${SKILL_INSTALL_RETRY_DELAY}s..."
      sleep "$SKILL_INSTALL_RETRY_DELAY"
    fi

    attempt=$((attempt + 1))
  done

  if ! skill_installed "$skill"; then
    echo "Missing skill after install retries: $skill"
    exit 1
  fi

  echo "Skill ready: $skill -> $(skill_path "$skill")"
done

echo "[Installer] required skills install step complete."
