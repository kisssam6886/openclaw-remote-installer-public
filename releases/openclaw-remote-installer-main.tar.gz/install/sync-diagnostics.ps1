param(
    [Parameter(Mandatory = $true)][string]$ReportDir
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$syncStatusFile = Join-Path $env:OPENCLAW_RUNTIME_DIR 'diagnostics-sync-status.json'

function Write-SyncStatus {
    param(
        [string]$Status,
        [string]$Note,
        [string]$TargetDir
    )

    Write-JsonFile -Path $syncStatusFile -Object @{
        status     = $Status
        checked_at = Get-TimestampUtc
        git_url    = $env:OPENCLAW_DIAGNOSTICS_GIT_URL
        branch     = $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH
        report_dir = $ReportDir
        target_dir = $TargetDir
        note       = $Note
    }
}

if (-not (Test-Path $ReportDir)) {
    Write-SyncStatus -Status 'failed' -Note 'Diagnostics report directory missing.' -TargetDir ''
    throw "Diagnostics report directory missing: $ReportDir"
}

if (-not $env:OPENCLAW_DIAGNOSTICS_GIT_URL) {
    Write-SyncStatus -Status 'skipped' -Note 'OPENCLAW_DIAGNOSTICS_GIT_URL not set.' -TargetDir ''
    Write-Host 'Diagnostics sync skipped: OPENCLAW_DIAGNOSTICS_GIT_URL not set.'
    exit 0
}

Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR

if (-not (Test-Path (Join-Path $env:OPENCLAW_DIAGNOSTICS_GIT_DIR '.git'))) {
    if (Test-Path $env:OPENCLAW_DIAGNOSTICS_GIT_DIR) {
        Remove-Item -Path $env:OPENCLAW_DIAGNOSTICS_GIT_DIR -Recurse -Force
    }

    & git clone $env:OPENCLAW_DIAGNOSTICS_GIT_URL $env:OPENCLAW_DIAGNOSTICS_GIT_DIR | Out-Null
}

Push-Location $env:OPENCLAW_DIAGNOSTICS_GIT_DIR
try {
    & git remote set-url origin $env:OPENCLAW_DIAGNOSTICS_GIT_URL | Out-Null
    & git fetch origin | Out-Null

    $hasRemoteBranch = $false
    try {
        & git rev-parse --verify "origin/$($env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH)" | Out-Null
        $hasRemoteBranch = $true
    }
    catch { }

    if ($hasRemoteBranch) {
        & git checkout -B $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH "origin/$($env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH)" | Out-Null
    }
    else {
        & git checkout -B $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH | Out-Null
    }

    try { & git pull --ff-only origin $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH | Out-Null } catch { }

    $targetRoot = Join-Path $env:OPENCLAW_DIAGNOSTICS_GIT_DIR $env:OPENCLAW_DIAGNOSTICS_GIT_SUBDIR
    Ensure-Directory -Path $targetRoot
    $targetDir = Join-Path $targetRoot (Split-Path -Leaf $ReportDir)

    if (Test-Path $targetDir) {
        Remove-Item -Path $targetDir -Recurse -Force
    }

    Copy-Item -Path $ReportDir -Destination $targetDir -Recurse -Force

    & git config user.name $env:OPENCLAW_REGISTRY_GIT_AUTHOR_NAME | Out-Null
    & git config user.email $env:OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL | Out-Null
    & git add $targetDir | Out-Null

    & git diff --cached --quiet
    if ($LASTEXITCODE -eq 0) {
        Write-SyncStatus -Status 'unchanged' -Note 'No diagnostics changes to push.' -TargetDir $targetDir
        Write-Host "Diagnostics sync unchanged: $targetDir"
        exit 0
    }

    & git commit -m "Sync diagnostics $(Split-Path -Leaf $ReportDir)" | Out-Null
    & git push -u origin $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH | Out-Null

    Write-SyncStatus -Status 'synced' -Note 'Diagnostics report pushed successfully.' -TargetDir $targetDir
    Write-Host "Diagnostics sync complete: $targetDir"
}
finally {
    Pop-Location
}
