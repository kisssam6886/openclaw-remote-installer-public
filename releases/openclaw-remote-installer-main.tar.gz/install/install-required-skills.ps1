$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$skillInstallMaxAttempts = if ($env:SKILL_INSTALL_MAX_ATTEMPTS) { [int]$env:SKILL_INSTALL_MAX_ATTEMPTS } else { 3 }
$skillInstallRetryDelay = if ($env:SKILL_INSTALL_RETRY_DELAY) { [int]$env:SKILL_INSTALL_RETRY_DELAY } else { 3 }

function Resolve-CommandPath {
    param([string[]]$Candidates)

    foreach ($candidate in $Candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }

        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($command -and $command.Source) {
            return $command.Source
        }

        if (Test-Path $candidate) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

function Ensure-PathEntry {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return }

    $parts = @()
    if ($env:Path) { $parts = $env:Path -split ';' }
    if ($parts | Where-Object { $_ -ieq $Path }) { return }

    $env:Path = if ($env:Path) { "$Path;$env:Path" } else { $Path }
}

function Get-NpmCommandPath {
    $candidates = @(
        $env:OPENCLAW_NPM_CMD,
        $(if ($env:OPENCLAW_NODE_HOME) { Join-Path $env:OPENCLAW_NODE_HOME 'npm.cmd' }),
        $(if ($env:OPENCLAW_NODE_HOME) { Join-Path $env:OPENCLAW_NODE_HOME 'npm.exe' }),
        $(if ($env:ProgramFiles) { Join-Path $env:ProgramFiles 'nodejs\npm.cmd' }),
        $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} 'nodejs\npm.cmd' }),
        $(if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Programs\nodejs\npm.cmd' }),
        'npm.cmd',
        'npm.exe',
        'npm'
    )

    return (Resolve-CommandPath -Candidates $candidates)
}

function Get-NpxCommandPath {
    $candidates = @(
        $env:OPENCLAW_NPX_CMD,
        $(if ($env:OPENCLAW_NODE_HOME) { Join-Path $env:OPENCLAW_NODE_HOME 'npx.cmd' }),
        $(if ($env:OPENCLAW_NODE_HOME) { Join-Path $env:OPENCLAW_NODE_HOME 'npx.exe' }),
        $(if ($env:ProgramFiles) { Join-Path $env:ProgramFiles 'nodejs\npx.cmd' }),
        $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} 'nodejs\npx.cmd' }),
        $(if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Programs\nodejs\npx.cmd' }),
        'npx.cmd',
        'npx.exe',
        'npx'
    )

    return (Resolve-CommandPath -Candidates $candidates)
}

function Get-ClawhubCommandPath {
    $prefix = $env:OPENCLAW_NPM_GLOBAL_PREFIX
    $candidates = @(
        $(if ($prefix) { Join-Path $prefix 'clawhub.cmd' }),
        $(if ($prefix) { Join-Path $prefix 'clawhub.exe' }),
        'clawhub.cmd',
        'clawhub.exe',
        'clawhub'
    )

    return (Resolve-CommandPath -Candidates $candidates)
}

function Invoke-NpmWithInstallerEnv {
    param([string[]]$Arguments)

    $npmCommand = Get-NpmCommandPath
    if (-not $npmCommand) {
        throw 'npm not found. Please install Node.js first.'
    }

    Ensure-Directory -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX
    Ensure-PathEntry -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX

    $previous = @{
        NPM_CONFIG_PREFIX = $env:NPM_CONFIG_PREFIX
        NPM_CONFIG_SCRIPT_SHELL = $env:NPM_CONFIG_SCRIPT_SHELL
        NPM_CONFIG_LOGLEVEL = $env:NPM_CONFIG_LOGLEVEL
        NPM_CONFIG_UPDATE_NOTIFIER = $env:NPM_CONFIG_UPDATE_NOTIFIER
        NPM_CONFIG_FUND = $env:NPM_CONFIG_FUND
        NPM_CONFIG_AUDIT = $env:NPM_CONFIG_AUDIT
        NODE_LLAMA_CPP_SKIP_DOWNLOAD = $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD
    }

    $env:NPM_CONFIG_PREFIX = $env:OPENCLAW_NPM_GLOBAL_PREFIX
    $env:NPM_CONFIG_SCRIPT_SHELL = 'cmd.exe'
    $env:NPM_CONFIG_LOGLEVEL = 'error'
    $env:NPM_CONFIG_UPDATE_NOTIFIER = 'false'
    $env:NPM_CONFIG_FUND = 'false'
    $env:NPM_CONFIG_AUDIT = 'false'
    $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD = '1'

    try {
        $output = & $npmCommand @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $env:NPM_CONFIG_PREFIX = $previous.NPM_CONFIG_PREFIX
        $env:NPM_CONFIG_SCRIPT_SHELL = $previous.NPM_CONFIG_SCRIPT_SHELL
        $env:NPM_CONFIG_LOGLEVEL = $previous.NPM_CONFIG_LOGLEVEL
        $env:NPM_CONFIG_UPDATE_NOTIFIER = $previous.NPM_CONFIG_UPDATE_NOTIFIER
        $env:NPM_CONFIG_FUND = $previous.NPM_CONFIG_FUND
        $env:NPM_CONFIG_AUDIT = $previous.NPM_CONFIG_AUDIT
        $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD = $previous.NODE_LLAMA_CPP_SKIP_DOWNLOAD
    }

    foreach ($line in $output) {
        Write-Host $line
    }

    return $exitCode
}

function Invoke-NpxWithInstallerEnv {
    param([string[]]$Arguments)

    $npxCommand = Get-NpxCommandPath
    if (-not $npxCommand) {
        return 1
    }

    Ensure-Directory -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX
    Ensure-PathEntry -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX

    $previous = @{
        NPM_CONFIG_PREFIX = $env:NPM_CONFIG_PREFIX
        NPM_CONFIG_SCRIPT_SHELL = $env:NPM_CONFIG_SCRIPT_SHELL
        NODE_LLAMA_CPP_SKIP_DOWNLOAD = $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD
    }

    $env:NPM_CONFIG_PREFIX = $env:OPENCLAW_NPM_GLOBAL_PREFIX
    $env:NPM_CONFIG_SCRIPT_SHELL = 'cmd.exe'
    $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD = '1'

    try {
        $output = & $npxCommand @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $env:NPM_CONFIG_PREFIX = $previous.NPM_CONFIG_PREFIX
        $env:NPM_CONFIG_SCRIPT_SHELL = $previous.NPM_CONFIG_SCRIPT_SHELL
        $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD = $previous.NODE_LLAMA_CPP_SKIP_DOWNLOAD
    }

    foreach ($line in $output) {
        Write-Host $line
    }

    return $exitCode
}

Write-Host '[Installer] installing required skills...'
Ensure-Directory -Path $env:OPENCLAW_SHARED_SKILLS_DIR
Ensure-Directory -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX
Ensure-PathEntry -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX

if (-not (Get-ClawhubCommandPath)) {
    $exitCode = Invoke-NpmWithInstallerEnv -Arguments @('install', '-g', 'clawhub')
    if ($exitCode -ne 0 -and $env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL) {
        Write-Host "[Installer] clawhub default registry failed; retrying with mirror: $($env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL)"
        $exitCode = Invoke-NpmWithInstallerEnv -Arguments @('install', '-g', 'clawhub', '--registry', $env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL)
    }
}

function Install-SkillOnce {
    param([string]$Skill)

    $clawhubCommand = Get-ClawhubCommandPath
    if ($clawhubCommand) {
        try { & $clawhubCommand install $Skill --workdir $env:OPENCLAW_STATE_DIR --force --no-input | Out-Null } catch { }
    }
    else {
        try { Invoke-NpxWithInstallerEnv -Arguments @('-y', 'clawhub', 'install', $Skill, '--workdir', $env:OPENCLAW_STATE_DIR, '--force', '--no-input') | Out-Null } catch { }
    }

    if (-not (Test-SkillInstalled -Skill $Skill)) {
        try { Invoke-NpxWithInstallerEnv -Arguments @('-y', 'skills', 'add', $Skill) | Out-Null } catch { }
    }
}

foreach ($skill in $script:RequiredSkills) {
    if (Test-SkillInstalled -Skill $skill) {
        Write-Host "Skill already available: $skill -> $(Get-SkillPath -Skill $skill)"
        continue
    }

    Write-Host "Installing skill: $skill"

    for ($attempt = 1; $attempt -le $skillInstallMaxAttempts; $attempt++) {
        Install-SkillOnce -Skill $skill

        if (Test-SkillInstalled -Skill $skill) {
            break
        }

        if ($attempt -lt $skillInstallMaxAttempts) {
            Write-Host "Skill not ready yet: $skill (attempt $attempt/$skillInstallMaxAttempts), retrying in ${skillInstallRetryDelay}s..."
            Start-Sleep -Seconds $skillInstallRetryDelay
        }
    }

    if (-not (Test-SkillInstalled -Skill $skill)) {
        throw "Missing skill after install retries: $skill"
    }

    Write-Host "Skill ready: $skill -> $(Get-SkillPath -Skill $skill)"
}

Write-Host '[Installer] required skills install step complete.'
