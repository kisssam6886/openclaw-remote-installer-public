$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$targetDir = $env:OPENCLAW_RUNTIME_DIR
Ensure-Directory -Path $targetDir
Ensure-Directory -Path (Join-Path $targetDir 'backups')
Ensure-Directory -Path (Join-Path $targetDir 'workspace')

Write-Host '[Installer] applying worker template...'

$sourceTemplate = Join-Path $script:RepoRoot 'templates/worker-agent-template.yaml'
$targetTemplate = Join-Path $targetDir 'worker-agent.yaml'
$configFile = Get-OpenClawConfigFile
$configDir = Split-Path -Parent $configFile
$backupFile = $null
$gatewayInstalled = $false
$providerConfigured = $false
$workConfig = Join-Path $targetDir ('openclaw.config.work.{0}.json' -f $PID)
$stagedConfig = Join-Path $configDir ('.openclaw.installer-staged.{0}.json' -f $PID)

function Invoke-OpenClawWithConfig {
    param(
        [string]$ConfigPath,
        [Parameter(ValueFromRemainingArguments = $true)]
        [object[]]$Arguments
    )

    $hadPreviousConfigPath = Test-Path Env:OPENCLAW_CONFIG_PATH
    $previousConfigPath = $env:OPENCLAW_CONFIG_PATH
    $env:OPENCLAW_CONFIG_PATH = $ConfigPath
    try {
        & openclaw @Arguments
    }
    finally {
        if ($hadPreviousConfigPath) {
            $env:OPENCLAW_CONFIG_PATH = $previousConfigPath
        }
        else {
            Remove-Item Env:OPENCLAW_CONFIG_PATH -ErrorAction SilentlyContinue
        }
    }
}

try {
    if (-not (Test-Path $sourceTemplate)) { throw 'worker template missing' }
    Copy-Item -Path $sourceTemplate -Destination $targetTemplate -Force
    Ensure-Directory -Path $configDir

    if (-not (Get-Command openclaw -ErrorAction SilentlyContinue)) {
        throw 'OpenClaw CLI missing. Cannot apply runtime config.'
    }

    if ((Test-Path $configFile) -and ((Get-Item $configFile).Length -gt 0)) {
        $backupFile = Join-Path $targetDir ("backups/openclaw.json.{0}.bak" -f (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ'))
        Copy-Item -Path $configFile -Destination $backupFile -Force
        Copy-Item -Path $configFile -Destination $workConfig -Force
    }
    else {
        Set-Content -Path $workConfig -Value '{}' -Encoding utf8
    }

    Invoke-OpenClawWithConfig -ConfigPath $workConfig config set gateway.mode local | Out-Null
    Invoke-OpenClawWithConfig -ConfigPath $workConfig config set --strict-json browser ((@{ enabled = $true; evaluateEnabled = $true; defaultProfile = 'openclaw' } | ConvertTo-Json -Compress)) | Out-Null
    Invoke-OpenClawWithConfig -ConfigPath $workConfig config set --strict-json skills.install ((@{ preferBrew = $true; nodeManager = 'npm' } | ConvertTo-Json -Compress)) | Out-Null
    Invoke-OpenClawWithConfig -ConfigPath $workConfig config set agents.defaults.userTimezone ((Get-TimeZone).Id | ConvertTo-JsonLiteral) | Out-Null
    Invoke-OpenClawWithConfig -ConfigPath $workConfig config set agents.defaults.workspace ($env:OPENCLAW_RUNTIME_DIR + '/workspace' | ConvertTo-JsonLiteral) | Out-Null

    if ($env:OPENCLAW_REQUIRE_PROVIDER_CONFIG -eq 'true') {
        if (-not $env:OPENCLAW_PROVIDER_ID -or -not $env:OPENCLAW_PROVIDER_BASE_URL -or -not $env:OPENCLAW_PROVIDER_API_KEY -or -not $env:OPENCLAW_PROVIDER_MODEL_ID) {
            throw 'Custom provider config missing. Copy .env.example to .env.local and fill OPENCLAW_PROVIDER_BASE_URL / OPENCLAW_PROVIDER_API_KEY first.'
        }

        Invoke-OpenClawWithConfig -ConfigPath $workConfig config set ("env.{0}" -f $env:OPENCLAW_PROVIDER_API_KEY_NAME) ($env:OPENCLAW_PROVIDER_API_KEY | ConvertTo-JsonLiteral) | Out-Null

        $providerConfig = @{
            baseUrl = $env:OPENCLAW_PROVIDER_BASE_URL
            api     = $env:OPENCLAW_PROVIDER_API_COMPAT
            apiKey  = "`${$($env:OPENCLAW_PROVIDER_API_KEY_NAME)}"
            models  = @(@{ id = $env:OPENCLAW_PROVIDER_MODEL_ID; name = $env:OPENCLAW_PROVIDER_DISPLAY_NAME })
        }

        Invoke-OpenClawWithConfig -ConfigPath $workConfig config set --strict-json ("models.providers.{0}" -f $env:OPENCLAW_PROVIDER_ID) ($providerConfig | ConvertTo-Json -Compress -Depth 10) | Out-Null
        Invoke-OpenClawWithConfig -ConfigPath $workConfig config set models.mode merge | Out-Null
        $providerConfigured = $true
    }

    Invoke-OpenClawWithConfig -ConfigPath $workConfig config set --strict-json agents.defaults.model ((@{ primary = $env:OPENCLAW_WORKER_MODEL } | ConvertTo-Json -Compress)) | Out-Null
    Invoke-OpenClawWithConfig -ConfigPath $workConfig config validate | Out-Null

    Copy-Item -Path $workConfig -Destination $stagedConfig -Force
    Move-Item -Path $stagedConfig -Destination $configFile -Force

    try {
        Invoke-OpenClawWithConfig -ConfigPath $configFile config validate | Out-Null
    }
    catch {
        if ($backupFile) {
            Copy-Item -Path $backupFile -Destination $configFile -Force
        }
        elseif (Test-Path $configFile) {
            Remove-Item -Path $configFile -Force
        }

        throw 'Committed OpenClaw config failed validation and was rolled back.'
    }

    if ($env:OPENCLAW_INSTALL_DAEMON -eq 'true') {
        Invoke-OpenClawWithConfig -ConfigPath $configFile gateway install | Out-Null
        Invoke-OpenClawWithConfig -ConfigPath $configFile gateway start | Out-Null
        $gatewayInstalled = $true
    }

    Write-JsonFile -Path (Join-Path $targetDir 'applied-worker-config.json') -Object @{
        applied_at                = Get-TimestampUtc
        config_file               = $configFile
        template_file             = $targetTemplate
        worker_model              = $env:OPENCLAW_WORKER_MODEL
        worker_model_source       = 'installer'
        provider_id               = $env:OPENCLAW_PROVIDER_ID
        provider_model_id         = $env:OPENCLAW_PROVIDER_MODEL_ID
        provider_base_url         = $env:OPENCLAW_PROVIDER_BASE_URL
        provider_configured       = $providerConfigured
        browser_enabled           = $true
        gateway_service_installed = $gatewayInstalled
        skills_dir                = $env:OPENCLAW_SHARED_SKILLS_DIR
        installer_env_file        = $env:OPENCLAW_INSTALLER_ENV_FILE
        backup_file               = $backupFile
    }

    Write-Host "Worker template written to: $targetTemplate"
    Write-Host "OpenClaw config applied to: $configFile"
}
finally {
    Remove-Item -Path $workConfig -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $stagedConfig -Force -ErrorAction SilentlyContinue
}
