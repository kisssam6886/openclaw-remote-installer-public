$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

Write-Host '[Installer] handoff to worker starting...'

$workerTemplate = Join-Path $script:RepoRoot 'templates/worker-agent-template.yaml'
$workerFirstRun = Join-Path $PSScriptRoot 'worker-first-run.ps1'

Write-Host '[1/4] Verify worker template exists'
if (-not (Test-Path $workerTemplate)) { throw 'worker template missing' }

Write-Host '[2/4] Verify first-run script exists'
if (-not (Test-Path $workerFirstRun)) { throw 'worker first-run script missing' }

Write-Host '[3/4] Write worker runtime config to customer machine'
& (Join-Path $PSScriptRoot 'apply-worker-template.ps1')

Write-Host '[4/4] Run worker first-run checks'
& $workerFirstRun

Write-Host '[Installer] handoff to worker complete.'
