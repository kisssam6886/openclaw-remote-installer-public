#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

REPORT_DIR="${1:-}"
SYNC_STATUS_FILE="$OPENCLAW_RUNTIME_DIR/diagnostics-sync-status.json"

write_sync_status() {
  local status="$1"
  local note="${2:-}"
  local target_dir="${3:-}"
  ensure_dir "$(dirname "$SYNC_STATUS_FILE")"

  cat >"$SYNC_STATUS_FILE" <<EOF2
{
  "status": $(json_string "$status"),
  "checked_at": $(json_string "$(timestamp_utc)"),
  "git_url": $(json_string "$OPENCLAW_DIAGNOSTICS_GIT_URL"),
  "branch": $(json_string "$OPENCLAW_DIAGNOSTICS_GIT_BRANCH"),
  "report_dir": $(json_string "$REPORT_DIR"),
  "target_dir": $(json_string "$target_dir"),
  "note": $(json_string "$note")
}
EOF2
}

if [ -z "$REPORT_DIR" ] || [ ! -d "$REPORT_DIR" ]; then
  write_sync_status "failed" "Diagnostics report directory missing." ""
  echo "Diagnostics report directory missing: $REPORT_DIR"
  exit 1
fi

if [ -z "$OPENCLAW_DIAGNOSTICS_GIT_URL" ]; then
  write_sync_status "skipped" "OPENCLAW_DIAGNOSTICS_GIT_URL not set." ""
  echo "Diagnostics sync skipped: OPENCLAW_DIAGNOSTICS_GIT_URL not set."
  exit 0
fi

ensure_dir "$OPENCLAW_RUNTIME_DIR"

if [ ! -d "$OPENCLAW_DIAGNOSTICS_GIT_DIR/.git" ]; then
  rm -rf "$OPENCLAW_DIAGNOSTICS_GIT_DIR"
  git clone "$OPENCLAW_DIAGNOSTICS_GIT_URL" "$OPENCLAW_DIAGNOSTICS_GIT_DIR" >/dev/null 2>&1 || {
    write_sync_status "failed" "git clone failed." ""
    echo "Diagnostics sync failed: git clone failed."
    exit 1
  }
fi

ORIGIN_URL="$(git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" remote get-url origin 2>/dev/null || true)"
if [ "$ORIGIN_URL" != "$OPENCLAW_DIAGNOSTICS_GIT_URL" ]; then
  git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" remote set-url origin "$OPENCLAW_DIAGNOSTICS_GIT_URL"
fi

git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" fetch origin >/dev/null 2>&1 || true

if git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" show-ref --verify --quiet "refs/heads/$OPENCLAW_DIAGNOSTICS_GIT_BRANCH"; then
  git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" checkout "$OPENCLAW_DIAGNOSTICS_GIT_BRANCH" >/dev/null 2>&1
else
  if git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" show-ref --verify --quiet "refs/remotes/origin/$OPENCLAW_DIAGNOSTICS_GIT_BRANCH"; then
    git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" checkout -B "$OPENCLAW_DIAGNOSTICS_GIT_BRANCH" "origin/$OPENCLAW_DIAGNOSTICS_GIT_BRANCH" >/dev/null 2>&1
  else
    git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" checkout -B "$OPENCLAW_DIAGNOSTICS_GIT_BRANCH" >/dev/null 2>&1
  fi
fi

git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" pull --ff-only origin "$OPENCLAW_DIAGNOSTICS_GIT_BRANCH" >/dev/null 2>&1 || true

TARGET_DIR="$OPENCLAW_DIAGNOSTICS_GIT_DIR/$OPENCLAW_DIAGNOSTICS_GIT_SUBDIR/$(basename "$REPORT_DIR")"
rm -rf "$TARGET_DIR"
ensure_dir "$(dirname "$TARGET_DIR")"
cp -R "$REPORT_DIR" "$TARGET_DIR"

git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" config user.name "$OPENCLAW_REGISTRY_GIT_AUTHOR_NAME"
git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" config user.email "$OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL"
git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" add "$TARGET_DIR"

if git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" diff --cached --quiet; then
  write_sync_status "unchanged" "No diagnostics changes to push." "$TARGET_DIR"
  echo "Diagnostics sync unchanged: $TARGET_DIR"
  exit 0
fi

git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" commit -m "Sync diagnostics $(basename "$REPORT_DIR")" >/dev/null 2>&1 || {
  write_sync_status "failed" "git commit failed." "$TARGET_DIR"
  echo "Diagnostics sync failed: git commit failed."
  exit 1
}

git -C "$OPENCLAW_DIAGNOSTICS_GIT_DIR" push -u origin "$OPENCLAW_DIAGNOSTICS_GIT_BRANCH" >/dev/null 2>&1 || {
  write_sync_status "failed" "git push failed." "$TARGET_DIR"
  echo "Diagnostics sync failed: git push failed."
  exit 1
}

write_sync_status "synced" "Diagnostics report pushed successfully." "$TARGET_DIR"
echo "Diagnostics sync complete: $TARGET_DIR"
