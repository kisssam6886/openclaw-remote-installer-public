#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

OPENCLAW_POST_INSTALL_OPEN_DASHBOARD="${OPENCLAW_POST_INSTALL_OPEN_DASHBOARD:-true}"
OPENCLAW_POST_INSTALL_OPEN_QQBOT="${OPENCLAW_POST_INSTALL_OPEN_QQBOT:-true}"
OPENCLAW_QQBOT_LOGIN_URL="${OPENCLAW_QQBOT_LOGIN_URL:-https://q.qq.com/qqbot/openclaw/login.html}"

bool_true() {
  case "$(printf '%s' "$1" | tr '[:upper:]' '[:lower:]')" in
    1|true|yes|y|on)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

open_url_best_effort() {
  local url="$1"

  case "$(uname -s)" in
    Darwin)
      command -v open >/dev/null 2>&1 || return 1
      open "$url" >/dev/null 2>&1
      ;;
    Linux)
      command -v xdg-open >/dev/null 2>&1 || return 1
      xdg-open "$url" >/dev/null 2>&1
      ;;
    *)
      return 1
      ;;
  esac
}

echo "[Post Install] starting..."

if bool_true "$OPENCLAW_POST_INSTALL_OPEN_DASHBOARD"; then
  echo "[Post Install] Opening OpenClaw dashboard..."
  if command -v openclaw >/dev/null 2>&1; then
    openclaw dashboard >/dev/null 2>&1 || echo "[Post Install] OpenClaw dashboard open failed; continuing."
  else
    echo "[Post Install] OpenClaw command missing; skip dashboard open."
  fi
else
  echo "[Post Install] Dashboard auto-open disabled."
fi

if bool_true "$OPENCLAW_POST_INSTALL_OPEN_QQBOT"; then
  echo "[Post Install] Opening QQ Bot login page..."
  open_url_best_effort "$OPENCLAW_QQBOT_LOGIN_URL" || echo "[Post Install] QQ Bot login page open failed; continuing."
else
  echo "[Post Install] QQ Bot login page auto-open disabled."
fi

echo "[Post Install] complete."
