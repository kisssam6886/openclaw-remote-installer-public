#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

LOG_DIR="$OPENCLAW_RUNTIME_DIR/logs"
MAX_ATTEMPTS="$OPENCLAW_INSTALL_MAX_ATTEMPTS"
LAST_DIAGNOSTICS_DIR=""

case "$MAX_ATTEMPTS" in
  ''|*[!0-9]*) MAX_ATTEMPTS=3 ;;
esac

ensure_dir "$OPENCLAW_RUNTIME_DIR"
ensure_dir "$LOG_DIR"

attempt=1
while [ "$attempt" -le "$MAX_ATTEMPTS" ]; do
  LOG_FILE="$LOG_DIR/install-attempt-$attempt.log"
  export OPENCLAW_INSTALL_ATTEMPT="$attempt"

  echo "[Runner] Install attempt $attempt/$MAX_ATTEMPTS"

  set +e
  bash "$REPO_ROOT/install/install-openclaw.sh" 2>&1 | tee "$LOG_FILE"
  EXIT_CODE=${PIPESTATUS[0]}
  set -e

  if [ "$EXIT_CODE" -eq 0 ]; then
    echo "[Runner] Install attempt $attempt succeeded."
    exit 0
  fi

  export OPENCLAW_LAST_INSTALL_LOG_FILE="$LOG_FILE"
  export OPENCLAW_INSTALL_EXIT_CODE="$EXIT_CODE"
  export OPENCLAW_INSTALL_FAILURE_STAGE="install-openclaw"

  echo "[Runner] Install attempt $attempt failed with exit code $EXIT_CODE"
  LAST_DIAGNOSTICS_DIR="$(bash "$REPO_ROOT/install/collect-diagnostics.sh" "$attempt" "$EXIT_CODE" "install-openclaw" "$LOG_FILE" | tail -n 1 || true)"
  if [ -n "$LAST_DIAGNOSTICS_DIR" ]; then
    echo "[Runner] Diagnostics collected: $LAST_DIAGNOSTICS_DIR"
  fi

  if [ "$attempt" -ge "$MAX_ATTEMPTS" ]; then
    break
  fi

  if [ "$OPENCLAW_REPAIR_AUTO" != "true" ]; then
    break
  fi

  echo "[Runner] Running auto-repair before retry..."
  bash "$REPO_ROOT/install/repair-openclaw.sh" || true
  attempt=$((attempt + 1))
done

echo "[Runner] OpenClaw install failed after $attempt attempt(s)."
if [ -n "$LAST_DIAGNOSTICS_DIR" ]; then
  echo "[Runner] Latest diagnostics: $LAST_DIAGNOSTICS_DIR"
fi
exit 1
