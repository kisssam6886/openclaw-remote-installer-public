$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$repairLog = Join-Path $env:OPENCLAW_RUNTIME_DIR 'repair-latest.log'
$configFile = Get-OpenClawConfigFile

function Get-LatestConfigBackup {
    $candidates = @()

    $patterns = @(
        (Join-Path $env:OPENCLAW_RUNTIME_DIR 'backups/openclaw.json.*.bak'),
        (Join-Path $env:OPENCLAW_STATE_DIR 'openclaw.json.bak'),
        (Join-Path $env:OPENCLAW_STATE_DIR 'openclaw.json.bak.*'),
        (Join-Path $env:OPENCLAW_STATE_DIR 'openclaw.json.backup.*'),
        (Join-Path $env:OPENCLAW_STATE_DIR 'backups/openclaw_*.json'),
        (Join-Path $env:OPENCLAW_STATE_DIR 'backups/upgrade_*/openclaw.json')
    )

    foreach ($pattern in $patterns) {
        $candidates += Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue
    }

    return ($candidates |
        Where-Object { $_.Length -gt 0 } |
        Sort-Object LastWriteTimeUtc -Descending |
        Select-Object -First 1)
}

$latestBackup = Get-LatestConfigBackup
Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR

$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add("[Repair] started at $(Get-TimestampUtc)")
$lines.Add("[Repair] config file: $configFile")

$npmRepairCommand = $null
foreach ($candidate in @($env:OPENCLAW_NPM_CMD, 'npm.cmd', 'npm.exe', 'npm')) {
    if ([string]::IsNullOrWhiteSpace($candidate)) { continue }
    $resolved = Get-Command $candidate -ErrorAction SilentlyContinue
    if ($resolved -and $resolved.Source) { $npmRepairCommand = $resolved.Source; break }
}
if ($npmRepairCommand) {
    try { & $npmRepairCommand cache verify | Out-Null } catch { try { & $npmRepairCommand cache clean --force | Out-Null } catch { } }
    $lines.Add('[Repair] npm cache refreshed')
}

if (Get-InstallerOpenClawCommand) {
    $configValid = $false
    if ((Test-Path $configFile) -and ((Get-Item $configFile).Length -gt 0)) {
        try {
            Invoke-InstallerOpenClaw -Arguments @('config', 'validate') | Out-Null
            $configValid = $true
        }
        catch {
            $configValid = $false
        }
    }

    if (-not $configValid) {
        if ($latestBackup) {
            Copy-Item -Path $latestBackup.FullName -Destination $configFile -Force
            $lines.Add("[Repair] restored latest config backup: $($latestBackup.FullName)")
        }
        else {
            $lines.Add('[Repair] config invalid but no backup found')
        }
    }

    try { Invoke-InstallerOpenClaw -Arguments @('gateway', 'stop') | Out-Null } catch { }
    try { Invoke-InstallerOpenClaw -Arguments @('doctor', '--non-interactive') | Out-Null } catch { }
    $lines.Add('[Repair] OpenClaw doctor executed')
}

if (Test-Path $env:OPENCLAW_INSTALLED_MARKER_FILE) {
    Remove-Item -Path $env:OPENCLAW_INSTALLED_MARKER_FILE -Force
}
$lines.Add('[Repair] cleared installed marker')
$lines.Add("[Repair] finished at $(Get-TimestampUtc)")

Set-Content -Path $repairLog -Value $lines -Encoding utf8
$lines | ForEach-Object { Write-Host $_ }
