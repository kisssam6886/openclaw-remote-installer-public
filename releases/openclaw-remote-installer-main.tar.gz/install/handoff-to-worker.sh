#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

echo "[Installer] handoff to worker starting..."

echo "[1/4] Verify worker template exists"
test -f "$REPO_ROOT/templates/worker-agent-template.yaml" || { echo "worker template missing"; exit 1; }

echo "[2/4] Verify first-run script exists"
test -f "$REPO_ROOT/install/worker-first-run.sh" || { echo "worker first-run script missing"; exit 1; }

echo "[3/4] Write worker runtime config to customer machine"
bash "$REPO_ROOT/install/apply-worker-template.sh"

echo "[4/4] Run worker first-run checks"
bash "$REPO_ROOT/install/worker-first-run.sh"

echo "[Installer] handoff to worker complete."
