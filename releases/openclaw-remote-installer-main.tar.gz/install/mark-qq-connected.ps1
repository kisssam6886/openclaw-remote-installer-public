param(
    [string]$AccountId = $env:OPENCLAW_QQ_ACCOUNT_ID,
    [string]$Note = $(if ($env:OPENCLAW_QQ_NOTE) { $env:OPENCLAW_QQ_NOTE } else { 'Customer QQ scan and test message confirmed.' })
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

Ensure-Directory -Path (Split-Path -Parent $env:OPENCLAW_QQ_STATUS_FILE)
@{
    connected    = $true
    account_id   = $AccountId
    note         = $Note
    verified_at  = Get-TimestampUtc
} | ConvertTo-Json -Depth 5 | Set-Content -Path $env:OPENCLAW_QQ_STATUS_FILE -Encoding utf8

Write-Host "[Installer] QQ connected marker written to: $($env:OPENCLAW_QQ_STATUS_FILE)"
Write-Host '[Installer] Re-run install/worker-first-run.ps1 to finalize the self-check.'
