#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

ATTEMPT="${1:-${OPENCLAW_INSTALL_ATTEMPT:-1}}"
EXIT_CODE="${2:-${OPENCLAW_INSTALL_EXIT_CODE:-1}}"
STAGE="${3:-${OPENCLAW_INSTALL_FAILURE_STAGE:-install-openclaw}}"
LOG_FILE="${4:-${OPENCLAW_LAST_INSTALL_LOG_FILE:-}}"
REPORT_KEY="$(sanitize_id "$(timestamp_utc)-$(machine_id)-attempt-$ATTEMPT")"
REPORT_DIR="$OPENCLAW_DIAGNOSTICS_DIR/$REPORT_KEY"
LATEST_POINTER="$OPENCLAW_RUNTIME_DIR/diagnostics-latest.txt"
SYNC_STATUS="skipped"

capture_command() {
  local target_name="$1"
  shift
  local target_file="$REPORT_DIR/commands/$target_name"
  {
    printf '$ %s\n' "$*"
    if "$@"; then
      :
    else
      printf '\n(command failed with exit code %s)\n' "$?"
    fi
  } >"$target_file" 2>&1
}

copy_if_exists() {
  local source_path="$1"
  local target_path="$2"
  if [ -f "$source_path" ]; then
    ensure_dir "$(dirname "$target_path")"
    cp "$source_path" "$target_path"
  fi
}

ensure_dir "$REPORT_DIR"
ensure_dir "$REPORT_DIR/commands"
ensure_dir "$REPORT_DIR/runtime"
ensure_dir "$REPORT_DIR/repo"

capture_command uname.txt uname -a
capture_command node-version.txt node --version
capture_command npm-version.txt npm --version
capture_command git-version.txt git --version
capture_command openclaw-version.txt openclaw --version
capture_command openclaw-config-file.txt openclaw config file
capture_command openclaw-config-validate.txt openclaw config validate
capture_command openclaw-doctor.txt openclaw doctor --non-interactive
capture_command openclaw-status.txt openclaw status
capture_command openclaw-gateway-status.txt openclaw gateway status
capture_command openclaw-browser-status.txt openclaw browser status

if [ "$(uname -s)" = "Darwin" ]; then
  capture_command sw-vers.txt sw_vers
fi

if [ -n "$LOG_FILE" ] && [ -f "$LOG_FILE" ]; then
  cp "$LOG_FILE" "$REPORT_DIR/runtime/install-attempt.log"
fi

CONFIG_FILE="$(openclaw_config_file)"
write_redacted_copy "$CONFIG_FILE" "$REPORT_DIR/runtime/openclaw.config.redacted.json"

if [ -n "$OPENCLAW_INSTALLER_ENV_FILE" ] && [ -f "$OPENCLAW_INSTALLER_ENV_FILE" ]; then
  write_redacted_copy "$OPENCLAW_INSTALLER_ENV_FILE" "$REPORT_DIR/runtime/installer-env.redacted"
fi

copy_if_exists "$OPENCLAW_RUNTIME_DIR/applied-worker-config.json" "$REPORT_DIR/runtime/applied-worker-config.json"
copy_if_exists "$OPENCLAW_INSTALL_SUMMARY_FILE" "$REPORT_DIR/runtime/install-summary.json"
copy_if_exists "$OPENCLAW_RUNTIME_DIR/registry-sync-status.json" "$REPORT_DIR/runtime/registry-sync-status.json"
copy_if_exists "$OPENCLAW_RUNTIME_DIR/diagnostics-sync-status.json" "$REPORT_DIR/runtime/diagnostics-sync-status.json"
copy_if_exists "$OPENCLAW_REGISTRY_DIR/$(machine_id).yaml" "$REPORT_DIR/runtime/registry-instance.yaml"
copy_if_exists "$REPO_ROOT/registry/instances/$(machine_id).yaml" "$REPORT_DIR/repo/registry-instance.yaml"

if [ -n "$OPENCLAW_DIAGNOSTICS_GIT_URL" ]; then
  if bash "$REPO_ROOT/install/sync-diagnostics.sh" "$REPORT_DIR" >/dev/null 2>&1; then
    SYNC_STATUS="synced"
  else
    SYNC_STATUS="failed"
  fi
fi

cat >"$REPORT_DIR/metadata.json" <<EOF2
{
  "generated_at": $(json_string "$(timestamp_utc)"),
  "machine_id": $(json_string "$(machine_id)"),
  "machine_name": $(json_string "$(machine_name)"),
  "os": $(json_string "$(os_label)"),
  "arch": $(json_string "$(arch_label)"),
  "openclaw_version": $(json_string "$(openclaw_version)"),
  "install_source": $(json_string "${OPENCLAW_INSTALL_SOURCE:-repo-local}"),
  "attempt": $ATTEMPT,
  "exit_code": $EXIT_CODE,
  "stage": $(json_string "$STAGE"),
  "log_file": $(json_string "$LOG_FILE"),
  "config_file": $(json_string "$CONFIG_FILE"),
  "provider_id": $(json_string "$OPENCLAW_PROVIDER_ID"),
  "provider_model_id": $(json_string "$OPENCLAW_PROVIDER_MODEL_ID"),
  "diagnostics_sync_status": $(json_string "$SYNC_STATUS")
}
EOF2

printf '%s\n' "$REPORT_DIR" >"$LATEST_POINTER"
printf '%s\n' "$REPORT_DIR"
