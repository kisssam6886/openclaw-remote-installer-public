#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

INSTANCE_FILE="$OPENCLAW_REGISTRY_DIR/$(machine_id).yaml"

echo "[Check] OpenClaw command"
command -v openclaw >/dev/null 2>&1 || { echo "OpenClaw missing"; exit 1; }

echo "[Check] Gateway status"
openclaw status >/dev/null 2>&1 || openclaw gateway status >/dev/null 2>&1 || { echo "Gateway not ready"; exit 1; }

echo "[Check] Browser capability"
openclaw browser --browser-profile openclaw status >/dev/null 2>&1 || openclaw browser status >/dev/null 2>&1 || { echo "Browser not ready"; exit 1; }

echo "[Check] Worker runtime artifacts"
test -f "$OPENCLAW_RUNTIME_DIR/worker-agent.yaml" || { echo "worker-agent.yaml missing"; exit 1; }
test -f "$OPENCLAW_RUNTIME_DIR/applied-worker-config.json" || { echo "applied-worker-config.json missing"; exit 1; }
test -f "$OPENCLAW_INSTALL_SUMMARY_FILE" || { echo "install-summary.json missing"; exit 1; }
test -f "$OPENCLAW_INSTALLED_MARKER_FILE" || { echo "installed.ok missing"; exit 1; }
test -f "$INSTANCE_FILE" || { echo "runtime registry instance missing"; exit 1; }

echo "[Check] Summary"
cat "$OPENCLAW_INSTALL_SUMMARY_FILE"

echo "[Check] Delivery looks ready."
