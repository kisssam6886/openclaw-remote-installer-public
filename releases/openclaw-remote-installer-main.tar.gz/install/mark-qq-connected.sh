#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

ACCOUNT_ID="${1:-${OPENCLAW_QQ_ACCOUNT_ID:-}}"
NOTE="${OPENCLAW_QQ_NOTE:-Customer QQ scan and test message confirmed.}"

write_qq_status true "$NOTE" "$ACCOUNT_ID"

echo "[Installer] QQ connected marker written to: $OPENCLAW_QQ_STATUS_FILE"
echo "[Installer] Re-run install/worker-first-run.sh to finalize the self-check."
