#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

INSTANCE_FILE="${1:-$OPENCLAW_REGISTRY_DIR/$(machine_id).yaml}"
SYNC_STATUS_FILE="$OPENCLAW_RUNTIME_DIR/registry-sync-status.json"

write_sync_status() {
  local status="$1"
  local note="${2:-}"
  local target_file="${3:-}"
  local now

  now="$(timestamp_utc)"
  ensure_dir "$(dirname "$SYNC_STATUS_FILE")"

  cat >"$SYNC_STATUS_FILE" <<EOF
{
  "status": $(json_string "$status"),
  "checked_at": $(json_string "$now"),
  "git_url": $(json_string "$OPENCLAW_REGISTRY_GIT_URL"),
  "branch": $(json_string "$OPENCLAW_REGISTRY_GIT_BRANCH"),
  "instance_file": $(json_string "$INSTANCE_FILE"),
  "target_file": $(json_string "$target_file"),
  "note": $(json_string "$note")
}
EOF
}

if [ ! -f "$INSTANCE_FILE" ]; then
  write_sync_status "failed" "Instance file missing." ""
  echo "Registry instance file missing: $INSTANCE_FILE"
  exit 1
fi

if [ -z "$OPENCLAW_REGISTRY_GIT_URL" ]; then
  write_sync_status "skipped" "OPENCLAW_REGISTRY_GIT_URL not set." ""
  echo "Registry sync skipped: OPENCLAW_REGISTRY_GIT_URL not set."
  exit 0
fi

ensure_dir "$OPENCLAW_RUNTIME_DIR"

if [ ! -d "$OPENCLAW_REGISTRY_GIT_DIR/.git" ]; then
  rm -rf "$OPENCLAW_REGISTRY_GIT_DIR"
  git clone "$OPENCLAW_REGISTRY_GIT_URL" "$OPENCLAW_REGISTRY_GIT_DIR" >/dev/null 2>&1 || {
    write_sync_status "failed" "git clone failed." ""
    echo "Registry sync failed: git clone failed."
    exit 1
  }
fi

ORIGIN_URL="$(git -C "$OPENCLAW_REGISTRY_GIT_DIR" remote get-url origin 2>/dev/null || true)"
if [ "$ORIGIN_URL" != "$OPENCLAW_REGISTRY_GIT_URL" ]; then
  git -C "$OPENCLAW_REGISTRY_GIT_DIR" remote set-url origin "$OPENCLAW_REGISTRY_GIT_URL"
fi

git -C "$OPENCLAW_REGISTRY_GIT_DIR" fetch origin >/dev/null 2>&1 || true

if git -C "$OPENCLAW_REGISTRY_GIT_DIR" show-ref --verify --quiet "refs/heads/$OPENCLAW_REGISTRY_GIT_BRANCH"; then
  git -C "$OPENCLAW_REGISTRY_GIT_DIR" checkout "$OPENCLAW_REGISTRY_GIT_BRANCH" >/dev/null 2>&1
else
  if git -C "$OPENCLAW_REGISTRY_GIT_DIR" show-ref --verify --quiet "refs/remotes/origin/$OPENCLAW_REGISTRY_GIT_BRANCH"; then
    git -C "$OPENCLAW_REGISTRY_GIT_DIR" checkout -B "$OPENCLAW_REGISTRY_GIT_BRANCH" "origin/$OPENCLAW_REGISTRY_GIT_BRANCH" >/dev/null 2>&1
  else
    git -C "$OPENCLAW_REGISTRY_GIT_DIR" checkout -B "$OPENCLAW_REGISTRY_GIT_BRANCH" >/dev/null 2>&1
  fi
fi

git -C "$OPENCLAW_REGISTRY_GIT_DIR" pull --ff-only origin "$OPENCLAW_REGISTRY_GIT_BRANCH" >/dev/null 2>&1 || true

TARGET_DIR="$OPENCLAW_REGISTRY_GIT_DIR/$OPENCLAW_REGISTRY_GIT_SUBDIR"
TARGET_FILE="$TARGET_DIR/$(basename "$INSTANCE_FILE")"
ensure_dir "$TARGET_DIR"
cp "$INSTANCE_FILE" "$TARGET_FILE"

git -C "$OPENCLAW_REGISTRY_GIT_DIR" config user.name "$OPENCLAW_REGISTRY_GIT_AUTHOR_NAME"
git -C "$OPENCLAW_REGISTRY_GIT_DIR" config user.email "$OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL"
git -C "$OPENCLAW_REGISTRY_GIT_DIR" add "$TARGET_FILE"

if git -C "$OPENCLAW_REGISTRY_GIT_DIR" diff --cached --quiet; then
  write_sync_status "unchanged" "No registry changes to push." "$TARGET_FILE"
  echo "Registry sync unchanged: $TARGET_FILE"
  exit 0
fi

git -C "$OPENCLAW_REGISTRY_GIT_DIR" commit -m "Sync registry $(basename "$INSTANCE_FILE")" >/dev/null 2>&1 || {
  write_sync_status "failed" "git commit failed." "$TARGET_FILE"
  echo "Registry sync failed: git commit failed."
  exit 1
}

git -C "$OPENCLAW_REGISTRY_GIT_DIR" push -u origin "$OPENCLAW_REGISTRY_GIT_BRANCH" >/dev/null 2>&1 || {
  write_sync_status "failed" "git push failed." "$TARGET_FILE"
  echo "Registry sync failed: git push failed."
  exit 1
}

write_sync_status "synced" "Registry instance pushed successfully." "$TARGET_FILE"
echo "Registry sync complete: $TARGET_FILE"
