$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$repoRegistryDir = Join-Path $script:RepoRoot 'registry/instances'
$runtimeInstanceDir = $env:OPENCLAW_REGISTRY_DIR
$instanceId = Get-MachineId
$instanceFileName = "$instanceId.yaml"
$runtimeInstanceFile = Join-Path $runtimeInstanceDir $instanceFileName
$repoInstanceFile = Join-Path $repoRegistryDir $instanceFileName
$configFile = Get-OpenClawConfigFile

function Get-ChannelStatus {
    if ($env:OPENCLAW_CHANNEL -eq 'pending' -or -not $env:OPENCLAW_CHANNEL) {
        return 'not-configured'
    }

    return 'pending'
}

function Write-RegistryInstance {
    param(
        [string]$Path,
        [string]$ChannelStatus
    )

    $now = Get-TimestampUtc
    $installedAt = $now

    Ensure-Directory -Path (Split-Path -Parent $Path)

    if (Test-Path $Path) {
        $existingInstalledAt = Select-String -Path $Path -Pattern "^installed_at: '(.*)'$" | Select-Object -First 1
        if ($existingInstalledAt) {
            $installedAt = $existingInstalledAt.Matches[0].Groups[1].Value
        }
    }

    $knownIssues = if ($ChannelStatus -eq 'pending') { "known_issues:`n  - 'Channel setup pending'" } else { 'known_issues: []' }

    @"
customer_id: $(ConvertTo-YamlSingleQuoted $instanceId)
name: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_CUSTOMER_NAME)
contact: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_CUSTOMER_CONTACT)
remote_tool: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_REMOTE_TOOL)
remote_id: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_REMOTE_ID)
install_source: $(ConvertTo-YamlSingleQuoted $(if ($env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE } else { 'repo-local' }))
os: $(ConvertTo-YamlSingleQuoted (Get-OSLabel))
arch: $(ConvertTo-YamlSingleQuoted (Get-ArchLabel))
machine_name: $(ConvertTo-YamlSingleQuoted (Get-MachineName))
openclaw_version: $(ConvertTo-YamlSingleQuoted (Get-OpenClawVersion))
edition: 'operations'
channel: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_CHANNEL)
channel_status: $(ConvertTo-YamlSingleQuoted $ChannelStatus)
worker_model: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_WORKER_MODEL)
provider_id: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_PROVIDER_ID)
provider_model_id: $(ConvertTo-YamlSingleQuoted $env:OPENCLAW_PROVIDER_MODEL_ID)
config_file: $(ConvertTo-YamlSingleQuoted $configFile)
registry_generated_at: $(ConvertTo-YamlSingleQuoted $now)
installed_at: $(ConvertTo-YamlSingleQuoted $installedAt)
last_maintained_at: $(ConvertTo-YamlSingleQuoted $now)
installed_skills:
  - 'agent-browser'
  - 'himalaya'
  - 'self-improvement'
  - 'task-status'
notes:
  - 'Worker first-run generated this record.'
  - $(ConvertTo-YamlSingleQuoted "Channel status: $($env:OPENCLAW_CHANNEL) / $ChannelStatus")
$knownIssues
maintenance_log:
  - $(ConvertTo-YamlSingleQuoted "$now worker-first-run self-check completed with channel_status=$ChannelStatus")
"@ | Set-Content -Path $Path -Encoding utf8
}

function Write-InstallSummary {
    param(
        [string]$Status,
        [string]$ChannelStatus,
        [string]$RegistrySyncStatus
    )

    Write-JsonFile -Path $env:OPENCLAW_INSTALL_SUMMARY_FILE -Object @{
        status                = $Status
        completed_at          = Get-TimestampUtc
        machine_id            = $instanceId
        machine_name          = Get-MachineName
        os                    = Get-OSLabel
        arch                  = Get-ArchLabel
        openclaw_version      = Get-OpenClawVersion
        worker_model          = $env:OPENCLAW_WORKER_MODEL
        provider_id           = $env:OPENCLAW_PROVIDER_ID
        provider_model_id     = $env:OPENCLAW_PROVIDER_MODEL_ID
        install_source        = $(if ($env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE } else { 'repo-local' })
        installer_env_file    = $env:OPENCLAW_INSTALLER_ENV_FILE
        channel               = $env:OPENCLAW_CHANNEL
        channel_status        = $ChannelStatus
        registry_sync_status  = $RegistrySyncStatus
        config_file           = $configFile
        runtime_registry_file = $runtimeInstanceFile
        repo_registry_file    = $repoInstanceFile
    }
}

Write-Host '[Worker Agent] first run starting...'

Write-Host '[1/8] Verify OpenClaw command'
if (-not (Get-InstallerOpenClawCommand)) { throw 'OpenClaw not found' }

Write-Host '[2/8] Verify browser capability command'
try { Invoke-InstallerOpenClaw -Arguments @('browser', '--browser-profile', 'openclaw', 'status') | Out-Null } catch { Invoke-InstallerOpenClaw -Arguments @('browser', 'status') | Out-Null }

Write-Host '[3/8] Verify required skills installation'
foreach ($skill in $script:RequiredSkills) {
    if (-not (Test-SkillInstalled -Skill $skill)) {
        throw "Missing skill: $skill"
    }
}

Write-Host '[4/8] Verify runtime config application'
$appliedConfigFile = Join-Path $env:OPENCLAW_RUNTIME_DIR 'applied-worker-config.json'
if (-not (Test-Path $appliedConfigFile)) { throw 'Applied worker config marker missing' }
if ($env:OPENCLAW_REQUIRE_PROVIDER_CONFIG -eq 'true') {
    $appliedConfig = Get-Content -Path $appliedConfigFile -Raw | ConvertFrom-Json
    if (-not $appliedConfig.provider_configured) { throw 'Worker provider config missing' }
}

if (-not (Test-Path $configFile)) { throw "OpenClaw config file missing: $configFile" }
Invoke-InstallerOpenClaw -Arguments @('config', 'validate') | Out-Null
Invoke-InstallerOpenClaw -Arguments @('doctor', '--non-interactive') | Out-Null

Write-Host '[5/8] Verify gateway status'
try { Invoke-InstallerOpenClaw -Arguments @('status') | Out-Null } catch { Invoke-InstallerOpenClaw -Arguments @('gateway', 'status') | Out-Null }

Write-Host '[6/8] Verify documentation and registry template exist'
if (-not (Test-Path (Join-Path $script:RepoRoot 'docs/qq-onboarding.md'))) { throw 'QQ onboarding doc missing' }
if (-not (Test-Path (Join-Path $script:RepoRoot 'registry/customer-template.yaml'))) { throw 'Customer registry template missing' }

$channelStatus = Get-ChannelStatus
$registrySyncStatus = 'skipped'

Write-Host '[7/8] Generate customer registry instance'
Write-RegistryInstance -Path $runtimeInstanceFile -ChannelStatus $channelStatus
Write-RegistryInstance -Path $repoInstanceFile -ChannelStatus $channelStatus

if ($env:OPENCLAW_REGISTRY_GIT_URL) {
    try {
        & (Join-Path $PSScriptRoot 'sync-customer-registry.ps1') -InstanceFile $runtimeInstanceFile
        $registrySyncStatus = 'synced'
    }
    catch {
        $registrySyncStatus = 'failed'
        if ($env:OPENCLAW_REGISTRY_SYNC_REQUIRED -eq 'true') {
            throw 'Customer registry sync is required but failed.'
        }
    }
}

Write-Host '[8/8] Write install completion summary'
Write-InstallSummary -Status 'ready' -ChannelStatus $channelStatus -RegistrySyncStatus $registrySyncStatus
Set-Content -Path $env:OPENCLAW_INSTALLED_MARKER_FILE -Value 'ok' -Encoding utf8

Write-Host '[Worker Agent] first run complete.'
