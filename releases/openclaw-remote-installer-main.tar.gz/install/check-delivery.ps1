$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$instanceFile = Join-Path $env:OPENCLAW_REGISTRY_DIR ("{0}.yaml" -f (Get-MachineId))

Write-Host '[Check] OpenClaw command'
if (-not (Get-Command openclaw -ErrorAction SilentlyContinue)) { throw 'OpenClaw missing' }

Write-Host '[Check] Gateway status'
try { & openclaw status | Out-Null } catch { & openclaw gateway status | Out-Null }

Write-Host '[Check] Browser capability'
try { & openclaw browser --browser-profile openclaw status | Out-Null } catch { & openclaw browser status | Out-Null }

Write-Host '[Check] Worker runtime artifacts'
if (-not (Test-Path (Join-Path $env:OPENCLAW_RUNTIME_DIR 'worker-agent.yaml'))) { throw 'worker-agent.yaml missing' }
if (-not (Test-Path (Join-Path $env:OPENCLAW_RUNTIME_DIR 'applied-worker-config.json'))) { throw 'applied-worker-config.json missing' }
if (-not (Test-Path $env:OPENCLAW_INSTALL_SUMMARY_FILE)) { throw 'install-summary.json missing' }
if (-not (Test-Path $env:OPENCLAW_INSTALLED_MARKER_FILE)) { throw 'installed.ok missing' }
if (-not (Test-Path $instanceFile)) { throw 'runtime registry instance missing' }

Write-Host '[Check] Summary'
Get-Content -Path $env:OPENCLAW_INSTALL_SUMMARY_FILE

Write-Host '[Check] Delivery looks ready.'
