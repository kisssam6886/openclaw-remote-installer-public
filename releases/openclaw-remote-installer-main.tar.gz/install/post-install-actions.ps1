$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

if (-not $env:OPENCLAW_POST_INSTALL_OPEN_DASHBOARD) { $env:OPENCLAW_POST_INSTALL_OPEN_DASHBOARD = 'true' }
if (-not $env:OPENCLAW_POST_INSTALL_OPEN_QQBOT) { $env:OPENCLAW_POST_INSTALL_OPEN_QQBOT = 'true' }
if (-not $env:OPENCLAW_QQBOT_LOGIN_URL) { $env:OPENCLAW_QQBOT_LOGIN_URL = 'https://q.qq.com/qqbot/openclaw/login.html' }

function Test-BoolTrue {
    param([string]$Value)

    if (-not $Value) { return $false }

    switch ($Value.ToLowerInvariant()) {
        '1' { return $true }
        'true' { return $true }
        'yes' { return $true }
        'y' { return $true }
        'on' { return $true }
        default { return $false }
    }
}

function Open-UrlBestEffort {
    param([string]$Url)

    try {
        Start-Process $Url | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

Write-Host '[Post Install] starting...'

if (Test-BoolTrue $env:OPENCLAW_POST_INSTALL_OPEN_DASHBOARD) {
    Write-Host '[Post Install] Opening OpenClaw dashboard...'
    if (Get-Command openclaw -ErrorAction SilentlyContinue) {
        try { & openclaw dashboard | Out-Null } catch { Write-Host '[Post Install] OpenClaw dashboard open failed; continuing.' }
    }
    else {
        Write-Host '[Post Install] OpenClaw command missing; skip dashboard open.'
    }
}
else {
    Write-Host '[Post Install] Dashboard auto-open disabled.'
}

if (Test-BoolTrue $env:OPENCLAW_POST_INSTALL_OPEN_QQBOT) {
    Write-Host '[Post Install] Opening QQ Bot login page...'
    if (-not (Open-UrlBestEffort $env:OPENCLAW_QQBOT_LOGIN_URL)) {
        Write-Host '[Post Install] QQ Bot login page open failed; continuing.'
    }
}
else {
    Write-Host '[Post Install] QQ Bot login page auto-open disabled.'
}

Write-Host '[Post Install] complete.'
