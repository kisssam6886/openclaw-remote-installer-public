# Operations Edition

## Default stack
- OpenClaw
- Browser capability
- QQ channel

## Default skills
1. agent-browser
2. himalaya
3. self-improvement
4. task-status

## Delivery checklist
- OpenClaw installed
- Browser capability available
- QQ connected by customer scan
- Required skills present
- Customer registry file created
