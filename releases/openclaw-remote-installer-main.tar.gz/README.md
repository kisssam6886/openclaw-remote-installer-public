# openclaw-remote-installer

面向客户机的 OpenClaw 远程安装工具。
当前主线目标是：你用 AnyDesk 连接客户的 macOS / Windows 电脑后，只跑一条命令，就自动完成 OpenClaw 安装、基础 skills 配置、运行自检、客户档案生成；如果安装失败，会自动收集诊断并按规则重试修复。

## 当前主线

- macOS：可直接实机测试
- Windows：已补齐 PowerShell 主链，可继续实机验证
- 默认模型：`nvidia/moonshotai/kimi-k2.5`
- 默认 provider：`nvidia`
- 默认 endpoint：`https://integrate.api.nvidia.com/v1`
- 真实 API key：只通过环境变量或 `.env.local` 注入，不写进仓库

## 安装链路

### macOS

- `bootstrap/macos.sh`
- `install/install-runner.sh`
- `install/install-openclaw.sh`
- `install/install-required-skills.sh`
- `install/handoff-to-worker.sh`
- `install/apply-worker-template.sh`
- `install/worker-first-run.sh`
- `install/check-delivery.sh`

### Windows

- `bootstrap/windows.ps1`
- `install/install-runner.ps1`
- `install/install-openclaw.ps1`
- `install/install-required-skills.ps1`
- `install/handoff-to-worker.ps1`
- `install/apply-worker-template.ps1`
- `install/worker-first-run.ps1`
- `install/check-delivery.ps1`

## 新增能力

- 自动重试：失败后自动进入 `collect-diagnostics -> repair -> retry`
- 诊断归档：失败时写入本地 `~/.openclaw/installer-runtime/diagnostics/`
- 可选 GitHub 诊断同步：设置 `OPENCLAW_DIAGNOSTICS_GIT_URL`
- 客户档案：写入本地运行时 registry，并可选同步到私有 GitHub registry repo
- 一键远程安装入口：`bootstrap/remote-install.sh` / `bootstrap/remote-install.ps1`

## 客户机必装 skills

- `agent-browser`
- `himalaya`
- `self-improvement`
- `task-status`

## 一键安装命令

### macOS

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_PROVIDER_API_KEY='替换成你的 NVIDIA key' bash
```

### Windows PowerShell

```powershell
$env:OPENCLAW_PROVIDER_API_KEY='替换成你的 NVIDIA key'
irm https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1 | iex
```

### 可选：顺手把客户信息写进 registry

```bash
curl -fsSL https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh | OPENCLAW_CUSTOMER_NAME='客户名' OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID='123456789' OPENCLAW_PROVIDER_API_KEY='你的 NVIDIA key' bash
```

## 镜像分发建议

- 当前仓库已支持 `OPENCLAW_INSTALL_ARCHIVE_URL`
- 以后你做国内镜像时，只要把同一份归档包放到自定义域名
- 远程安装脚本仍可复用，只需把归档地址改成镜像地址
- 如果连 `raw.githubusercontent.com` 也不稳定，就把 `bootstrap/remote-install.sh` 和 `bootstrap/remote-install.ps1` 一并镜像出去

## 公开镜像分发

- 当前源码仓库可以继续保持私有
- 如果客户要匿名执行安装命令，对外必须有一个公开分发出口
- 推荐做法：私有源码仓库 + 公共分发仓库
- 详细说明见 `docs/public-mirror-setup.md`
- 我已补好自动发布工作流：`.github/workflows/publish-public-mirror.yml`

## 关键产物

- `~/.openclaw/installer-runtime/worker-agent.yaml`
- `~/.openclaw/installer-runtime/applied-worker-config.json`
- `~/.openclaw/installer-runtime/install-summary.json`
- `~/.openclaw/installer-runtime/installed.ok`
- `~/.openclaw/installer-runtime/diagnostics/`
- `registry/instances/<machine-id>.yaml`

## 测试入口

- macOS：`bash bootstrap/macos.sh`
- Windows：`powershell -ExecutionPolicy Bypass -File .\bootstrap\windows.ps1`
- macOS 交付检查：`bash install/check-delivery.sh`
- Windows 交付检查：`powershell -ExecutionPolicy Bypass -File .\install\check-delivery.ps1`
