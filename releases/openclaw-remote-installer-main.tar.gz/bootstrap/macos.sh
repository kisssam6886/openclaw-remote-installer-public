#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
NODE_MIN_MAJOR="22"
NODE_LTS_MAJOR="24"
NODE_INSTALL_TMP_DIR="${TMPDIR:-/tmp}/openclaw-node-installer"
NODE_TARBALL_INSTALL_DIR="${HOME}/.openclaw/tooling/node-lts"

resolve_node_dist_url() {
  local latest_dir_url="$1"
  local pattern="$2"

  curl -fsSL "$latest_dir_url" \
    | sed -n "s#.*href=\"\(/dist/latest-v[0-9][^/]*/${pattern}\)\".*#https://nodejs.org\\1#p" \
    | sed -n '1p'
}

install_node_from_official_pkg() {
  local latest_dir_url="https://nodejs.org/dist/latest-v${NODE_LTS_MAJOR}.x/"
  local pkg_url
  local pkg_file

  echo "Homebrew 安装 Node.js 失败，开始尝试 Node.js 官方安装包..."

  pkg_url="$(resolve_node_dist_url "$latest_dir_url" 'node-v[^\"]*\\.pkg')"
  if [ -z "$pkg_url" ]; then
    echo "无法解析 Node.js 官方 pkg 下载地址：$latest_dir_url"
    return 1
  fi

  mkdir -p "$NODE_INSTALL_TMP_DIR"
  pkg_file="$NODE_INSTALL_TMP_DIR/$(basename "$pkg_url")"

  echo "Downloading: $pkg_url"
  curl -fsSL "$pkg_url" -o "$pkg_file"

  echo "Installing official Node.js pkg..."
  sudo installer -pkg "$pkg_file" -target /
}

install_node_from_official_tarball() {
  local latest_dir_url="https://nodejs.org/dist/latest-v${NODE_LTS_MAJOR}.x/"
  local arch
  local tar_url
  local tar_file
  local extract_dir
  local extracted_node_dir

  arch="$(uname -m)"
  case "$arch" in
    arm64) arch='arm64' ;;
    x86_64) arch='x64' ;;
    *)
      echo "Unsupported macOS architecture for Node tarball fallback: $arch"
      return 1
      ;;
  esac

  echo "官方 pkg 安装失败，开始尝试 Node.js 官方 tarball..."

  tar_url="$(resolve_node_dist_url "$latest_dir_url" "node-v[^\"]*-darwin-${arch}\\.tar\\.gz")"
  if [ -z "$tar_url" ]; then
    echo "无法解析 Node.js 官方 tarball 下载地址：$latest_dir_url"
    return 1
  fi

  mkdir -p "$NODE_INSTALL_TMP_DIR"
  tar_file="$NODE_INSTALL_TMP_DIR/$(basename "$tar_url")"
  extract_dir="$NODE_INSTALL_TMP_DIR/extract"

  rm -rf "$extract_dir" "$NODE_TARBALL_INSTALL_DIR"
  mkdir -p "$extract_dir" "$NODE_TARBALL_INSTALL_DIR"

  echo "Downloading: $tar_url"
  curl -fsSL "$tar_url" -o "$tar_file"

  echo "Extracting official Node.js tarball..."
  tar -xzf "$tar_file" -C "$extract_dir"
  extracted_node_dir="$(find "$extract_dir" -mindepth 1 -maxdepth 1 -type d | sed -n '1p')"
  if [ -z "$extracted_node_dir" ]; then
    echo "Node.js tarball 解压后未找到目录。"
    return 1
  fi

  cp -R "$extracted_node_dir"/. "$NODE_TARBALL_INSTALL_DIR/"
  export PATH="$NODE_TARBALL_INSTALL_DIR/bin:$PATH"

  echo "Node.js tarball 已安装到: $NODE_TARBALL_INSTALL_DIR"
  echo "当前会话 PATH 已加入: $NODE_TARBALL_INSTALL_DIR/bin"
}

ensure_node_ready() {
  local node_major

  if command -v node >/dev/null 2>&1; then
    node_major="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || echo 0)"
    if [ -n "$node_major" ] && [ "$node_major" -ge "$NODE_MIN_MAJOR" ]; then
      return 0
    fi
  fi

  if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew not found. Please install Homebrew first: https://brew.sh/"
    exit 1
  fi

  if brew install node; then
    return 0
  fi

  if install_node_from_official_pkg; then
    return 0
  fi

  install_node_from_official_tarball
}

echo "[OpenClaw Installer] macOS bootstrap starting..."

echo "[1/4] Checking Homebrew"
if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew not found. Please install Homebrew first: https://brew.sh/"
  exit 1
fi

echo "[2/4] Checking Git"
if ! command -v git >/dev/null 2>&1; then
  brew install git
fi

echo "[3/4] Checking Node.js"
ensure_node_ready

NODE_MAJOR="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || echo 0)"
if [ -z "$NODE_MAJOR" ] || [ "$NODE_MAJOR" -lt "$NODE_MIN_MAJOR" ]; then
  echo "Node.js ${NODE_MIN_MAJOR}+ is required by OpenClaw. Current: $(node -v 2>/dev/null || echo missing)"
  echo "Please fix Node.js, then re-run bootstrap/macos.sh"
  exit 1
fi

echo "[4/4] Run OpenClaw install runner"
bash "$REPO_ROOT/install/install-runner.sh"

echo "Bootstrap complete."
