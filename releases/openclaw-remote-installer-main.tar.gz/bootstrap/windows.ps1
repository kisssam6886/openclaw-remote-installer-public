$ErrorActionPreference = 'Stop'

$psMajor = 2
if ($PSVersionTable -and $PSVersionTable.PSVersion) { $psMajor = [int]$PSVersionTable.PSVersion.Major }
if ($psMajor -lt 5) { throw "Windows PowerShell 5.1+ or PowerShell 7 is required. Detected major version: $psMajor" }

$RepoRoot = Split-Path -Parent $PSScriptRoot

function Refresh-ProcessPath {
    $parts = @()

    foreach ($scope in 'Machine', 'User') {
        $value = [Environment]::GetEnvironmentVariable('Path', $scope)
        if ($value) {
            $parts += ($value -split ';')
        }
    }

    if ($env:Path) {
        $parts += ($env:Path -split ';')
    }

    $env:Path = (($parts | Where-Object { $_ } | Select-Object -Unique) -join ';')
}

function Find-Executable {
    param([string[]]$Candidates)

    foreach ($candidate in $Candidates) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path $candidate)) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

function Ensure-CommandReady {
    param(
        [string]$CommandName,
        [string[]]$Candidates
    )

    $command = Get-Command $CommandName -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }

    Refresh-ProcessPath
    $command = Get-Command $CommandName -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }

    $found = Find-Executable -Candidates $Candidates
    if ($found) {
        $env:Path = ((Split-Path -Parent $found), $env:Path) -join ';'
        return $found
    }

    return $null
}

function Install-WithWingetIfMissing {
    param(
        [string]$WingetId,
        [string[]]$Candidates,
        [string]$PrimaryCommandName
    )

    $resolved = Ensure-CommandReady -CommandName $PrimaryCommandName -Candidates $Candidates
    if ($resolved) {
        return $resolved
    }

    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
        return $null
    }

    & winget install --id $WingetId -e --source winget --accept-package-agreements --accept-source-agreements
    return (Ensure-CommandReady -CommandName $PrimaryCommandName -Candidates $Candidates)
}

Write-Host '[OpenClaw Installer] Windows bootstrap starting...'

Write-Host '[1/4] Check Git'
$gitCandidates = @(
    (Join-Path $env:ProgramFiles 'Git\cmd\git.exe'),
    (Join-Path $env:ProgramFiles 'Git\bin\git.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Git\cmd\git.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Git\bin\git.exe')
)
$gitPath = Install-WithWingetIfMissing -WingetId 'Git.Git' -Candidates $gitCandidates -PrimaryCommandName 'git'
if (-not $gitPath) {
    throw 'Git not found after install attempt. Please install Git first.'
}

Write-Host '[2/4] Check Node.js'
$nodeCandidates = @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
)
$nodePath = Install-WithWingetIfMissing -WingetId 'OpenJS.NodeJS.LTS' -Candidates $nodeCandidates -PrimaryCommandName 'node'
if (-not $nodePath) {
    throw 'Node.js not found after install attempt. Please install Node.js 22+ first.'
}

$nodeVersion = (& $nodePath --version)
$nodeMajor = [int](($nodeVersion -replace '^v', '').Split('.')[0])
if ($nodeMajor -lt 22) {
    throw "Node.js 22+ is required by OpenClaw. Current: $nodeVersion"
}

$nodeDir = Split-Path -Parent $nodePath
$env:OPENCLAW_NODE_EXE = $nodePath
$env:OPENCLAW_NODE_HOME = $nodeDir

$npmCandidates = @(
    (Join-Path $nodeDir 'npm.cmd'),
    (Join-Path $nodeDir 'npm.exe'),
    (Join-Path $nodeDir 'npm'),
    (Join-Path $env:ProgramFiles 'nodejs\npm.cmd'),
    (Join-Path ${env:ProgramFiles(x86)} 'nodejs\npm.cmd'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\npm.cmd')
)
$npmPath = Ensure-CommandReady -CommandName 'npm.cmd' -Candidates $npmCandidates
if (-not $npmPath) {
    $npmPath = Ensure-CommandReady -CommandName 'npm' -Candidates $npmCandidates
}
if (-not $npmPath) {
    throw 'npm not found after Node.js setup. Please restart PowerShell and retry.'
}
$env:OPENCLAW_NPM_CMD = $npmPath

$npxCandidates = @(
    (Join-Path $nodeDir 'npx.cmd'),
    (Join-Path $nodeDir 'npx.exe'),
    (Join-Path $nodeDir 'npx'),
    (Join-Path $env:ProgramFiles 'nodejs\npx.cmd'),
    (Join-Path ${env:ProgramFiles(x86)} 'nodejs\npx.cmd'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\npx.cmd')
)
$npxPath = Ensure-CommandReady -CommandName 'npx.cmd' -Candidates $npxCandidates
if (-not $npxPath) {
    $npxPath = Ensure-CommandReady -CommandName 'npx' -Candidates $npxCandidates
}
if ($npxPath) {
    $env:OPENCLAW_NPX_CMD = $npxPath
}

Write-Host '[3/4] Run OpenClaw install runner'
& (Join-Path $RepoRoot 'install/install-runner.ps1')

Write-Host '[4/4] Bootstrap complete.'
