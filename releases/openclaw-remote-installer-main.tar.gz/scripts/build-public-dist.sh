#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DIST_DIR="${1:-$REPO_ROOT/.dist-public}"
DIST_REPO="${DIST_REPO:-kisssam6886/openclaw-remote-installer-public}"
DIST_BRANCH="${DIST_BRANCH:-main}"
ARCHIVE_BASENAME="${ARCHIVE_BASENAME:-openclaw-remote-installer-main}"

rm -rf "$DIST_DIR"
mkdir -p "$DIST_DIR/bootstrap" "$DIST_DIR/releases"

TAR_PATH="$DIST_DIR/releases/${ARCHIVE_BASENAME}.tar.gz"
ZIP_PATH="$DIST_DIR/releases/${ARCHIVE_BASENAME}.zip"

if command -v git >/dev/null 2>&1 && git -C "$REPO_ROOT" rev-parse --git-dir >/dev/null 2>&1; then
  git -C "$REPO_ROOT" archive --format=tar.gz --output="$TAR_PATH" HEAD
  git -C "$REPO_ROOT" archive --format=zip --output="$ZIP_PATH" HEAD
else
  echo "git is required to build public dist archives."
  exit 1
fi

export REPO_ROOT DIST_DIR DIST_REPO DIST_BRANCH ARCHIVE_BASENAME
python3 - <<'PY'
import json
import os
import shutil
from pathlib import Path

repo_root = Path(os.environ['REPO_ROOT'])
dist_dir = Path(os.environ['DIST_DIR'])
dist_repo = os.environ['DIST_REPO']
dist_branch = os.environ['DIST_BRANCH']
archive_basename = os.environ['ARCHIVE_BASENAME']

public_tar_url = f"https://raw.githubusercontent.com/{dist_repo}/{dist_branch}/releases/{archive_basename}.tar.gz"
public_zip_url = f"https://raw.githubusercontent.com/{dist_repo}/{dist_branch}/releases/{archive_basename}.zip"

src_sh = (repo_root / 'bootstrap' / 'remote-install.sh').read_text()
src_ps1 = (repo_root / 'bootstrap' / 'remote-install.ps1').read_text()

public_sh = src_sh.replace(
    'OPENCLAW_INSTALL_ARCHIVE_URL="${OPENCLAW_INSTALL_ARCHIVE_URL:-https://github.com/${OPENCLAW_INSTALL_REPO}/archive/refs/heads/${OPENCLAW_INSTALL_REF}.tar.gz}"',
    f'OPENCLAW_INSTALL_ARCHIVE_URL="${{OPENCLAW_INSTALL_ARCHIVE_URL:-{public_tar_url}}}"'
).replace(
    'OPENCLAW_INSTALL_SOURCE="${OPENCLAW_INSTALL_SOURCE:-github-archive}"',
    'OPENCLAW_INSTALL_SOURCE="${OPENCLAW_INSTALL_SOURCE:-public-mirror}"'
)

public_ps1 = src_ps1.replace(
    "if (-not $env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE = 'github-archive' }",
    "if (-not $env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE = 'public-mirror' }"
).replace(
    '$archiveUrl = if ($env:OPENCLAW_INSTALL_ARCHIVE_URL) { $env:OPENCLAW_INSTALL_ARCHIVE_URL } else { "https://github.com/$repo/archive/refs/heads/$ref.zip" }',
    f'$archiveUrl = if ($env:OPENCLAW_INSTALL_ARCHIVE_URL) {{ $env:OPENCLAW_INSTALL_ARCHIVE_URL }} else {{ "{public_zip_url}" }}'
)

(dist_dir / 'bootstrap' / 'remote-install.sh').write_text(public_sh)
(dist_dir / 'bootstrap' / 'remote-install.ps1').write_text(public_ps1)
(dist_dir / 'bootstrap' / 'source-remote-install.sh').write_text(src_sh)
(dist_dir / 'bootstrap' / 'source-remote-install.ps1').write_text(src_ps1)

manifest = {
    'name': 'openclaw-remote-installer-public',
    'version': '0.2.1',
    'source_repo': dist_repo,
    'dist_branch': dist_branch,
    'bootstrap': {
        'macos': f'https://raw.githubusercontent.com/{dist_repo}/{dist_branch}/bootstrap/remote-install.sh',
        'windows': f'https://raw.githubusercontent.com/{dist_repo}/{dist_branch}/bootstrap/remote-install.ps1',
    },
    'archives': {
        'tar_gz': public_tar_url,
        'zip': public_zip_url,
    },
}
(dist_dir / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')

shutil.copymode(repo_root / 'bootstrap' / 'remote-install.sh', dist_dir / 'bootstrap' / 'remote-install.sh')
shutil.copymode(repo_root / 'bootstrap' / 'remote-install.sh', dist_dir / 'bootstrap' / 'source-remote-install.sh')
PY

echo "Public dist prepared at: $DIST_DIR"
