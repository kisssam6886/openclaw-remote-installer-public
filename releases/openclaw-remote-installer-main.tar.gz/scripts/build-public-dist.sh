#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
DIST_DIR="${1:-$REPO_ROOT/.dist-public}"
DIST_REPO="${DIST_REPO:-kisssam6886/openclaw-remote-installer-public}"
DIST_BRANCH="${DIST_BRANCH:-main}"
ARCHIVE_BASENAME="${ARCHIVE_BASENAME:-openclaw-remote-installer-main}"

rm -rf "$DIST_DIR"
mkdir -p "$DIST_DIR/bootstrap" "$DIST_DIR/releases"

TAR_PATH="$DIST_DIR/releases/${ARCHIVE_BASENAME}.tar.gz"
ZIP_PATH="$DIST_DIR/releases/${ARCHIVE_BASENAME}.zip"

if command -v git >/dev/null 2>&1 && git -C "$REPO_ROOT" rev-parse --git-dir >/dev/null 2>&1; then
  git -C "$REPO_ROOT" archive --format=tar.gz --output="$TAR_PATH" HEAD
  git -C "$REPO_ROOT" archive --format=zip --output="$ZIP_PATH" HEAD
else
  echo "git is required to build public dist archives."
  exit 1
fi

cat > "$DIST_DIR/bootstrap/remote-install.sh" <<EOF
#!/usr/bin/env bash
set -euo pipefail
OPENCLAW_INSTALL_SOURCE="\${OPENCLAW_INSTALL_SOURCE:-public-mirror}"
OPENCLAW_INSTALL_ARCHIVE_URL="\${OPENCLAW_INSTALL_ARCHIVE_URL:-https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/releases/${ARCHIVE_BASENAME}.tar.gz}"
export OPENCLAW_INSTALL_SOURCE OPENCLAW_INSTALL_ARCHIVE_URL
curl -fsSL "https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/bootstrap/source-remote-install.sh" | bash
EOF
chmod +x "$DIST_DIR/bootstrap/remote-install.sh"

cat > "$DIST_DIR/bootstrap/remote-install.ps1" <<'EOF'
$ErrorActionPreference = 'Stop'
if (-not $env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE = 'public-mirror' }
if (-not $env:OPENCLAW_INSTALL_ARCHIVE_URL) { $env:OPENCLAW_INSTALL_ARCHIVE_URL = '__DIST_ZIP_URL__' }
irm __DIST_SOURCE_PS1_URL__ | iex
EOF
python3 - <<PY2
from pathlib import Path
path = Path(r"$DIST_DIR/bootstrap/remote-install.ps1")
text = path.read_text()
text = text.replace('__DIST_ZIP_URL__', 'https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/releases/${ARCHIVE_BASENAME}.zip')
text = text.replace('__DIST_SOURCE_PS1_URL__', 'https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/bootstrap/source-remote-install.ps1')
path.write_text(text)
PY2

cp "$REPO_ROOT/bootstrap/remote-install.sh" "$DIST_DIR/bootstrap/source-remote-install.sh"
cp "$REPO_ROOT/bootstrap/remote-install.ps1" "$DIST_DIR/bootstrap/source-remote-install.ps1"

cat > "$DIST_DIR/manifest.json" <<EOF
{
  "name": "openclaw-remote-installer-public",
  "version": "0.2.1",
  "source_repo": "${DIST_REPO}",
  "dist_branch": "${DIST_BRANCH}",
  "bootstrap": {
    "macos": "https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/bootstrap/remote-install.sh",
    "windows": "https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/bootstrap/remote-install.ps1"
  },
  "archives": {
    "tar_gz": "https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/releases/${ARCHIVE_BASENAME}.tar.gz",
    "zip": "https://raw.githubusercontent.com/${DIST_REPO}/${DIST_BRANCH}/releases/${ARCHIVE_BASENAME}.zip"
  }
}
EOF

echo "Public dist prepared at: $DIST_DIR"
