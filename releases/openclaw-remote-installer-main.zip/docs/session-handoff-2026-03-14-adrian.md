# Hand-off｜2026-03-14｜给 Adrian

## 1. 这份交接的目的

这份文档给 Adrian 用，目的是让他以后可以独立帮 Sam 做下面几件事：

- 通过 AnyDesk 远程给客户的 Mac / Windows 安装 OpenClaw
- 避免再手抄超长命令，减少复制错误
- 遇到安装过程报错时，判断是“真失败”还是“已装好但验收误判失败”
- 知道当前 Windows 和 Mac 的标准命令、恢复方式、注意点
- 知道 Sam 自己 MacBook Air 的 Codex 配置如何复制

---

## 2. 当前最终结论

截至 2026-03-14，当前状态如下：

- macOS 主线：初步验证通过
- Windows 主线：初步验证通过
- 公开安装入口：已更新并已发布
- Windows 安装后后台常驻逻辑：已更新为“隐藏登录项常驻”方向，不再尽量依赖黑色 gateway 窗口一直开着
- 测试机安装 / 恢复脚本生成器：已做好
- Sam 的 Codex 配置打包：已做好，可复制到 MacBook Air

### 关键提交

- 源码仓库：`557d843`
- 公开分发仓库：`8203477`

### 以后统一使用的 public 安装版本

- `?v=8203477`

不要再继续使用更早测试阶段的 `?v=` 值。

---

## 3. 当前标准安装命令

这是 Adrian 连上 AnyDesk 后最应该用的两条安装命令。

### macOS 安装

```bash
curl -fsSL 'https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.sh?v=8203477' | OPENCLAW_KEEP_INSTALLER_WORKDIR='true' OPENCLAW_CUSTOMER_NAME='客户名' OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID='AnyDeskID' OPENCLAW_PROVIDER_API_KEY='你的NVIDIA key' bash
```

### Windows PowerShell 安装

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force; $env:OPENCLAW_KEEP_INSTALLER_WORKDIR='true'; $env:OPENCLAW_CUSTOMER_NAME='客户名'; $env:OPENCLAW_REMOTE_TOOL='anydesk'; $env:OPENCLAW_REMOTE_ID='AnyDeskID'; $env:OPENCLAW_PROVIDER_API_KEY='你的NVIDIA key'; Invoke-RestMethod 'https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main/bootstrap/remote-install.ps1?v=8203477' | Invoke-Expression
```

### 实际只需要改 3 个值

- `客户名`
- `AnyDeskID`
- `你的NVIDIA key`

---

## 4. 当前标准恢复命令

如果机器已经装过 OpenClaw，只是 gateway 掉了、页面连不上、想做轻恢复，不要先清空配置，先用恢复命令。

### macOS 恢复

```bash
openclaw gateway restart || openclaw gateway start; openclaw gateway probe || true; openclaw status; openclaw dashboard --no-open
```

### Windows 恢复

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force; $ErrorActionPreference='Stop'; if (-not (Get-Command openclaw -ErrorAction SilentlyContinue)) { throw 'OpenClaw command not found. Install first.' }; try { openclaw gateway restart | Out-Null } catch { openclaw gateway start | Out-Null }; try { openclaw gateway probe } catch { }; openclaw status; openclaw dashboard --no-open
```

### 什么时候用“安装”，什么时候用“恢复”

- 全新机器：用“安装”
- 已装机器只是服务掉了：用“恢复”
- 已装旧版 Windows，但想切到新版后台常驻逻辑：**重新跑安装命令，不是恢复命令**

---

## 5. 最推荐的交付方式：不要再手改长命令

已经做了脚本生成器，目的是让 Sam 或 Adrian 在自己电脑上先生成 4 个文件，再发到测试机或远程复制，减少手抄出错。

### 生成器位置

- `scripts/generate-test-machine-scripts.sh`

### 用法

```bash
bash '/Users/sam/Documents/New project/openclaw-remote-installer/scripts/generate-test-machine-scripts.sh' --customer-name '客户名' --remote-id 'AnyDeskID'
```

### 生成结果

会生成 4 个文件：

- `install-mac.command`
- `recover-mac.command`
- `install-win.ps1`
- `recover-win.ps1`

默认输出目录：

- `.generated/test-machine-scripts/<客户名>-<anydesk-id>/`

### Sam 当前这台测试机已生成好的文件

目录：

- `/Users/sam/Documents/New project/openclaw-remote-installer/.generated/test-machine-scripts/sam-win-738175205/`

其中包括：

- `/Users/sam/Documents/New project/openclaw-remote-installer/.generated/test-machine-scripts/sam-win-738175205/install-mac.command`
- `/Users/sam/Documents/New project/openclaw-remote-installer/.generated/test-machine-scripts/sam-win-738175205/recover-mac.command`
- `/Users/sam/Documents/New project/openclaw-remote-installer/.generated/test-machine-scripts/sam-win-738175205/install-win.ps1`
- `/Users/sam/Documents/New project/openclaw-remote-installer/.generated/test-machine-scripts/sam-win-738175205/recover-win.ps1`

---

## 6. 这次做过的关键修复

这部分是给 Adrian 理解“为什么现在能用”的。

### 6.1 Windows provider 配置写入方式修过

早期版本里，Windows 安装器在写 provider / model 配置时，命令拆分和写入方式不稳定，导致出现过：

- 参数过多
- JSON5 解析失败
- provider 配置缺字段
- `models.providers.nvidia.models` 校验失败

后面已经改成通过临时 config 文件写入再校验，不再依赖容易出错的拆写过程。

### 6.2 Windows gateway 启动判定修过

早期 Windows 逻辑容易卡在：

- `gateway start` 已经执行了
- OpenClaw 实际已经装好了
- 但安装器最后验收判断它“没好”，于是重复跑安装

后面已经修成：

- 优先做 TCP 探活
- browser 检查失败时会重试 / 重启 gateway
- 已装 CLI 时尽量复用，不要每次重新全量安装

### 6.3 Windows 后台常驻逻辑已调整

这是这次最重要的变化之一。

#### 旧情况

- Windows 常常依赖一个黑色 `openclaw-gateway` 窗口
- 如果用户把黑窗关掉，gateway 大概率就停

#### 新情况

安装器现在会在 Windows 上走新的后台转换逻辑：

- 先执行 `openclaw gateway install`
- 再写隐藏启动器 `gateway-hidden.vbs`
- 再写登录项 `OpenClaw Gateway.cmd`
- 用登录项隐藏启动 gateway
- 尽量不再要求用户保留黑色窗口一直开着

### 6.4 “明明装好了却显示失败”的误判已做缓解

Sam 在真实 Windows 测试机上已经确认过：

- `openclaw` 实际已经装进去了
- token 配完后能连上 dashboard
- 模型也能跑

这说明有些失败并不是“没装上”，而是安装器最后的验收 / 常驻判定没过。

因此后来又做了两层缓解：

1. 安装器侧继续修常驻和健康检查逻辑
2. 测试机脚本侧，即使安装器报错，只要 `openclaw` 命令已经可用，仍继续跑：
   - `openclaw gateway restart`
   - `openclaw gateway probe`
   - `openclaw status`
   - `openclaw dashboard --no-open`

这样能更快判断“是真失败还是误判”。

---

## 7. 这次新增 / 修改的关键文件

### 已修改

- `README.md`
- `install/common.ps1`
- `install/apply-worker-template.ps1`

### 已新增

- `install/configure-windows-background-gateway.ps1`
- `scripts/generate-test-machine-scripts.sh`
- `docs/test-machine-script-generator.md`
- `docs/session-handoff-2026-03-14-adrian.md`

### 与本次修复直接相关的代码逻辑

- Windows 默认打开后台常驻开关：`install/common.ps1`
- Windows daemon 安装后改走隐藏后台转换：`install/apply-worker-template.ps1`
- Windows 隐藏登录项常驻实现：`install/configure-windows-background-gateway.ps1`
- 测试机四文件生成器：`scripts/generate-test-machine-scripts.sh`

---

## 8. Adrian 实际操作 SOP

这是 Adrian 以后最应该照着做的流程。

### 场景 A：全新机器安装 OpenClaw

1. 先收集 3 个值：
   - 客户名
   - AnyDesk ID
   - NVIDIA key
2. 推荐先在本机生成脚本：
   - 跑 `generate-test-machine-scripts.sh`
3. 远程连 AnyDesk
4. Mac 就贴 Mac 安装命令，Windows 就贴 Windows 安装命令
5. 安装结束后检查：
   - `openclaw status`
   - `openclaw dashboard --no-open`
6. 如果安装器报错，但 `openclaw` 已存在，不要立刻判死刑，先跑恢复命令再看状态

### 场景 B：已装机器掉服务

1. 不要先删 `~/.openclaw`
2. 直接跑恢复命令
3. 看 `openclaw status`
4. 如仍失败，再看本地诊断目录

### 场景 C：已装旧版 Windows，要切到新版后台常驻

1. 不要只跑恢复命令
2. 直接重新跑最新版 Windows 安装命令
3. 安装成功后再看 `openclaw status`
4. 重点确认不再依赖黑色窗口持续存在

---

## 9. 真实排错过程中遇到过的坑

这一段很重要，Adrian 以后看到类似错误可以少走弯路。

### 坑 1：把 PowerShell 提示符和报错文本又粘回终端

用户曾把下面这些也粘回去了：

- `PS C:\Users\Sam>`
- `>>`
- `CategoryInfo`
- `FullyQualifiedErrorId`
- 中文报错正文

这样会导致一堆“找不到命令”“语法错误”，但这些不是安装器真正的问题。

#### 正确做法

只粘一整条真正的命令，不要把提示符和报错文本也贴进去。

### 坑 2：Windows 刚装完 Node / Git，但当前 PowerShell 会话找不到

之前出现过：

- `node` not found

这是因为安装器前面还在装 Node.js，当前会话 PATH 可能没刷新，和后续真正安装失败不一定是同一个问题。

### 坑 3：本地 Mac 的 `~/.openclaw/openclaw.json` 损坏

Sam 的本地 Mac 上曾出现过：

- `JSON5: invalid end of input at 1:1`

这说明本地 `~/.openclaw/openclaw.json` 为空或损坏。

这个问题属于 **本地 Mac 的 OpenClaw 配置损坏**，和远程 Windows 测试机安装链不是同一个问题，不能混在一起判断。

### 坑 4：出现 `gateway closed (1006 abnormal closure)`

这个错误在 Windows 测试链里出现过，说明 browser / gateway 的第一轮验收没有通过，不代表 OpenClaw 本体一定没装上。

### 坑 5：安装器一直重复 `npm install -g openclaw`

这个也是前期验收逻辑太苛刻造成的副作用。后来已经通过复用已装 CLI、放宽健康检查、改后台常驻逻辑做了缓解。

---

## 10. 什么时候需要看诊断目录

如果重新安装和恢复都失败，再看这个目录：

### Windows

- `C:\Users\<用户名>\.openclaw\installer-runtime\diagnostics\`

### macOS

- `~/.openclaw/installer-runtime/diagnostics/`

优先找最新时间的 attempt 目录。

---

## 11. 现在给客户 / 测试机交付时的建议话术

Adrian 可以直接按这个意思说：

- 我会先连 AnyDesk
- 我只需要你的 AnyDesk ID 和这台机器的标识名称
- 安装命令现在已经固定，Mac 和 Windows 各一条
- 如果中途看到安装器报错，我会先检查 `openclaw` 是否已实际装好，不会立刻把它判成失败
- Windows 新版逻辑会尽量改成后台隐藏常驻，不再要求一直留着黑色窗口

---

## 12. Sam 的 Codex 配置复制（给 MacBook Air）

除了 OpenClaw 安装链，这次还做了一份 Sam 自己的 Codex 配置复制包。

### 配置包位置

- 目录：`/Users/sam/Documents/New project/.generated/codex-macbook-air-exact/`
- 压缩包：`/Users/sam/Documents/New project/.generated/codex-macbook-air-exact.tar.gz`

### 包里包含

- `config.toml`
- `AGENTS.md`
- `memory.md`
- `config.model.5.3.toml`
- `config.model.5.4.toml`
- `skills/`
- `automations/`
- `install-codex-profile.sh`

### 包里不包含

- `auth.json`
- `state_5.sqlite`
- `history.jsonl`
- `sessions/`
- `shell snapshots`
- `models cache`

### 为什么不包含 `auth.json`

因为它是登录凭据，跨机器直接复制有安全风险。

### 正确使用方法

1. 先在新 Mac 上安装 Codex
2. 打开 Codex，登录一次
3. 再应用配置包：

```bash
bash /你的路径/codex-macbook-air-exact/install-codex-profile.sh
```

### 当前 Codex 核心配置

- provider：`sub2api`
- model：`gpt-5.4`
- reasoning：`xhigh`
- verbosity：`high`
- network：`enabled`
- response storage：关闭

### 注意

如果新机器用户名不是 `sam`，需要改路径相关配置：

- `config.toml`
- `automations/*/automation.toml`

---

## 13. Adrian 以后最省力的做法

如果 Adrian 要长期接手这件事，最省力的方式不是每次手拼命令，而是：

1. 先在本机运行脚本生成器
2. 生成 Mac / Windows 安装与恢复 4 个文件
3. 连 AnyDesk 后直接复制对应文件里的命令或内容
4. 装完先看 `openclaw status`
5. Windows 若要切新常驻逻辑，直接重跑安装命令

简单说：

- **优先用生成器，不要手抄长命令**
- **优先判断“是否已装好”，不要只看安装器最后一句报错**
- **Windows 新版已往后台隐藏常驻走，不再沿用旧黑窗依赖逻辑**

---

## 14. 交接一句话总结

Sam 这轮已经把 Mac / Windows 的 OpenClaw 远程安装主线初步打通，并把 Windows 常驻逻辑、测试机脚本生成、以及 Sam 自己的 Codex 配置复制包都整理好了。Adrian 以后只需要按本文档的标准命令和 SOP 操作，基本就能独立接手。
