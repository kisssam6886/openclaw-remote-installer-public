# QQ 接入说明（当前非阻塞）

当前 QQ 不再阻塞主安装交付，可以后置处理。

## 当前状态

- 主安装链允许先不接 QQ
- 交付阻塞项以 OpenClaw 安装成功、skills 完整、browser 可用为准
- 如果以后要补 QQ，再单独做连接验证和状态回写

## 现有占位能力

1. 客户机完成 OpenClaw 安装
2. 完成人工 QQ 配置或扫码登录
3. 运行 `bash install/mark-qq-connected.sh <qq账号或标识>`
4. 重新运行 `bash install/worker-first-run.sh`
5. QQ 状态会写入 `~/.openclaw/installer-runtime/status/qq-status.json`

## 说明

QQ 这条线先保留占位，不影响你现在用 AnyDesk 帮客户完成 OpenClaw 安装交付。
