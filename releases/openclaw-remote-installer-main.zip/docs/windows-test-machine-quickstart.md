# Windows 测试机快速开始

## 目标

在正式交付客户前，先在 Windows 测试机验证完整安装链路。

## 步骤

1. 克隆仓库
2. 复制 `.env.example` 为 `.env.local`
3. 填入 `OPENCLAW_PROVIDER_API_KEY`
4. 用管理员权限打开 PowerShell
5. 运行 `powershell -ExecutionPolicy Bypass -File .\bootstrap\windows.ps1`
6. 确认 OpenClaw、gateway、browser 均可用
7. 运行 `powershell -ExecutionPolicy Bypass -File .\install\check-delivery.ps1`
8. 查看 `%USERPROFILE%\.openclaw\installer-runtime\install-summary.json`
9. 如失败，查看 `%USERPROFILE%\.openclaw\installer-runtime\diagnostics\`

## 说明

当前默认模型和 provider 已经是 NVIDIA Kimi K2.5，只要补真实 key 即可。
