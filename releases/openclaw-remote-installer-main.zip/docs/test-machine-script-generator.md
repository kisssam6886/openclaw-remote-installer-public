# 测试机脚本生成器

用于在你自己的电脑上先生成 4 个文件，减少长命令复制出错：

- `install-mac.command`
- `recover-mac.command`
- `install-win.ps1`
- `recover-win.ps1`

## 用法

```bash
bash scripts/generate-test-machine-scripts.sh \
  --customer-name 'win-clean-test' \
  --remote-id '738175205'
```

如果你想把 NVIDIA key 直接写进脚本：

```bash
bash scripts/generate-test-machine-scripts.sh \
  --customer-name 'win-clean-test' \
  --remote-id '738175205' \
  --include-provider-key \
  --provider-api-key '你的NVIDIA key'
```

## 输出位置

默认输出到：

- `.generated/test-machine-scripts/<客户名>-<anydesk-id>/`

## 说明

- 安装脚本默认带 `OPENCLAW_KEEP_INSTALLER_WORKDIR='true'`，方便你做恢复测试。
- Windows 安装脚本在安装器报错但 `openclaw` 已经可用时，会继续跑 `gateway restart/probe/status`，减少“明明装上了却卡在失败”的误判。
- 新版 Windows 安装链会把 gateway 切成隐藏登录项常驻，目标是不再要求你一直保留黑色 `openclaw-gateway` 窗口。
- 恢复脚本是轻恢复入口，不会先清空 `~/.openclaw`。
