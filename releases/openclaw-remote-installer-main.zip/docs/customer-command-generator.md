# 客户交付命令生成器

## 作用

这个脚本用于你在自己电脑上先生成“客户交付版安装命令”。

你只要输入：

- 客户名称
- AnyDesk ID

它就会自动生成：

- Mac 可复制命令
- Windows 可复制命令
- 一份保存到本地的命令文档

生成器脚本本身在这里：

- `scripts/generate-customer-command.sh`

---

## 最简单用法

在源码仓库根目录运行：

```bash
bash scripts/generate-customer-command.sh
```

然后按提示输入：

- 客户名称
- AnyDesk ID
- 是否把 NVIDIA key 直接写进命令

---

## 直接带参数生成

```bash
bash scripts/generate-customer-command.sh \
  --customer-name '客户名称' \
  --remote-id '123456789'
```

如果你想连 NVIDIA key 一起写进去：

```bash
bash scripts/generate-customer-command.sh \
  --customer-name '客户名称' \
  --remote-id '123456789' \
  --include-provider-key \
  --provider-api-key '你的NVIDIA key'
```

如果你只想生成 Mac 命令：

```bash
bash scripts/generate-customer-command.sh \
  --customer-name '客户名称' \
  --remote-id '123456789' \
  --platform mac
```

如果你只想生成 Windows 命令：

```bash
bash scripts/generate-customer-command.sh \
  --customer-name '客户名称' \
  --remote-id '123456789' \
  --platform windows
```

---

## 生成结果在哪里

默认输出到：

- `.generated/customer-delivery-commands/`

脚本运行后会告诉你具体文件路径。

---

## 是否建议把 NVIDIA key 直接写进命令

建议分两种情况：

- 你自己临时远程安装，当场复制粘贴：可以
- 你要把命令发给别人、发群、发工单：不建议

因为一旦写进命令，容易进入：

- 聊天记录
- 命令历史
- 截图
- 日志

所以默认我让脚本先生成“带占位符”的版本，更稳。

---

## AnyDesk 密码要不要写进命令

不要。

命令里只建议出现：

- `OPENCLAW_REMOTE_TOOL='anydesk'`
- `OPENCLAW_REMOTE_ID='客户AnyDeskID'`

AnyDesk 密码不要进入：

- 命令
- 文档
- registry
- GitHub
- 诊断包
