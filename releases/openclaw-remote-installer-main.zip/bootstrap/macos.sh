#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
NODE_MIN_MAJOR="22"
NODE_LTS_MAJOR="24"
NODE_INSTALL_TMP_DIR="${TMPDIR:-/tmp}/openclaw-node-installer"

install_node_from_official_pkg() {
  local latest_dir_url="https://nodejs.org/dist/latest-v${NODE_LTS_MAJOR}.x/"
  local pkg_url
  local pkg_file

  echo "Homebrew 安装 Node.js 失败，开始尝试 Node.js 官方安装包..."

  pkg_url="$(curl -fsSL "$latest_dir_url" | tr '"' '\n' | sed -n 's#^\(node-v[0-9][^ ]*\.pkg\)$#'"$latest_dir_url"'\1#p' | sed -n '1p')"
  if [ -z "$pkg_url" ]; then
    echo "无法解析 Node.js 官方 pkg 下载地址：$latest_dir_url"
    return 1
  fi

  mkdir -p "$NODE_INSTALL_TMP_DIR"
  pkg_file="$NODE_INSTALL_TMP_DIR/$(basename "$pkg_url")"

  echo "Downloading: $pkg_url"
  curl -fsSL "$pkg_url" -o "$pkg_file"

  echo "Installing official Node.js pkg..."
  sudo installer -pkg "$pkg_file" -target /
}

ensure_node_ready() {
  local node_major

  if command -v node >/dev/null 2>&1; then
    node_major="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || echo 0)"
    if [ -n "$node_major" ] && [ "$node_major" -ge "$NODE_MIN_MAJOR" ]; then
      return 0
    fi
  fi

  if ! command -v brew >/dev/null 2>&1; then
    echo "Homebrew not found. Please install Homebrew first: https://brew.sh/"
    exit 1
  fi

  if brew install node; then
    return 0
  fi

  install_node_from_official_pkg
}

echo "[OpenClaw Installer] macOS bootstrap starting..."

echo "[1/4] Checking Homebrew"
if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew not found. Please install Homebrew first: https://brew.sh/"
  exit 1
fi

echo "[2/4] Checking Git"
if ! command -v git >/dev/null 2>&1; then
  brew install git
fi

echo "[3/4] Checking Node.js"
ensure_node_ready

NODE_MAJOR="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || echo 0)"
if [ -z "$NODE_MAJOR" ] || [ "$NODE_MAJOR" -lt "$NODE_MIN_MAJOR" ]; then
  echo "Node.js ${NODE_MIN_MAJOR}+ is required by OpenClaw. Current: $(node -v 2>/dev/null || echo missing)"
  echo "Please fix Node.js, then re-run bootstrap/macos.sh"
  exit 1
fi

echo "[4/4] Run OpenClaw install runner"
bash "$REPO_ROOT/install/install-runner.sh"

echo "Bootstrap complete."
