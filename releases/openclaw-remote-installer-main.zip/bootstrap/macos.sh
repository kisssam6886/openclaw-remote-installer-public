#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "[OpenClaw Installer] macOS bootstrap starting..."

echo "[1/4] Checking Homebrew"
if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew not found. Please install Homebrew first: https://brew.sh/"
  exit 1
fi

echo "[2/4] Checking Git"
if ! command -v git >/dev/null 2>&1; then
  brew install git
fi

echo "[3/4] Checking Node.js"
if ! command -v node >/dev/null 2>&1; then
  brew install node
fi

NODE_MAJOR="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || echo 0)"
if [ -z "$NODE_MAJOR" ] || [ "$NODE_MAJOR" -lt 22 ]; then
  echo "Node.js 22+ is required by OpenClaw. Current: $(node -v 2>/dev/null || echo missing)"
  echo "Please upgrade Node.js, then re-run bootstrap/macos.sh"
  exit 1
fi

echo "[4/4] Run OpenClaw install runner"
bash "$REPO_ROOT/install/install-runner.sh"

echo "Bootstrap complete."
