$ErrorActionPreference = 'Stop'

$psMajor = 2
if ($PSVersionTable -and $PSVersionTable.PSVersion) { $psMajor = [int]$PSVersionTable.PSVersion.Major }
if ($psMajor -lt 5) { throw "Windows PowerShell 5.1+ or PowerShell 7 is required. Detected major version: $psMajor" }

$RepoRoot = Split-Path -Parent $PSScriptRoot

function Refresh-ProcessPath {
    $parts = @()

    foreach ($scope in 'Machine', 'User') {
        $value = [Environment]::GetEnvironmentVariable('Path', $scope)
        if ($value) {
            $parts += ($value -split ';')
        }
    }

    if ($env:Path) {
        $parts += ($env:Path -split ';')
    }

    $env:Path = (($parts | Where-Object { $_ } | Select-Object -Unique) -join ';')
}

function Find-Executable {
    param([string[]]$Candidates)

    foreach ($candidate in $Candidates) {
        if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path $candidate)) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

function Ensure-CommandReady {
    param(
        [string]$CommandName,
        [string[]]$Candidates
    )

    $command = Get-Command $CommandName -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }

    Refresh-ProcessPath
    $command = Get-Command $CommandName -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }

    $found = Find-Executable -Candidates $Candidates
    if ($found) {
        $env:Path = ((Split-Path -Parent $found), $env:Path) -join ';'
        return $found
    }

    return $null
}

Write-Host '[OpenClaw Installer] Windows bootstrap starting...'

Write-Host '[1/4] Check Git'
$gitPath = Ensure-CommandReady -CommandName 'git' -Candidates @(
    (Join-Path $env:ProgramFiles 'Git\cmd\git.exe'),
    (Join-Path $env:ProgramFiles 'Git\bin\git.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Git\cmd\git.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Git\bin\git.exe')
)
if (-not $gitPath) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        & winget install --id Git.Git -e --source winget --accept-package-agreements --accept-source-agreements
        $gitPath = Ensure-CommandReady -CommandName 'git' -Candidates @(
            (Join-Path $env:ProgramFiles 'Git\cmd\git.exe'),
            (Join-Path $env:ProgramFiles 'Git\bin\git.exe'),
            (Join-Path ${env:ProgramFiles(x86)} 'Git\cmd\git.exe'),
            (Join-Path ${env:ProgramFiles(x86)} 'Git\bin\git.exe')
        )
    }

    if (-not $gitPath) {
        throw 'Git not found after install attempt. Please install Git first.'
    }
}

Write-Host '[2/4] Check Node.js'
$nodeCandidates = @(
    (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'nodejs\node.exe'),
    (Join-Path $env:LOCALAPPDATA 'Programs\nodejs\node.exe')
)
$nodePath = Ensure-CommandReady -CommandName 'node' -Candidates $nodeCandidates
if (-not $nodePath) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        & winget install --id OpenJS.NodeJS -e --source winget --accept-package-agreements --accept-source-agreements
        $nodePath = Ensure-CommandReady -CommandName 'node' -Candidates $nodeCandidates
    }

    if (-not $nodePath) {
        throw 'Node.js not found after install attempt. Please install Node.js 22+ first.'
    }
}

$nodeVersion = (& $nodePath --version)
$nodeMajor = [int](($nodeVersion -replace '^v', '').Split('.')[0])
if ($nodeMajor -lt 22) {
    throw "Node.js 22+ is required by OpenClaw. Current: $nodeVersion"
}

Write-Host '[3/4] Run OpenClaw install runner'
& (Join-Path $RepoRoot 'install/install-runner.ps1')

Write-Host '[4/4] Bootstrap complete.'
