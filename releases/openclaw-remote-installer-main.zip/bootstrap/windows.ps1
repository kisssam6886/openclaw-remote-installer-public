$ErrorActionPreference = 'Stop'

$RepoRoot = Split-Path -Parent $PSScriptRoot

Write-Host '[OpenClaw Installer] Windows bootstrap starting...'

Write-Host '[1/4] Check Git'
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        & winget install --id Git.Git -e --source winget --accept-package-agreements --accept-source-agreements
    }
    else {
        throw 'Git not found. Please install Git first.'
    }
}

Write-Host '[2/4] Check Node.js'
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        & winget install --id OpenJS.NodeJS -e --source winget --accept-package-agreements --accept-source-agreements
    }
    else {
        throw 'Node.js not found. Please install Node.js 22+ first.'
    }
}

$nodeVersion = (& node --version)
$nodeMajor = [int](($nodeVersion -replace '^v', '').Split('.')[0])
if ($nodeMajor -lt 22) {
    throw "Node.js 22+ is required by OpenClaw. Current: $nodeVersion"
}

Write-Host '[3/4] Run OpenClaw install runner'
& (Join-Path $RepoRoot 'install/install-runner.ps1')

Write-Host '[4/4] Bootstrap complete.'
