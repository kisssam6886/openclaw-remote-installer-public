$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$targetDir = $env:OPENCLAW_RUNTIME_DIR
Ensure-Directory -Path $targetDir
Ensure-Directory -Path (Join-Path $targetDir 'backups')
Ensure-Directory -Path (Join-Path $targetDir 'workspace')

Write-Host '[Installer] applying worker template...'

$sourceTemplate = Join-Path $script:RepoRoot 'templates/worker-agent-template.yaml'
$targetTemplate = Join-Path $targetDir 'worker-agent.yaml'
$configFile = Get-OpenClawConfigFile
$configDir = Split-Path -Parent $configFile
$backupFile = $null
$gatewayInstalled = $false
$providerConfigured = $false
$workConfig = Join-Path $targetDir ('openclaw.config.work.{0}.json' -f $PID)
$stagedConfig = Join-Path $configDir ('.openclaw.installer-staged.{0}.json' -f $PID)

try {
    if (-not (Test-Path $sourceTemplate)) { throw 'worker template missing' }
    Copy-Item -Path $sourceTemplate -Destination $targetTemplate -Force
    Ensure-Directory -Path $configDir

    if (-not (Get-InstallerOpenClawCommand)) {
        throw 'OpenClaw CLI missing. Cannot apply runtime config.'
    }

    if ((Test-Path $configFile) -and ((Get-Item $configFile).Length -gt 0)) {
        $backupFile = Join-Path $targetDir ("backups/openclaw.json.{0}.bak" -f (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ'))
        Copy-Item -Path $configFile -Destination $backupFile -Force
        Copy-Item -Path $configFile -Destination $workConfig -Force
    }
    else {
        Set-Content -Path $workConfig -Value '{}' -Encoding utf8
    }

    $nodeExecutable = if ($env:OPENCLAW_NODE_EXE) { $env:OPENCLAW_NODE_EXE } else { 'node' }
    $mutatorScript = Join-Path $targetDir ('apply-worker-template.{0}.cjs' -f $PID)
    $workspaceDir = Join-Path $env:OPENCLAW_RUNTIME_DIR 'workspace'
    $systemTimezone = (Get-TimeZone).Id

    $hadWorkConfigEnv = Test-Path Env:OPENCLAW_WORK_CONFIG
    $previousWorkConfigEnv = $env:OPENCLAW_WORK_CONFIG
    $hadWorkspaceDirEnv = Test-Path Env:OPENCLAW_WORKSPACE_DIR
    $previousWorkspaceDirEnv = $env:OPENCLAW_WORKSPACE_DIR
    $hadSystemTimezoneEnv = Test-Path Env:OPENCLAW_SYSTEM_TIMEZONE
    $previousSystemTimezoneEnv = $env:OPENCLAW_SYSTEM_TIMEZONE

    $env:OPENCLAW_WORK_CONFIG = $workConfig
    $env:OPENCLAW_WORKSPACE_DIR = $workspaceDir
    $env:OPENCLAW_SYSTEM_TIMEZONE = $systemTimezone

    @'
const fs = require("fs");
const configPath = process.env.OPENCLAW_WORK_CONFIG;
if (!configPath) {
  throw new Error("OPENCLAW_WORK_CONFIG is not set");
}
let raw = "{}";
if (fs.existsSync(configPath)) {
  raw = fs.readFileSync(configPath, "utf8");
}
const text = String(raw || "").trim();
let cfg = {};
if (text) {
  try {
    cfg = JSON.parse(text);
  } catch (error) {
    throw new Error(`Failed to parse work config as JSON: ${error.message}`);
  }
}
const ensureObject = (parent, key) => {
  if (!parent[key] || typeof parent[key] !== "object" || Array.isArray(parent[key])) {
    parent[key] = {};
  }
  return parent[key];
};
const gateway = ensureObject(cfg, "gateway");
gateway.mode = "local";
const browser = ensureObject(cfg, "browser");
browser.enabled = true;
browser.evaluateEnabled = true;
browser.defaultProfile = "openclaw";
const skills = ensureObject(cfg, "skills");
const skillsInstall = ensureObject(skills, "install");
skillsInstall.preferBrew = true;
skillsInstall.nodeManager = "npm";
const agents = ensureObject(cfg, "agents");
const defaults = ensureObject(agents, "defaults");
defaults.userTimezone = process.env.OPENCLAW_SYSTEM_TIMEZONE || "UTC";
defaults.workspace = process.env.OPENCLAW_WORKSPACE_DIR || "";
const defaultModel = ensureObject(defaults, "model");
defaultModel.primary = process.env.OPENCLAW_WORKER_MODEL || "";
if ((process.env.OPENCLAW_REQUIRE_PROVIDER_CONFIG || "").toLowerCase() === "true") {
  const providerId = process.env.OPENCLAW_PROVIDER_ID;
  const apiKeyName = process.env.OPENCLAW_PROVIDER_API_KEY_NAME;
  const providerBaseUrl = process.env.OPENCLAW_PROVIDER_BASE_URL;
  const providerApi = process.env.OPENCLAW_PROVIDER_API_COMPAT;
  const providerModelId = process.env.OPENCLAW_PROVIDER_MODEL_ID;
  const providerDisplayName = process.env.OPENCLAW_PROVIDER_DISPLAY_NAME;
  const providerApiKey = process.env.OPENCLAW_PROVIDER_API_KEY;
  if (!providerId || !apiKeyName || !providerBaseUrl || !providerApi || !providerModelId || !providerDisplayName || !providerApiKey) {
    throw new Error("Provider config env missing");
  }
  const env = ensureObject(cfg, "env");
  env[apiKeyName] = providerApiKey;
  const models = ensureObject(cfg, "models");
  models.mode = "merge";
  const providers = ensureObject(models, "providers");
  providers[providerId] = {
    baseUrl: providerBaseUrl,
    api: providerApi,
    apiKey: '${' + apiKeyName + '}',
    models: [
      {
        id: providerModelId,
        name: providerDisplayName
      }
    ]
  };
}
fs.writeFileSync(configPath, JSON.stringify(cfg, null, 2));
'@ | Set-Content -Path $mutatorScript -Encoding utf8

    try {
        & $nodeExecutable $mutatorScript | Out-Null
    }
    finally {
        if ($hadWorkConfigEnv) { $env:OPENCLAW_WORK_CONFIG = $previousWorkConfigEnv } else { Remove-Item Env:OPENCLAW_WORK_CONFIG -ErrorAction SilentlyContinue }
        if ($hadWorkspaceDirEnv) { $env:OPENCLAW_WORKSPACE_DIR = $previousWorkspaceDirEnv } else { Remove-Item Env:OPENCLAW_WORKSPACE_DIR -ErrorAction SilentlyContinue }
        if ($hadSystemTimezoneEnv) { $env:OPENCLAW_SYSTEM_TIMEZONE = $previousSystemTimezoneEnv } else { Remove-Item Env:OPENCLAW_SYSTEM_TIMEZONE -ErrorAction SilentlyContinue }
        Remove-Item -Path $mutatorScript -Force -ErrorAction SilentlyContinue
    }

    if ($env:OPENCLAW_REQUIRE_PROVIDER_CONFIG -eq 'true') {
        $providerConfigured = $true
    }

    Invoke-InstallerOpenClaw -ConfigPath $workConfig -Arguments @('config', 'validate') | Out-Null

    Copy-Item -Path $workConfig -Destination $stagedConfig -Force
    Move-Item -Path $stagedConfig -Destination $configFile -Force

    try {
        Invoke-InstallerOpenClaw -ConfigPath $configFile -Arguments @('config', 'validate') | Out-Null
    }
    catch {
        if ($backupFile) {
            Copy-Item -Path $backupFile -Destination $configFile -Force
        }
        elseif (Test-Path $configFile) {
            Remove-Item -Path $configFile -Force
        }

        throw 'Committed OpenClaw config failed validation and was rolled back.'
    }

    if ($env:OPENCLAW_INSTALL_DAEMON -eq 'true') {
        Invoke-InstallerOpenClaw -ConfigPath $configFile -Arguments @('gateway', 'install') | Out-Null

        $gatewayReady = Test-InstallerGatewayReady -ConfigPath $configFile
        if (-not $gatewayReady) {
            $timeoutSeconds = 45
            if ($env:OPENCLAW_GATEWAY_START_TIMEOUT_SECONDS -match '^[0-9]+$') {
                $timeoutSeconds = [int]$env:OPENCLAW_GATEWAY_START_TIMEOUT_SECONDS
            }

            $gatewayStartProcess = Start-InstallerOpenClawDetached -ConfigPath $configFile -Arguments @('gateway', 'start')
            if (-not (Wait-InstallerGatewayReady -ConfigPath $configFile -TimeoutSeconds $timeoutSeconds)) {
                if ($gatewayStartProcess -and -not $gatewayStartProcess.HasExited) {
                    Stop-Process -Id $gatewayStartProcess.Id -Force -ErrorAction SilentlyContinue
                }
                throw "OpenClaw gateway start did not report ready within $timeoutSeconds seconds."
            }
        }

        $gatewayInstalled = $true
    }

    Write-JsonFile -Path (Join-Path $targetDir 'applied-worker-config.json') -Object @{
        applied_at                = Get-TimestampUtc
        config_file               = $configFile
        template_file             = $targetTemplate
        worker_model              = $env:OPENCLAW_WORKER_MODEL
        worker_model_source       = 'installer'
        provider_id               = $env:OPENCLAW_PROVIDER_ID
        provider_model_id         = $env:OPENCLAW_PROVIDER_MODEL_ID
        provider_base_url         = $env:OPENCLAW_PROVIDER_BASE_URL
        provider_configured       = $providerConfigured
        browser_enabled           = $true
        gateway_service_installed = $gatewayInstalled
        skills_dir                = $env:OPENCLAW_SHARED_SKILLS_DIR
        installer_env_file        = $env:OPENCLAW_INSTALLER_ENV_FILE
        backup_file               = $backupFile
    }

    Write-Host "Worker template written to: $targetTemplate"
    Write-Host "OpenClaw config applied to: $configFile"
}
finally {
    Remove-Item -Path $workConfig -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $stagedConfig -Force -ErrorAction SilentlyContinue
}
