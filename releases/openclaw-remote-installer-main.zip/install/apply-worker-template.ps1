$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$targetDir = $env:OPENCLAW_RUNTIME_DIR
Ensure-Directory -Path $targetDir
Ensure-Directory -Path (Join-Path $targetDir 'backups')
Ensure-Directory -Path (Join-Path $targetDir 'workspace')

Write-Host '[Installer] applying worker template...'

$sourceTemplate = Join-Path $script:RepoRoot 'templates/worker-agent-template.yaml'
$targetTemplate = Join-Path $targetDir 'worker-agent.yaml'
$configFile = Get-OpenClawConfigFile
$configDir = Split-Path -Parent $configFile
$backupFile = $null
$gatewayInstalled = $false
$providerConfigured = $false

if (-not (Test-Path $sourceTemplate)) { throw 'worker template missing' }
Copy-Item -Path $sourceTemplate -Destination $targetTemplate -Force
Ensure-Directory -Path $configDir

if (-not (Get-Command openclaw -ErrorAction SilentlyContinue)) {
    throw 'OpenClaw CLI missing. Cannot apply runtime config.'
}

if (Test-Path $configFile) {
    $backupFile = Join-Path $targetDir ("backups/openclaw.json.{0}.bak" -f (Get-Date -Format 'yyyyMMddTHHmmssZ'))
    Copy-Item -Path $configFile -Destination $backupFile -Force
}

& openclaw config set gateway.mode local | Out-Null
& openclaw config set --strict-json browser ((@{ enabled = $true; evaluateEnabled = $true; defaultProfile = 'openclaw' } | ConvertTo-Json -Compress)) | Out-Null
& openclaw config set --strict-json skills.install ((@{ preferBrew = $true; nodeManager = 'npm' } | ConvertTo-Json -Compress)) | Out-Null
& openclaw config set agents.defaults.userTimezone ((Get-TimeZone).Id | ConvertTo-JsonLiteral) | Out-Null
& openclaw config set agents.defaults.workspace ($env:OPENCLAW_RUNTIME_DIR + '/workspace' | ConvertTo-JsonLiteral) | Out-Null

if ($env:OPENCLAW_REQUIRE_PROVIDER_CONFIG -eq 'true') {
    if (-not $env:OPENCLAW_PROVIDER_ID -or -not $env:OPENCLAW_PROVIDER_BASE_URL -or -not $env:OPENCLAW_PROVIDER_API_KEY -or -not $env:OPENCLAW_PROVIDER_MODEL_ID) {
        throw 'Custom provider config missing. Copy .env.example to .env.local and fill OPENCLAW_PROVIDER_BASE_URL / OPENCLAW_PROVIDER_API_KEY first.'
    }

    & openclaw config set ("env.{0}" -f $env:OPENCLAW_PROVIDER_API_KEY_NAME) ($env:OPENCLAW_PROVIDER_API_KEY | ConvertTo-JsonLiteral) | Out-Null

    $providerConfig = @{
        baseUrl = $env:OPENCLAW_PROVIDER_BASE_URL
        api     = $env:OPENCLAW_PROVIDER_API_COMPAT
        apiKey  = "`${$($env:OPENCLAW_PROVIDER_API_KEY_NAME)}"
        models  = @(@{ id = $env:OPENCLAW_PROVIDER_MODEL_ID; name = $env:OPENCLAW_PROVIDER_DISPLAY_NAME })
    }

    & openclaw config set --strict-json ("models.providers.{0}" -f $env:OPENCLAW_PROVIDER_ID) ($providerConfig | ConvertTo-Json -Compress -Depth 10) | Out-Null
    & openclaw config set models.mode merge | Out-Null
    $providerConfigured = $true
}

& openclaw config set --strict-json agents.defaults.model ((@{ primary = $env:OPENCLAW_WORKER_MODEL } | ConvertTo-Json -Compress)) | Out-Null

try {
    & openclaw config validate | Out-Null
}
catch {
    if ($backupFile) {
        Copy-Item -Path $backupFile -Destination $configFile -Force
    }
    elseif (Test-Path $configFile) {
        Remove-Item -Path $configFile -Force
    }

    throw 'Applied OpenClaw config failed validation and was rolled back.'
}

if ($env:OPENCLAW_INSTALL_DAEMON -eq 'true') {
    & openclaw gateway install | Out-Null
    & openclaw gateway start | Out-Null
    $gatewayInstalled = $true
}

Write-JsonFile -Path (Join-Path $targetDir 'applied-worker-config.json') -Object @{
    applied_at                = Get-TimestampUtc
    config_file               = $configFile
    template_file             = $targetTemplate
    worker_model              = $env:OPENCLAW_WORKER_MODEL
    worker_model_source       = 'installer'
    provider_id               = $env:OPENCLAW_PROVIDER_ID
    provider_model_id         = $env:OPENCLAW_PROVIDER_MODEL_ID
    provider_base_url         = $env:OPENCLAW_PROVIDER_BASE_URL
    provider_configured       = $providerConfigured
    browser_enabled           = $true
    gateway_service_installed = $gatewayInstalled
    skills_dir                = $env:OPENCLAW_SHARED_SKILLS_DIR
    installer_env_file        = $env:OPENCLAW_INSTALLER_ENV_FILE
    backup_file               = $backupFile
}

Write-Host "Worker template written to: $targetTemplate"
Write-Host "OpenClaw config applied to: $configFile"
