#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

echo "[Installer] OpenClaw install starting..."

if ! command -v npm >/dev/null 2>&1; then
  echo "npm not found. Please install Node.js first."
  exit 1
fi

echo "[1/5] Install or update OpenClaw CLI"
npm install -g openclaw || {
  echo "Global install failed. Placeholder for fallback install path."
  exit 1
}

echo "[2/5] Verify OpenClaw command"
openclaw --version

echo "[3/5] Install required skills"
bash "$REPO_ROOT/install/install-required-skills.sh"

echo "[4/5] Prepare installer runtime directories"
ensure_dir "$OPENCLAW_RUNTIME_DIR"
ensure_dir "$OPENCLAW_REGISTRY_DIR"

echo "[5/5] Continue to worker handoff"
bash "$REPO_ROOT/install/handoff-to-worker.sh"

echo "[Installer] OpenClaw install complete."
