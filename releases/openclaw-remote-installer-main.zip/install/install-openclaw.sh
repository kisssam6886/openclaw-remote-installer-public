#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

echo "[Installer] OpenClaw install starting..."

if ! command -v npm >/dev/null 2>&1; then
  echo "npm not found. Please install Node.js first."
  exit 1
fi

echo "[1/6] Install or update OpenClaw CLI"
if [ "${OPENCLAW_FORCE_CLI_INSTALL:-false}" = "true" ]; then
  OPENCLAW_SKIP_CLI_INSTALL=false
elif command -v openclaw >/dev/null 2>&1 && openclaw --version >/dev/null 2>&1; then
  OPENCLAW_SKIP_CLI_INSTALL=true
  echo "[Installer] OpenClaw CLI already available; skipping reinstall."
else
  OPENCLAW_SKIP_CLI_INSTALL=false
fi

if [ "$OPENCLAW_SKIP_CLI_INSTALL" != "true" ]; then
  npm install -g openclaw || {
    echo "Global install failed. Placeholder for fallback install path."
    exit 1
  }
fi

echo "[2/6] Verify OpenClaw command"
openclaw --version

OPENCLAW_REAL_BIN="$(detect_openclaw_real_bin || true)"
if ! ensure_openclaw_command_available "$OPENCLAW_REAL_BIN"; then
  echo "Failed to prepare a stable OpenClaw command on this machine."
  exit 1
fi

echo "If current zsh still says 'command not found' after install, run: rehash"

echo "[3/6] Install required skills"
bash "$REPO_ROOT/install/install-required-skills.sh"

echo "[4/6] Prepare installer runtime directories"
ensure_dir "$OPENCLAW_RUNTIME_DIR"
ensure_dir "$OPENCLAW_REGISTRY_DIR"

echo "[5/6] Continue to worker handoff"
bash "$REPO_ROOT/install/handoff-to-worker.sh"

echo "[6/6] Run post-install actions"
bash "$REPO_ROOT/install/post-install-actions.sh" || true

echo "[Installer] OpenClaw install complete."
