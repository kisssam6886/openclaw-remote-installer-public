#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

REPAIR_LOG="$OPENCLAW_RUNTIME_DIR/repair-latest.log"
CONFIG_FILE="$(openclaw_config_file)"
LATEST_BACKUP="$(ls -1t "$OPENCLAW_RUNTIME_DIR"/backups/openclaw.json.*.bak 2>/dev/null | sed -n '1p' || true)"

ensure_dir "$OPENCLAW_RUNTIME_DIR"

{
  echo "[Repair] started at $(timestamp_utc)"
  echo "[Repair] config file: $CONFIG_FILE"

  if command -v npm >/dev/null 2>&1; then
    npm cache verify >/dev/null 2>&1 || npm cache clean --force >/dev/null 2>&1 || true
    echo "[Repair] npm cache refreshed"
  fi

  if command -v openclaw >/dev/null 2>&1; then
    if [ -f "$CONFIG_FILE" ] && ! openclaw config validate >/dev/null 2>&1; then
      if [ -n "$LATEST_BACKUP" ] && [ -f "$LATEST_BACKUP" ]; then
        cp "$LATEST_BACKUP" "$CONFIG_FILE"
        echo "[Repair] restored latest config backup: $LATEST_BACKUP"
      else
        echo "[Repair] config invalid but no backup found"
      fi
    fi

    openclaw gateway stop >/dev/null 2>&1 || true
    openclaw doctor --non-interactive >/dev/null 2>&1 || true
    echo "[Repair] OpenClaw doctor executed"
  fi

  rm -f "$OPENCLAW_INSTALLED_MARKER_FILE"
  echo "[Repair] cleared installed marker"
  echo "[Repair] finished at $(timestamp_utc)"
} | tee "$REPAIR_LOG"
