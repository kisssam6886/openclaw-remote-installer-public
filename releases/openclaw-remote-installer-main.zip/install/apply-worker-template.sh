#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

TARGET_DIR="$OPENCLAW_RUNTIME_DIR"
ensure_dir "$TARGET_DIR"
ensure_dir "$TARGET_DIR/backups"

echo "[Installer] applying worker template..."

SRC="$REPO_ROOT/templates/worker-agent-template.yaml"
DST="$TARGET_DIR/worker-agent.yaml"
CONFIG_FILE="$(openclaw_config_file)"
CONFIG_DIR="$(dirname "$CONFIG_FILE")"
BACKUP_FILE=""
MODEL_SOURCE="installer"
GATEWAY_SERVICE_INSTALLED=false
PROVIDER_CONFIGURED=false

test -f "$SRC" || { echo "worker template missing"; exit 1; }
cp "$SRC" "$DST"
ensure_dir "$CONFIG_DIR"

if ! command -v openclaw >/dev/null 2>&1; then
  echo "OpenClaw CLI missing. Cannot apply runtime config."
  exit 1
fi

if [ -f "$CONFIG_FILE" ]; then
  BACKUP_FILE="$TARGET_DIR/backups/openclaw.json.$(date -u +%Y%m%dT%H%M%SZ).bak"
  cp "$CONFIG_FILE" "$BACKUP_FILE"
fi

openclaw config set gateway.mode local >/dev/null
openclaw config set browser '{ enabled: true, evaluateEnabled: true, defaultProfile: "openclaw" }' >/dev/null
openclaw config set skills.install '{ preferBrew: true, nodeManager: "npm" }' >/dev/null
openclaw config set agents.defaults.userTimezone "$(json_string "$(system_timezone)")" >/dev/null
openclaw config set agents.defaults.workspace "$(json_string "$OPENCLAW_RUNTIME_DIR/workspace")" >/dev/null
ensure_dir "$OPENCLAW_RUNTIME_DIR/workspace"

if [ "$OPENCLAW_REQUIRE_PROVIDER_CONFIG" = "true" ]; then
  if [ -z "$OPENCLAW_PROVIDER_ID" ] || [ -z "$OPENCLAW_PROVIDER_BASE_URL" ] || [ -z "$OPENCLAW_PROVIDER_API_KEY" ] || [ -z "$OPENCLAW_PROVIDER_MODEL_ID" ]; then
    echo "Custom provider config missing. Copy .env.example to .env.local and fill OPENCLAW_PROVIDER_BASE_URL / OPENCLAW_PROVIDER_API_KEY first."
    exit 1
  fi

  openclaw config set "env.$OPENCLAW_PROVIDER_API_KEY_NAME" "$(json_string "$OPENCLAW_PROVIDER_API_KEY")" >/dev/null
  PROVIDER_JSON="$(cat <<EOF
{"baseUrl":$(json_string "$OPENCLAW_PROVIDER_BASE_URL"),"apiKey":"\${$OPENCLAW_PROVIDER_API_KEY_NAME}","api":$(json_string "$OPENCLAW_PROVIDER_API_COMPAT"),"models":[{"id":$(json_string "$OPENCLAW_PROVIDER_MODEL_ID"),"name":$(json_string "$OPENCLAW_PROVIDER_DISPLAY_NAME")}]}
EOF
)"
  openclaw config set --strict-json "models.providers.$OPENCLAW_PROVIDER_ID" "$PROVIDER_JSON" >/dev/null
  openclaw config set models.mode merge >/dev/null || true
  PROVIDER_CONFIGURED=true
fi

openclaw config set --strict-json agents.defaults.model "{\"primary\":$(json_string "$OPENCLAW_WORKER_MODEL")}" >/dev/null

if ! openclaw config validate >/dev/null 2>&1; then
  if [ -n "$BACKUP_FILE" ]; then
    cp "$BACKUP_FILE" "$CONFIG_FILE"
  else
    rm -f "$CONFIG_FILE"
  fi

  echo "Applied OpenClaw config failed validation and was rolled back."
  exit 1
fi

if [ "$(uname -s)" = "Darwin" ] && [ "$OPENCLAW_INSTALL_DAEMON" = "true" ]; then
  if openclaw gateway install --json >/dev/null 2>&1 || openclaw gateway install >/dev/null 2>&1; then
    if openclaw gateway start --json >/dev/null 2>&1 || openclaw gateway start >/dev/null 2>&1; then
      GATEWAY_SERVICE_INSTALLED=true
    else
      echo "OpenClaw gateway start failed."
      exit 1
    fi
  else
    echo "OpenClaw gateway install failed."
    exit 1
  fi
fi

if [ -n "$BACKUP_FILE" ]; then
  BACKUP_JSON="$(json_string "$BACKUP_FILE")"
else
  BACKUP_JSON="null"
fi

cat >"$TARGET_DIR/applied-worker-config.json" <<EOF
{
  "applied_at": $(json_string "$(timestamp_utc)"),
  "config_file": $(json_string "$CONFIG_FILE"),
  "template_file": $(json_string "$DST"),
  "worker_model": $(json_string "$OPENCLAW_WORKER_MODEL"),
  "worker_model_source": $(json_string "$MODEL_SOURCE"),
  "provider_id": $(json_string "$OPENCLAW_PROVIDER_ID"),
  "provider_model_id": $(json_string "$OPENCLAW_PROVIDER_MODEL_ID"),
  "provider_base_url": $(json_string "$OPENCLAW_PROVIDER_BASE_URL"),
  "provider_configured": $PROVIDER_CONFIGURED,
  "browser_enabled": true,
  "gateway_service_installed": $GATEWAY_SERVICE_INSTALLED,
  "skills_dir": $(json_string "$OPENCLAW_SHARED_SKILLS_DIR"),
  "installer_env_file": $(json_string "$OPENCLAW_INSTALLER_ENV_FILE"),
  "backup_file": $BACKUP_JSON
}
EOF

echo "Worker template written to: $DST"
echo "OpenClaw config applied to: $CONFIG_FILE"
