$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$repairLog = Join-Path $env:OPENCLAW_RUNTIME_DIR 'repair-latest.log'
$configFile = Get-OpenClawConfigFile
$latestBackup = Get-ChildItem -Path (Join-Path $env:OPENCLAW_RUNTIME_DIR 'backups') -Filter 'openclaw.json.*.bak' -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1

Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR

$lines = [System.Collections.Generic.List[string]]::new()
$lines.Add("[Repair] started at $(Get-TimestampUtc)")
$lines.Add("[Repair] config file: $configFile")

if (Get-Command npm -ErrorAction SilentlyContinue) {
    try { & npm cache verify | Out-Null } catch { try { & npm cache clean --force | Out-Null } catch { } }
    $lines.Add('[Repair] npm cache refreshed')
}

if (Get-Command openclaw -ErrorAction SilentlyContinue) {
    $configValid = $true
    if (Test-Path $configFile) {
        try { & openclaw config validate | Out-Null } catch { $configValid = $false }
    }

    if (-not $configValid) {
        if ($latestBackup) {
            Copy-Item -Path $latestBackup.FullName -Destination $configFile -Force
            $lines.Add("[Repair] restored latest config backup: $($latestBackup.FullName)")
        }
        else {
            $lines.Add('[Repair] config invalid but no backup found')
        }
    }

    try { & openclaw gateway stop | Out-Null } catch { }
    try { & openclaw doctor --non-interactive | Out-Null } catch { }
    $lines.Add('[Repair] OpenClaw doctor executed')
}

if (Test-Path $env:OPENCLAW_INSTALLED_MARKER_FILE) {
    Remove-Item -Path $env:OPENCLAW_INSTALLED_MARKER_FILE -Force
}
$lines.Add('[Repair] cleared installed marker')
$lines.Add("[Repair] finished at $(Get-TimestampUtc)")

Set-Content -Path $repairLog -Value $lines -Encoding utf8
$lines | ForEach-Object { Write-Host $_ }
