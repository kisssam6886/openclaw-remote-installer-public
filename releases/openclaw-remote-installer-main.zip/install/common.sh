#!/usr/bin/env bash
set -euo pipefail

COMMON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$COMMON_DIR/.." && pwd)"
OPENCLAW_STATE_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
OPENCLAW_RUNTIME_DIR="${OPENCLAW_RUNTIME_DIR:-$OPENCLAW_STATE_DIR/installer-runtime}"
OPENCLAW_SHARED_SKILLS_DIR="${OPENCLAW_SHARED_SKILLS_DIR:-$OPENCLAW_STATE_DIR/skills}"
OPENCLAW_REGISTRY_DIR="${OPENCLAW_REGISTRY_DIR:-$OPENCLAW_RUNTIME_DIR/registry/instances}"
OPENCLAW_QQ_STATUS_FILE="${OPENCLAW_QQ_STATUS_FILE:-$OPENCLAW_RUNTIME_DIR/status/qq-status.json}"
OPENCLAW_WORKER_MODEL="${OPENCLAW_WORKER_MODEL:-nvidia/moonshotai/kimi-k2.5}"
OPENCLAW_CHANNEL="${OPENCLAW_CHANNEL:-pending}"
OPENCLAW_INSTALL_DAEMON="${OPENCLAW_INSTALL_DAEMON:-true}"
OPENCLAW_INSTALL_SUMMARY_FILE="${OPENCLAW_INSTALL_SUMMARY_FILE:-$OPENCLAW_RUNTIME_DIR/install-summary.json}"
OPENCLAW_INSTALLED_MARKER_FILE="${OPENCLAW_INSTALLED_MARKER_FILE:-$OPENCLAW_RUNTIME_DIR/installed.ok}"
OPENCLAW_REGISTRY_GIT_URL="${OPENCLAW_REGISTRY_GIT_URL:-}"
OPENCLAW_REGISTRY_GIT_BRANCH="${OPENCLAW_REGISTRY_GIT_BRANCH:-main}"
OPENCLAW_REGISTRY_GIT_DIR="${OPENCLAW_REGISTRY_GIT_DIR:-$OPENCLAW_RUNTIME_DIR/registry-sync}"
OPENCLAW_REGISTRY_GIT_SUBDIR="${OPENCLAW_REGISTRY_GIT_SUBDIR:-registry/instances}"
OPENCLAW_REGISTRY_SYNC_REQUIRED="${OPENCLAW_REGISTRY_SYNC_REQUIRED:-false}"
OPENCLAW_REGISTRY_GIT_AUTHOR_NAME="${OPENCLAW_REGISTRY_GIT_AUTHOR_NAME:-OpenClaw Installer}"
OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL="${OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL:-openclaw-installer@local.invalid}"
OPENCLAW_INSTALLER_ENV_FILE="${OPENCLAW_INSTALLER_ENV_FILE:-}"
OPENCLAW_INSTALL_MAX_ATTEMPTS="${OPENCLAW_INSTALL_MAX_ATTEMPTS:-3}"
OPENCLAW_DIAGNOSTICS_DIR="${OPENCLAW_DIAGNOSTICS_DIR:-$OPENCLAW_RUNTIME_DIR/diagnostics}"
OPENCLAW_DIAGNOSTICS_GIT_URL="${OPENCLAW_DIAGNOSTICS_GIT_URL:-}"
OPENCLAW_DIAGNOSTICS_GIT_BRANCH="${OPENCLAW_DIAGNOSTICS_GIT_BRANCH:-main}"
OPENCLAW_DIAGNOSTICS_GIT_DIR="${OPENCLAW_DIAGNOSTICS_GIT_DIR:-$OPENCLAW_RUNTIME_DIR/diagnostics-sync}"
OPENCLAW_DIAGNOSTICS_GIT_SUBDIR="${OPENCLAW_DIAGNOSTICS_GIT_SUBDIR:-reports/install-failures}"
OPENCLAW_REPAIR_AUTO="${OPENCLAW_REPAIR_AUTO:-true}"
OPENCLAW_ENABLE_WORKER_AGENT="${OPENCLAW_ENABLE_WORKER_AGENT:-true}"
OPENCLAW_WORKER_AGENT_REQUIRED="${OPENCLAW_WORKER_AGENT_REQUIRED:-false}"
OPENCLAW_WORKER_AGENT_ID="${OPENCLAW_WORKER_AGENT_ID:-worker}"
OPENCLAW_WORKER_AGENT_WORKSPACE="${OPENCLAW_WORKER_AGENT_WORKSPACE:-$OPENCLAW_STATE_DIR/workspace-worker}"
REQUIRED_SKILLS=(agent-browser himalaya self-improvement task-status)

load_installer_env() {
  local candidate

  for candidate in \
    "$OPENCLAW_INSTALLER_ENV_FILE" \
    "$REPO_ROOT/.env.local" \
    "$REPO_ROOT/.installer.env" \
    "$HOME/.openclaw-installer.env"
  do
    [ -n "$candidate" ] || continue

    if [ -f "$candidate" ]; then
      set -a
      . "$candidate"
      set +a
      OPENCLAW_INSTALLER_ENV_FILE="$candidate"
      return 0
    fi
  done

  return 1
}

refresh_installer_context() {
  OPENCLAW_STATE_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
  OPENCLAW_RUNTIME_DIR="${OPENCLAW_RUNTIME_DIR:-$OPENCLAW_STATE_DIR/installer-runtime}"
  OPENCLAW_SHARED_SKILLS_DIR="${OPENCLAW_SHARED_SKILLS_DIR:-$OPENCLAW_STATE_DIR/skills}"
  OPENCLAW_REGISTRY_DIR="${OPENCLAW_REGISTRY_DIR:-$OPENCLAW_RUNTIME_DIR/registry/instances}"
  OPENCLAW_QQ_STATUS_FILE="${OPENCLAW_QQ_STATUS_FILE:-$OPENCLAW_RUNTIME_DIR/status/qq-status.json}"
  OPENCLAW_WORKER_MODEL="${OPENCLAW_WORKER_MODEL:-nvidia/moonshotai/kimi-k2.5}"
  OPENCLAW_CHANNEL="${OPENCLAW_CHANNEL:-pending}"
  OPENCLAW_INSTALL_DAEMON="${OPENCLAW_INSTALL_DAEMON:-true}"
  OPENCLAW_INSTALL_SUMMARY_FILE="${OPENCLAW_INSTALL_SUMMARY_FILE:-$OPENCLAW_RUNTIME_DIR/install-summary.json}"
  OPENCLAW_INSTALLED_MARKER_FILE="${OPENCLAW_INSTALLED_MARKER_FILE:-$OPENCLAW_RUNTIME_DIR/installed.ok}"
  OPENCLAW_REGISTRY_GIT_URL="${OPENCLAW_REGISTRY_GIT_URL:-}"
  OPENCLAW_REGISTRY_GIT_BRANCH="${OPENCLAW_REGISTRY_GIT_BRANCH:-main}"
  OPENCLAW_REGISTRY_GIT_DIR="${OPENCLAW_REGISTRY_GIT_DIR:-$OPENCLAW_RUNTIME_DIR/registry-sync}"
  OPENCLAW_REGISTRY_GIT_SUBDIR="${OPENCLAW_REGISTRY_GIT_SUBDIR:-registry/instances}"
  OPENCLAW_REGISTRY_SYNC_REQUIRED="${OPENCLAW_REGISTRY_SYNC_REQUIRED:-false}"
  OPENCLAW_REGISTRY_GIT_AUTHOR_NAME="${OPENCLAW_REGISTRY_GIT_AUTHOR_NAME:-OpenClaw Installer}"
  OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL="${OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL:-openclaw-installer@local.invalid}"
  OPENCLAW_INSTALL_MAX_ATTEMPTS="${OPENCLAW_INSTALL_MAX_ATTEMPTS:-3}"
  OPENCLAW_DIAGNOSTICS_DIR="${OPENCLAW_DIAGNOSTICS_DIR:-$OPENCLAW_RUNTIME_DIR/diagnostics}"
  OPENCLAW_DIAGNOSTICS_GIT_URL="${OPENCLAW_DIAGNOSTICS_GIT_URL:-}"
  OPENCLAW_DIAGNOSTICS_GIT_BRANCH="${OPENCLAW_DIAGNOSTICS_GIT_BRANCH:-main}"
  OPENCLAW_DIAGNOSTICS_GIT_DIR="${OPENCLAW_DIAGNOSTICS_GIT_DIR:-$OPENCLAW_RUNTIME_DIR/diagnostics-sync}"
  OPENCLAW_DIAGNOSTICS_GIT_SUBDIR="${OPENCLAW_DIAGNOSTICS_GIT_SUBDIR:-reports/install-failures}"
  OPENCLAW_REPAIR_AUTO="${OPENCLAW_REPAIR_AUTO:-true}"
  OPENCLAW_ENABLE_WORKER_AGENT="${OPENCLAW_ENABLE_WORKER_AGENT:-true}"
  OPENCLAW_WORKER_AGENT_REQUIRED="${OPENCLAW_WORKER_AGENT_REQUIRED:-false}"
  OPENCLAW_WORKER_AGENT_ID="${OPENCLAW_WORKER_AGENT_ID:-worker}"
  OPENCLAW_WORKER_AGENT_WORKSPACE="${OPENCLAW_WORKER_AGENT_WORKSPACE:-$OPENCLAW_STATE_DIR/workspace-worker}"
  OPENCLAW_PROVIDER_ID="${OPENCLAW_PROVIDER_ID:-nvidia}"
  OPENCLAW_PROVIDER_MODEL_ID="${OPENCLAW_PROVIDER_MODEL_ID:-${OPENCLAW_WORKER_MODEL#*/}}"
  OPENCLAW_PROVIDER_BASE_URL="${OPENCLAW_PROVIDER_BASE_URL:-https://integrate.api.nvidia.com/v1}"
  OPENCLAW_PROVIDER_API_KEY="${OPENCLAW_PROVIDER_API_KEY:-}"
  OPENCLAW_PROVIDER_API_COMPAT="${OPENCLAW_PROVIDER_API_COMPAT:-openai-completions}"
  OPENCLAW_PROVIDER_DISPLAY_NAME="${OPENCLAW_PROVIDER_DISPLAY_NAME:-Kimi K2.5 (NVIDIA)}"
  OPENCLAW_REQUIRE_PROVIDER_CONFIG="${OPENCLAW_REQUIRE_PROVIDER_CONFIG:-true}"

  if [ "$OPENCLAW_PROVIDER_ID" = "$OPENCLAW_WORKER_MODEL" ]; then
    OPENCLAW_PROVIDER_ID="nvidia"
  fi

  if [ "$OPENCLAW_PROVIDER_MODEL_ID" = "$OPENCLAW_WORKER_MODEL" ]; then
    OPENCLAW_PROVIDER_MODEL_ID="${OPENCLAW_WORKER_MODEL#*/}"
  fi

  if [ -z "${OPENCLAW_PROVIDER_API_KEY_NAME:-}" ]; then
    if [ "$OPENCLAW_PROVIDER_ID" = "nvidia" ]; then
      OPENCLAW_PROVIDER_API_KEY_NAME="NVIDIA_API_KEY"
    else
      OPENCLAW_PROVIDER_API_KEY_NAME="$(printf '%s' "$OPENCLAW_PROVIDER_ID" | tr '[:lower:]-.' '[:upper:]__')_API_KEY"
    fi
  fi
}

timestamp_utc() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

ensure_dir() {
  mkdir -p "$1"
}

sanitize_id() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9._-]+/-/g; s/^-+//; s/-+$//; s/-+/-/g'
}

machine_name() {
  if [ "$(uname -s)" = "Darwin" ] && command -v scutil >/dev/null 2>&1; then
    scutil --get ComputerName 2>/dev/null || hostname
    return
  fi

  hostname
}

machine_id() {
  local raw=""

  if [ "$(uname -s)" = "Darwin" ]; then
    raw="$(ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null | awk -F'"' '/IOPlatformUUID/{print $4; exit}')"
  fi

  if [ -z "$raw" ] && [ -f /etc/machine-id ]; then
    raw="$(tr -d '\n' </etc/machine-id)"
  fi

  if [ -z "$raw" ]; then
    raw="$(machine_name)-$(date +%Y%m%d%H%M%S)"
  fi

  sanitize_id "$raw"
}

os_label() {
  if [ "$(uname -s)" = "Darwin" ] && command -v sw_vers >/dev/null 2>&1; then
    printf 'macOS %s' "$(sw_vers -productVersion 2>/dev/null || echo unknown)"
    return
  fi

  printf '%s' "$(uname -s)"
}

arch_label() {
  uname -m
}

system_timezone() {
  local zone=""

  zone="$(readlink /etc/localtime 2>/dev/null || true)"
  if [ -n "$zone" ] && printf '%s' "$zone" | grep -q '/zoneinfo/'; then
    printf '%s\n' "${zone##*/zoneinfo/}"
    return
  fi

  if [ -f /etc/timezone ]; then
    sed -n '1p' /etc/timezone
    return
  fi

  printf '%s\n' "${TZ:-UTC}"
}

openclaw_version() {
  if command -v openclaw >/dev/null 2>&1; then
    openclaw --version 2>/dev/null | sed -n '1p'
    return
  fi

  printf 'unknown\n'
}

expand_path() {
  local raw_path="$1"

  case "$raw_path" in
    ~)
      printf '%s\n' "$HOME"
      ;;
    ~/*)
      printf '%s/%s\n' "$HOME" "${raw_path#~/}"
      ;;
    *)
      printf '%s\n' "$raw_path"
      ;;
  esac
}

trim_whitespace() {
  local value="$1"

  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s\n' "$value"
}

strip_surrounding_quotes() {
  local value="$1"

  if [ "${value#\"}" != "$value" ] && [ "${value%\"}" != "$value" ] && [ "${#value}" -ge 2 ]; then
    value="${value#\"}"
    value="${value%\"}"
  elif [ "${value#\'}" != "$value" ] && [ "${value%\'}" != "$value" ] && [ "${#value}" -ge 2 ]; then
    value="${value#\'}"
    value="${value%\'}"
  fi

  printf '%s\n' "$value"
}

strip_ansi_sequences() {
  local value="$1"
  local esc

  esc="$(printf '\033')"
  printf '%s' "$value" | sed -E "s/${esc}\\[[0-9;?]*[ -/]*[@-~]//g" | tr -d '[:cntrl:]'
}

sanitize_cli_path() {
  local value="$1"

  value="$(strip_ansi_sequences "$value")"
  value="$(trim_whitespace "$value")"
  value="$(strip_surrounding_quotes "$value")"
  value="$(trim_whitespace "$value")"
  printf '%s\n' "$value"
}

extract_openclaw_config_path() {
  local raw_output="$1"

  printf '%s\n' "$raw_output" | LC_ALL=C grep -Eo '(/[^[:space:]]*openclaw\.json|~/[^[:space:]]*openclaw\.json)' | sed -n '1p'
}

openclaw_config_file() {
  local config_file=""
  local fallback_file=""
  local cli_output=""

  fallback_file="$(expand_path "${OPENCLAW_CONFIG_FILE:-$OPENCLAW_STATE_DIR/openclaw.json}")"

  if [ -n "${OPENCLAW_CONFIG_FILE:-}" ]; then
    printf '%s\n' "$fallback_file"
    return
  fi

  if command -v openclaw >/dev/null 2>&1; then
    cli_output="$(openclaw config file 2>&1 || true)"
    config_file="$(extract_openclaw_config_path "$cli_output")"
    config_file="$(sanitize_cli_path "$config_file")"
  fi

  if [ -z "$config_file" ]; then
    config_file="$fallback_file"
  else
    config_file="$(expand_path "$config_file")"
  fi

  if [ ! -f "$config_file" ] && [ -f "$fallback_file" ]; then
    config_file="$fallback_file"
  fi

  printf '%s\n' "$config_file"
}

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

json_string() {
  printf '"%s"' "$(json_escape "$1")"
}

redact_secret() {
  local value="$1"

  if [ -z "$value" ]; then
    printf ''
    return
  fi

  printf '%s' "$value" | sed -E 's/./*/g'
}

write_redacted_copy() {
  local source_path="$1"
  local target_path="$2"

  [ -f "$source_path" ] || return 0

  sed \
    -e "s#${OPENCLAW_PROVIDER_API_KEY:-__NO_KEY__}#[REDACTED_API_KEY]#g" \
    -e 's#"NVIDIA_API_KEY"[[:space:]]*:[[:space:]]*"[^"]*"#"NVIDIA_API_KEY":"[REDACTED_API_KEY]"#g' \
    "$source_path" >"$target_path"
}

yaml_quote() {
  printf "'%s'" "$(printf '%s' "$1" | sed "s/'/''/g")"
}

skill_path() {
  local skill="$1"
  local candidate

  for candidate in \
    "$OPENCLAW_SHARED_SKILLS_DIR/$skill/SKILL.md" \
    "$HOME/clawd/skills/$skill/SKILL.md" \
    "/opt/homebrew/lib/node_modules/openclaw/skills/$skill/SKILL.md" \
    "/usr/local/lib/node_modules/openclaw/skills/$skill/SKILL.md"
  do
    if [ -f "$candidate" ]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done

  return 1
}

skill_installed() {
  skill_path "$1" >/dev/null 2>&1
}

qq_status_connected() {
  [ -f "$OPENCLAW_QQ_STATUS_FILE" ] && grep -Eq '"connected"[[:space:]]*:[[:space:]]*true' "$OPENCLAW_QQ_STATUS_FILE"
}

qq_status_label() {
  if qq_status_connected; then
    printf 'connected\n'
    return
  fi

  printf 'pending\n'
}

write_qq_status() {
  local connected="$1"
  local note="${2:-}"
  local account_id="${3:-}"
  local status_dir

  status_dir="$(dirname "$OPENCLAW_QQ_STATUS_FILE")"
  ensure_dir "$status_dir"

  cat >"$OPENCLAW_QQ_STATUS_FILE" <<EOF
{
  "channel": "qq",
  "connected": $connected,
  "account_id": $(json_string "$account_id"),
  "machine_name": $(json_string "$(machine_name)"),
  "verified_by": $(json_string "${USER:-unknown}"),
  "verified_at": $(json_string "$(timestamp_utc)"),
  "note": $(json_string "$note")
}
EOF
}

load_installer_env >/dev/null 2>&1 || true
refresh_installer_context
