$ErrorActionPreference = 'Stop'

$script:RepoRoot = Split-Path -Parent $PSScriptRoot

function Import-InstallerEnv {
    $candidates = @()

    if ($env:OPENCLAW_INSTALLER_ENV_FILE) {
        $candidates += $env:OPENCLAW_INSTALLER_ENV_FILE
    }

    $candidates += (Join-Path $script:RepoRoot '.env.local')
    $candidates += (Join-Path $script:RepoRoot '.installer.env')
    $candidates += (Join-Path $HOME '.openclaw-installer.env')

    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate) -or -not (Test-Path $candidate)) {
            continue
        }

        foreach ($line in Get-Content -Path $candidate) {
            $trimmed = $line.Trim()
            if (-not $trimmed -or $trimmed.StartsWith('#') -or -not $trimmed.Contains('=')) {
                continue
            }

            $parts = $trimmed.Split('=', 2)
            $name = $parts[0].Trim()
            $value = $parts[1].Trim()

            if (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'"))) {
                $value = $value.Substring(1, $value.Length - 2)
            }

            Set-Item -Path "Env:$name" -Value $value
        }

        $env:OPENCLAW_INSTALLER_ENV_FILE = (Resolve-Path $candidate).Path
        return
    }
}

function Get-DefaultProviderId {
    if ($env:OPENCLAW_WORKER_MODEL -and $env:OPENCLAW_WORKER_MODEL.Contains('/')) {
        return $env:OPENCLAW_WORKER_MODEL.Split('/')[0]
    }

    return 'nvidia'
}

function Get-DefaultProviderModelId {
    if ($env:OPENCLAW_WORKER_MODEL -and $env:OPENCLAW_WORKER_MODEL.Contains('/')) {
        return $env:OPENCLAW_WORKER_MODEL.Split('/', 2)[1]
    }

    return $env:OPENCLAW_WORKER_MODEL
}

function Get-DefaultProviderApiKeyName {
    param([string]$ProviderId)

    if (-not $ProviderId) {
        $ProviderId = 'openclaw'
    }

    if ($ProviderId -eq 'nvidia') {
        return 'NVIDIA_API_KEY'
    }

    return ($ProviderId.ToUpper().Replace('-', '_').Replace('.', '_') + '_API_KEY')
}

function Refresh-InstallerContext {
    if (-not $env:OPENCLAW_STATE_DIR) { $env:OPENCLAW_STATE_DIR = Join-Path $HOME '.openclaw' }
    if (-not $env:OPENCLAW_RUNTIME_DIR) { $env:OPENCLAW_RUNTIME_DIR = Join-Path $env:OPENCLAW_STATE_DIR 'installer-runtime' }
    if (-not $env:OPENCLAW_SHARED_SKILLS_DIR) { $env:OPENCLAW_SHARED_SKILLS_DIR = Join-Path $env:OPENCLAW_STATE_DIR 'skills' }
    if (-not $env:OPENCLAW_NPM_GLOBAL_PREFIX) { $env:OPENCLAW_NPM_GLOBAL_PREFIX = Join-Path $env:OPENCLAW_STATE_DIR 'tooling/npm-global' }
    if (-not $env:OPENCLAW_REGISTRY_DIR) { $env:OPENCLAW_REGISTRY_DIR = Join-Path $env:OPENCLAW_RUNTIME_DIR 'registry/instances' }
    if (-not $env:OPENCLAW_QQ_STATUS_FILE) { $env:OPENCLAW_QQ_STATUS_FILE = Join-Path $env:OPENCLAW_RUNTIME_DIR 'status/qq-status.json' }
    if (-not $env:OPENCLAW_WORKER_MODEL) { $env:OPENCLAW_WORKER_MODEL = 'nvidia/moonshotai/kimi-k2.5' }
    if (-not $env:OPENCLAW_CHANNEL) { $env:OPENCLAW_CHANNEL = 'pending' }
    if (-not $env:OPENCLAW_INSTALL_DAEMON) { $env:OPENCLAW_INSTALL_DAEMON = 'true' }
    if (-not $env:OPENCLAW_INSTALL_SUMMARY_FILE) { $env:OPENCLAW_INSTALL_SUMMARY_FILE = Join-Path $env:OPENCLAW_RUNTIME_DIR 'install-summary.json' }
    if (-not $env:OPENCLAW_INSTALLED_MARKER_FILE) { $env:OPENCLAW_INSTALLED_MARKER_FILE = Join-Path $env:OPENCLAW_RUNTIME_DIR 'installed.ok' }
    if (-not $env:OPENCLAW_INSTALL_MAX_ATTEMPTS) { $env:OPENCLAW_INSTALL_MAX_ATTEMPTS = '3' }
    if (-not $env:OPENCLAW_DIAGNOSTICS_DIR) { $env:OPENCLAW_DIAGNOSTICS_DIR = Join-Path $env:OPENCLAW_RUNTIME_DIR 'diagnostics' }
    if (-not $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH) { $env:OPENCLAW_DIAGNOSTICS_GIT_BRANCH = 'main' }
    if (-not $env:OPENCLAW_DIAGNOSTICS_GIT_DIR) { $env:OPENCLAW_DIAGNOSTICS_GIT_DIR = Join-Path $env:OPENCLAW_RUNTIME_DIR 'diagnostics-sync' }
    if (-not $env:OPENCLAW_DIAGNOSTICS_GIT_SUBDIR) { $env:OPENCLAW_DIAGNOSTICS_GIT_SUBDIR = 'reports/install-failures' }
    if (-not $env:OPENCLAW_REPAIR_AUTO) { $env:OPENCLAW_REPAIR_AUTO = 'true' }
    if (-not $env:OPENCLAW_ENABLE_WORKER_AGENT) { $env:OPENCLAW_ENABLE_WORKER_AGENT = 'true' }
    if (-not $env:OPENCLAW_WORKER_AGENT_REQUIRED) { $env:OPENCLAW_WORKER_AGENT_REQUIRED = 'false' }
    if (-not $env:OPENCLAW_WORKER_AGENT_ID) { $env:OPENCLAW_WORKER_AGENT_ID = 'worker' }
    if (-not $env:OPENCLAW_WORKER_AGENT_WORKSPACE) { $env:OPENCLAW_WORKER_AGENT_WORKSPACE = Join-Path $env:OPENCLAW_STATE_DIR 'workspace-worker' }
    if (-not $env:OPENCLAW_REGISTRY_GIT_BRANCH) { $env:OPENCLAW_REGISTRY_GIT_BRANCH = 'main' }
    if (-not $env:OPENCLAW_REGISTRY_GIT_DIR) { $env:OPENCLAW_REGISTRY_GIT_DIR = Join-Path $env:OPENCLAW_RUNTIME_DIR 'registry-sync' }
    if (-not $env:OPENCLAW_REGISTRY_GIT_SUBDIR) { $env:OPENCLAW_REGISTRY_GIT_SUBDIR = 'registry/instances' }
    if (-not $env:OPENCLAW_REGISTRY_SYNC_REQUIRED) { $env:OPENCLAW_REGISTRY_SYNC_REQUIRED = 'false' }
    if (-not $env:OPENCLAW_REGISTRY_GIT_AUTHOR_NAME) { $env:OPENCLAW_REGISTRY_GIT_AUTHOR_NAME = 'OpenClaw Installer' }
    if (-not $env:OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL) { $env:OPENCLAW_REGISTRY_GIT_AUTHOR_EMAIL = 'openclaw-installer@local.invalid' }
    if (-not $env:OPENCLAW_INSTALL_SOURCE) { $env:OPENCLAW_INSTALL_SOURCE = 'repo-local' }
    if (-not $env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL) { $env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL = 'https://registry.npmmirror.com' }

    if (-not $env:OPENCLAW_PROVIDER_ID -or $env:OPENCLAW_PROVIDER_ID -eq $env:OPENCLAW_WORKER_MODEL) {
        $env:OPENCLAW_PROVIDER_ID = Get-DefaultProviderId
    }

    if (-not $env:OPENCLAW_PROVIDER_MODEL_ID -or $env:OPENCLAW_PROVIDER_MODEL_ID -eq $env:OPENCLAW_WORKER_MODEL) {
        $env:OPENCLAW_PROVIDER_MODEL_ID = Get-DefaultProviderModelId
    }

    if (-not $env:OPENCLAW_PROVIDER_BASE_URL) { $env:OPENCLAW_PROVIDER_BASE_URL = 'https://integrate.api.nvidia.com/v1' }
    if (-not $env:OPENCLAW_PROVIDER_API_COMPAT) { $env:OPENCLAW_PROVIDER_API_COMPAT = 'openai-completions' }
    if (-not $env:OPENCLAW_PROVIDER_DISPLAY_NAME) { $env:OPENCLAW_PROVIDER_DISPLAY_NAME = 'Kimi K2.5 (NVIDIA)' }
    if (-not $env:OPENCLAW_REQUIRE_PROVIDER_CONFIG) { $env:OPENCLAW_REQUIRE_PROVIDER_CONFIG = 'true' }
    if (-not $env:OPENCLAW_PROVIDER_API_KEY_NAME) { $env:OPENCLAW_PROVIDER_API_KEY_NAME = Get-DefaultProviderApiKeyName -ProviderId $env:OPENCLAW_PROVIDER_ID }
}

Import-InstallerEnv
Refresh-InstallerContext

$script:RequiredSkills = @('agent-browser', 'himalaya', 'self-improvement', 'task-status')

function Ensure-Directory {
    param([string]$Path)

    if (-not $Path) { return }
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Get-TimestampUtc {
    (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
}

function Get-MachineName {
    if ($env:COMPUTERNAME) { return $env:COMPUTERNAME }
    return [System.Net.Dns]::GetHostName()
}

function Get-MachineId {
    try {
        $guid = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
        if ($guid) { return $guid.ToLower() }
    }
    catch { }

    return (Get-MachineName).ToLower()
}

function Get-OSLabel {
    return "Windows $([System.Environment]::OSVersion.VersionString)"
}

function Get-ArchLabel {
    if ($env:PROCESSOR_ARCHITECTURE) { return $env:PROCESSOR_ARCHITECTURE }
    return 'unknown'
}

function Get-SystemTimezone {
    try {
        return (Get-TimeZone).Id
    }
    catch {
        if ($env:TZ) { return $env:TZ }
        return 'UTC'
    }
}

function Expand-InstallerPath {
    param([string]$Path)

    if (-not $Path) { return $Path }

    try {
        return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
    }
    catch {
        return $Path
    }
}

function Normalize-OpenClawCliPath {
    param([string]$Path)

    if (-not $Path) { return $Path }

    $value = $Path -replace "`e\[[0-9;?]*[ -/]*[@-~]", ''
    $value = $value.Trim()

    if (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'"))) {
        $value = $value.Substring(1, $value.Length - 2)
    }

    return $value.Trim()
}

function Get-OpenClawConfigPathFromOutput {
    param([string]$Output)

    if (-not $Output) { return $null }

    $match = [regex]::Match($Output, '([A-Za-z]:\\[^\r\n\s]*openclaw\.json|~[\\/][^\r\n\s]*openclaw\.json|/[^\r\n\s]*openclaw\.json)')
    if ($match.Success) {
        return $match.Groups[1].Value
    }

    return $null
}

function Get-InstallerOpenClawCommand {
    $candidates = @(
        $env:OPENCLAW_CMD,
        $(if ($env:OPENCLAW_NPM_GLOBAL_PREFIX) { Join-Path $env:OPENCLAW_NPM_GLOBAL_PREFIX 'openclaw.cmd' }),
        $(if ($env:OPENCLAW_NPM_GLOBAL_PREFIX) { Join-Path $env:OPENCLAW_NPM_GLOBAL_PREFIX 'openclaw.exe' }),
        $(if ($env:OPENCLAW_NPM_GLOBAL_PREFIX) { Join-Path $env:OPENCLAW_NPM_GLOBAL_PREFIX 'openclaw' }),
        $(if ($env:APPDATA) { Join-Path $env:APPDATA 'npm\openclaw.cmd' }),
        $(if ($env:APPDATA) { Join-Path $env:APPDATA 'npm\openclaw.exe' }),
        'openclaw.cmd',
        'openclaw.exe',
        'openclaw'
    )

    foreach ($candidate in $candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }

        if (Test-Path $candidate) {
            return (Resolve-Path $candidate).Path
        }

        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($command -and $command.Source) {
            return $command.Source
        }
    }

    return $null
}

function Convert-ToWindowsCommandLineArgument {
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) {
        return '""'
    }

    $text = [string]$Value
    if ($text.Length -eq 0) {
        return '""'
    }

    if ($text -notmatch '[\s"]') {
        return $text
    }

    $escaped = $text -replace '(\\*)"', '$1$1\\"'
    $escaped = $escaped -replace '(\\+)$', '$1$1'
    return '"' + $escaped + '"'
}

function Invoke-InstallerOpenClaw {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Arguments,
        [string]$ConfigPath
    )

    $command = Get-InstallerOpenClawCommand
    if (-not $command) {
        throw 'OpenClaw command not found.'
    }

    $stdoutFile = Join-Path $env:TEMP ('openclaw-stdout-{0}.log' -f ([guid]::NewGuid().ToString('N')))
    $stderrFile = Join-Path $env:TEMP ('openclaw-stderr-{0}.log' -f ([guid]::NewGuid().ToString('N')))
    $hadPreviousConfigPath = Test-Path Env:OPENCLAW_CONFIG_PATH
    $previousConfigPath = $env:OPENCLAW_CONFIG_PATH

    if ($ConfigPath) {
        $env:OPENCLAW_CONFIG_PATH = $ConfigPath
    }

    try {
        $argumentLine = (($Arguments | ForEach-Object { Convert-ToWindowsCommandLineArgument $_ }) -join ' ')
        $process = Start-Process -FilePath $command -ArgumentList $argumentLine -NoNewWindow -Wait -PassThru -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile
        $stdOut = if (Test-Path $stdoutFile) { Get-Content -Path $stdoutFile -Raw } else { '' }
        $stdErr = if (Test-Path $stderrFile) { Get-Content -Path $stderrFile -Raw } else { '' }
    }
    finally {
        if ($ConfigPath) {
            if ($hadPreviousConfigPath) {
                $env:OPENCLAW_CONFIG_PATH = $previousConfigPath
            }
            else {
                Remove-Item Env:OPENCLAW_CONFIG_PATH -ErrorAction SilentlyContinue
            }
        }
    }

    $output = @()
    if ($stdOut) {
        $output += ($stdOut -split "`r?`n" | Where-Object { $_ -ne '' })
    }
    if ($stdErr) {
        $output += ($stdErr -split "`r?`n" | Where-Object { $_ -ne '' })
    }

    Remove-Item -Path $stdoutFile, $stderrFile -Force -ErrorAction SilentlyContinue

    if ($process.ExitCode -ne 0) {
        $message = (($output | ForEach-Object { [string]$_ }) -join [Environment]::NewLine).Trim()
        if (-not $message) {
            $message = "OpenClaw command failed with exit code $($process.ExitCode)"
        }
        throw $message
    }

    return $output
}

function Start-InstallerOpenClawDetached {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Arguments,
        [string]$ConfigPath
    )

    $command = Get-InstallerOpenClawCommand
    if (-not $command) {
        throw 'OpenClaw command not found.'
    }

    $hadPreviousConfigPath = Test-Path Env:OPENCLAW_CONFIG_PATH
    $previousConfigPath = $env:OPENCLAW_CONFIG_PATH

    if ($ConfigPath) {
        $env:OPENCLAW_CONFIG_PATH = $ConfigPath
    }

    try {
        $argumentLine = (($Arguments | ForEach-Object { Convert-ToWindowsCommandLineArgument $_ }) -join ' ')
        return (Start-Process -FilePath $command -ArgumentList $argumentLine -PassThru)
    }
    finally {
        if ($ConfigPath) {
            if ($hadPreviousConfigPath) {
                $env:OPENCLAW_CONFIG_PATH = $previousConfigPath
            }
            else {
                Remove-Item Env:OPENCLAW_CONFIG_PATH -ErrorAction SilentlyContinue
            }
        }
    }
}

function Get-InstallerGatewayPort {
    if ($env:OPENCLAW_GATEWAY_PORT -match '^[0-9]+$') {
        return [int]$env:OPENCLAW_GATEWAY_PORT
    }

    return 18789
}

function Test-InstallerGatewayTcpReady {
    param(
        [string]$HostName = '127.0.0.1',
        [int]$Port = 18789,
        [int]$TimeoutMs = 1000
    )

    $client = $null
    try {
        $client = [System.Net.Sockets.TcpClient]::new()
        $asyncResult = $client.BeginConnect($HostName, $Port, $null, $null)
        if (-not $asyncResult.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            return $false
        }

        $client.EndConnect($asyncResult)
        return $client.Connected
    }
    catch {
        return $false
    }
    finally {
        if ($client) {
            $client.Dispose()
        }
    }
}

function Test-InstallerGatewayReady {
    param([string]$ConfigPath)

    $gatewayPort = Get-InstallerGatewayPort
    if (Test-InstallerGatewayTcpReady -HostName '127.0.0.1' -Port $gatewayPort) {
        return $true
    }

    if (Test-InstallerGatewayTcpReady -HostName '::1' -Port $gatewayPort) {
        return $true
    }

    try {
        Invoke-InstallerOpenClaw -ConfigPath $ConfigPath -Arguments @('status') | Out-Null
        return $true
    }
    catch {
        try {
            Invoke-InstallerOpenClaw -ConfigPath $ConfigPath -Arguments @('gateway', 'status') | Out-Null
            return $true
        }
        catch {
            return $false
        }
    }
}

function Wait-InstallerGatewayReady {
    param(
        [string]$ConfigPath,
        [int]$TimeoutSeconds = 45,
        [int]$PollIntervalSeconds = 2
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        if (Test-InstallerGatewayReady -ConfigPath $ConfigPath) {
            return $true
        }

        Start-Sleep -Seconds $PollIntervalSeconds
    }
    while ((Get-Date) -lt $deadline)

    return $false
}

function Invoke-InstallerBrowserStatus {
    param([string]$ConfigPath)

    try {
        return (Invoke-InstallerOpenClaw -ConfigPath $ConfigPath -Arguments @('browser', '--browser-profile', 'openclaw', 'status'))
    }
    catch {
        return (Invoke-InstallerOpenClaw -ConfigPath $ConfigPath -Arguments @('browser', 'status'))
    }
}

function Restart-InstallerGateway {
    param(
        [string]$ConfigPath,
        [int]$TimeoutSeconds = 45
    )

    try { Invoke-InstallerOpenClaw -ConfigPath $ConfigPath -Arguments @('gateway', 'stop') | Out-Null } catch { }
    Start-Sleep -Seconds 2

    $gatewayStartProcess = Start-InstallerOpenClawDetached -ConfigPath $ConfigPath -Arguments @('gateway', 'start')
    if (-not (Wait-InstallerGatewayReady -ConfigPath $ConfigPath -TimeoutSeconds $TimeoutSeconds)) {
        if ($gatewayStartProcess -and -not $gatewayStartProcess.HasExited) {
            Stop-Process -Id $gatewayStartProcess.Id -Force -ErrorAction SilentlyContinue
        }
        throw "OpenClaw gateway restart did not report ready within $TimeoutSeconds seconds."
    }
}

function Ensure-InstallerBrowserReady {
    param(
        [string]$ConfigPath,
        [int]$Attempts = 3,
        [int]$DelaySeconds = 4,
        [int]$GatewayRestartTimeoutSeconds = 45
    )

    if ($Attempts -lt 1) { $Attempts = 1 }
    if ($DelaySeconds -lt 0) { $DelaySeconds = 0 }

    $lastError = $null

    for ($attempt = 1; $attempt -le $Attempts; $attempt++) {
        try {
            Invoke-InstallerBrowserStatus -ConfigPath $ConfigPath | Out-Null
            return
        }
        catch {
            $lastError = $_

            if ($attempt -eq 1) {
                Write-Host '[Worker Agent] Browser capability check failed; restarting gateway and retrying...'
                Restart-InstallerGateway -ConfigPath $ConfigPath -TimeoutSeconds $GatewayRestartTimeoutSeconds
            }

            if ($attempt -lt $Attempts) {
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    if ($lastError) {
        throw $lastError
    }

    throw 'Browser capability command failed.'
}

function Get-OpenClawVersion {
    $openclawCommand = Get-InstallerOpenClawCommand
    if ($openclawCommand) {
        return ((Invoke-InstallerOpenClaw -Arguments @('--version')) | Select-Object -First 1)
    }

    return 'unknown'
}

function Get-OpenClawConfigFile {
    $fallbackConfigFile = Expand-InstallerPath $(if ($env:OPENCLAW_CONFIG_FILE) { $env:OPENCLAW_CONFIG_FILE } else { Join-Path $env:OPENCLAW_STATE_DIR 'openclaw.json' })

    if ($env:OPENCLAW_CONFIG_FILE) {
        return $fallbackConfigFile
    }

    if (Get-InstallerOpenClawCommand) {
        try {
            $configOutput = ((Invoke-InstallerOpenClaw -Arguments @('config', 'file')) | Out-String)
            $configFile = Normalize-OpenClawCliPath (Get-OpenClawConfigPathFromOutput $configOutput)
            if ($configFile) {
                $expandedConfigFile = Expand-InstallerPath $configFile
                if ((Test-Path $expandedConfigFile) -or -not (Test-Path $fallbackConfigFile)) {
                    return $expandedConfigFile
                }
            }
        }
        catch { }
    }

    return $fallbackConfigFile
}

function Get-SkillCandidates {
    param([string]$Skill)

    $candidates = @()

    if ($env:OPENCLAW_SHARED_SKILLS_DIR) {
        $candidates += (Join-Path $env:OPENCLAW_SHARED_SKILLS_DIR "$Skill/SKILL.md")
    }

    if ($HOME) {
        $candidates += (Join-Path $HOME ".openclaw/skills/$Skill/SKILL.md")
    }

    if ($env:APPDATA) {
        $candidates += (Join-Path $env:APPDATA "npm/node_modules/openclaw/skills/$Skill/SKILL.md")
    }

    if ($env:OPENCLAW_NPM_GLOBAL_PREFIX) {
        $candidates += (Join-Path $env:OPENCLAW_NPM_GLOBAL_PREFIX "node_modules/openclaw/skills/$Skill/SKILL.md")
    }

    if ($env:ProgramFiles) {
        $candidates += (Join-Path $env:ProgramFiles "nodejs/node_modules/openclaw/skills/$Skill/SKILL.md")
    }

    return $candidates
}

function Test-SkillInstalled {
    param([string]$Skill)

    foreach ($candidate in Get-SkillCandidates -Skill $Skill) {
        if (Test-Path $candidate) {
            return $true
        }
    }

    return $false
}

function Get-SkillPath {
    param([string]$Skill)

    foreach ($candidate in Get-SkillCandidates -Skill $Skill) {
        if (Test-Path $candidate) {
            return $candidate
        }
    }

    return $null
}

function ConvertTo-JsonLiteral {
    param([Parameter(ValueFromPipeline = $true)]$Value)

    process {
        return ($Value | ConvertTo-Json -Compress -Depth 20)
    }
}

function ConvertTo-YamlSingleQuoted {
    param([AllowNull()][string]$Value)

    if ($null -eq $Value) { $Value = '' }
    return "'" + $Value.Replace("'", "''") + "'"
}

function Write-JsonFile {
    param(
        [string]$Path,
        $Object
    )

    Ensure-Directory -Path (Split-Path -Parent $Path)
    $Object | ConvertTo-Json -Depth 20 | Set-Content -Path $Path -Encoding utf8
}

function Write-RedactedCopy {
    param(
        [string]$SourcePath,
        [string]$TargetPath
    )

    if (-not (Test-Path $SourcePath)) {
        return
    }

    $content = Get-Content -Path $SourcePath -Raw
    if ($env:OPENCLAW_PROVIDER_API_KEY) {
        $content = $content.Replace($env:OPENCLAW_PROVIDER_API_KEY, '[REDACTED_API_KEY]')
    }

    $apiKeyName = if ($env:OPENCLAW_PROVIDER_API_KEY_NAME) { [Regex]::Escape($env:OPENCLAW_PROVIDER_API_KEY_NAME) } else { 'NVIDIA_API_KEY' }
    $content = [Regex]::Replace($content, '"' + $apiKeyName + '"\s*:\s*"[^"]*"', '"' + $env:OPENCLAW_PROVIDER_API_KEY_NAME + '":"[REDACTED_API_KEY]"')

    Ensure-Directory -Path (Split-Path -Parent $TargetPath)
    Set-Content -Path $TargetPath -Value $content -Encoding utf8
}
