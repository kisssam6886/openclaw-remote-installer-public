#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

echo "[Installer] installing required skills..."

if ! command -v npm >/dev/null 2>&1; then
  echo "npm not found. Please install Node.js first."
  exit 1
fi

ensure_dir "$OPENCLAW_SHARED_SKILLS_DIR"

if ! command -v clawhub >/dev/null 2>&1; then
  npm install -g clawhub >/dev/null 2>&1 || true
fi

for skill in "${REQUIRED_SKILLS[@]}"; do
  if skill_installed "$skill"; then
    echo "Skill already available: $skill -> $(skill_path "$skill")"
    continue
  fi

  echo "Installing skill: $skill"

  if command -v clawhub >/dev/null 2>&1; then
    clawhub install "$skill" --workdir "$OPENCLAW_STATE_DIR" --force --no-input >/dev/null 2>&1 || true
  else
    npx -y clawhub install "$skill" --workdir "$OPENCLAW_STATE_DIR" --force --no-input >/dev/null 2>&1 || true
  fi

  if ! skill_installed "$skill"; then
    npx -y skills add "$skill" >/dev/null 2>&1 || true
  fi

  if ! skill_installed "$skill"; then
    echo "Missing skill after install: $skill"
    exit 1
  fi

  echo "Skill ready: $skill -> $(skill_path "$skill")"
done

echo "[Installer] required skills install step complete."
