param(
    [string]$ConfigPath
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

if ($env:OS -ne 'Windows_NT') {
    return
}

function Get-WindowsGatewayTaskName {
    if ($env:OPENCLAW_WINDOWS_TASK_NAME) {
        return $env:OPENCLAW_WINDOWS_TASK_NAME.Trim()
    }

    $profile = if ($env:OPENCLAW_PROFILE) { $env:OPENCLAW_PROFILE.Trim() } else { '' }
    if (-not $profile -or $profile.ToLowerInvariant() -eq 'default') {
        return 'OpenClaw Gateway'
    }

    return "OpenClaw Gateway ($profile)"
}

function Get-WindowsGatewayStateDir {
    if ($env:OPENCLAW_STATE_DIR) {
        return (Expand-InstallerPath $env:OPENCLAW_STATE_DIR)
    }

    return (Join-Path $HOME '.openclaw')
}

function Get-WindowsGatewayTaskScriptPath {
    if ($env:OPENCLAW_TASK_SCRIPT) {
        return (Expand-InstallerPath $env:OPENCLAW_TASK_SCRIPT)
    }

    $scriptName = if ($env:OPENCLAW_TASK_SCRIPT_NAME) { $env:OPENCLAW_TASK_SCRIPT_NAME.Trim() } else { 'gateway.cmd' }
    return (Join-Path (Get-WindowsGatewayStateDir) $scriptName)
}

function Get-WindowsStartupFolder {
    if ($env:APPDATA) {
        return (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup')
    }

    return (Join-Path $HOME 'AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup')
}

function Convert-ToWindowsSafeFileName {
    param([string]$Value)

    return ($Value -replace '[<>:"/\\|?*]', '_')
}

function Remove-WindowsGatewayScheduledTask {
    param([string]$TaskName)

    $schtasks = Get-Command 'schtasks.exe' -ErrorAction SilentlyContinue
    if (-not $schtasks) {
        return
    }

    & $schtasks.Source /Query /TN $TaskName | Out-Null
    if ($LASTEXITCODE -ne 0) {
        return
    }

    & $schtasks.Source /Delete /F /TN $TaskName | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to delete Scheduled Task: $TaskName"
    }
}

if ($env:OPENCLAW_WINDOWS_BACKGROUND_GATEWAY -ne 'true') {
    Write-Host '[Installer] Windows background gateway conversion disabled.'
    return
}

$gatewayScriptPath = Get-WindowsGatewayTaskScriptPath
if (-not (Test-Path $gatewayScriptPath)) {
    throw "Gateway task script missing: $gatewayScriptPath"
}

$stateDir = Get-WindowsGatewayStateDir
$taskName = Get-WindowsGatewayTaskName
$startupDir = Get-WindowsStartupFolder
$startupEntryPath = Join-Path $startupDir ((Convert-ToWindowsSafeFileName $taskName) + '.cmd')
$hiddenLauncherPath = Join-Path $stateDir 'gateway-hidden.vbs'
$escapedGatewayScriptPath = $gatewayScriptPath.Replace('"', '""')
$gatewayTimeoutSeconds = 45
$cmdPath = (Get-Command 'cmd.exe' -ErrorAction SilentlyContinue).Source

if (-not $cmdPath) {
    $cmdPath = 'cmd.exe'
}

if ($env:OPENCLAW_GATEWAY_START_TIMEOUT_SECONDS -match '^[0-9]+$') {
    $gatewayTimeoutSeconds = [int]$env:OPENCLAW_GATEWAY_START_TIMEOUT_SECONDS
}

Ensure-Directory -Path $stateDir
Ensure-Directory -Path $startupDir

@"
Set shell = CreateObject("WScript.Shell")
shell.Run Chr(34) & "$escapedGatewayScriptPath" & Chr(34), 0, False
"@ | Set-Content -Path $hiddenLauncherPath -Encoding ascii

@"
@echo off
wscript.exe //B //NoLogo "$hiddenLauncherPath"
"@ | Set-Content -Path $startupEntryPath -Encoding ascii

try {
    Invoke-InstallerOpenClaw -ConfigPath $ConfigPath -Arguments @('gateway', 'stop') | Out-Null
}
catch { }

Remove-WindowsGatewayScheduledTask -TaskName $taskName

Start-Sleep -Seconds 2
Start-Process -FilePath $cmdPath -ArgumentList "/d /s /c `"$startupEntryPath`"" -WindowStyle Hidden | Out-Null

if (-not (Wait-InstallerGatewayReady -ConfigPath $ConfigPath -TimeoutSeconds $gatewayTimeoutSeconds)) {
    throw "Windows background gateway did not report ready within $gatewayTimeoutSeconds seconds."
}

Write-Host "[Installer] Windows background gateway enabled via login item: $startupEntryPath"
