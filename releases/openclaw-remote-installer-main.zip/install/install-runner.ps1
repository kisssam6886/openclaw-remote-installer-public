$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$logDir = Join-Path $env:OPENCLAW_RUNTIME_DIR 'logs'
$maxAttempts = 3
$lastDiagnosticsDir = $null

if ($env:OPENCLAW_INSTALL_MAX_ATTEMPTS -match '^[0-9]+$') {
    $maxAttempts = [int]$env:OPENCLAW_INSTALL_MAX_ATTEMPTS
}

Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR
Ensure-Directory -Path $logDir

for ($attempt = 1; $attempt -le $maxAttempts; $attempt++) {
    $logFile = Join-Path $logDir ("install-attempt-{0}.log" -f $attempt)
    $env:OPENCLAW_INSTALL_ATTEMPT = "$attempt"

    Write-Host "[Runner] Install attempt $attempt/$maxAttempts"

    $success = $true
    try {
        & (Join-Path $PSScriptRoot 'install-openclaw.ps1') *>&1 | Tee-Object -FilePath $logFile
    }
    catch {
        $success = $false
        ($_ | Out-String).TrimEnd() | Add-Content -Path $logFile -Encoding utf8
    }

    if ($success) {
        Write-Host "[Runner] Install attempt $attempt succeeded."
        exit 0
    }

    $env:OPENCLAW_LAST_INSTALL_LOG_FILE = $logFile
    $env:OPENCLAW_INSTALL_EXIT_CODE = '1'
    $env:OPENCLAW_INSTALL_FAILURE_STAGE = 'install-openclaw'

    Write-Host "[Runner] Install attempt $attempt failed."
    try {
        $lastDiagnosticsDir = & (Join-Path $PSScriptRoot 'collect-diagnostics.ps1') -Attempt $attempt -ExitCode 1 -Stage 'install-openclaw' -LogFile $logFile | Select-Object -Last 1
        if ($lastDiagnosticsDir) {
            Write-Host "[Runner] Diagnostics collected: $lastDiagnosticsDir"
        }
    }
    catch {
        Write-Host '[Runner] Diagnostics collection failed.'
    }

    if ($attempt -ge $maxAttempts) {
        break
    }

    if ($env:OPENCLAW_REPAIR_AUTO -ne 'true') {
        break
    }

    Write-Host '[Runner] Running auto-repair before retry...'
    try { & (Join-Path $PSScriptRoot 'repair-openclaw.ps1') } catch { }
}

if ($lastDiagnosticsDir) {
    throw "OpenClaw install failed after $maxAttempts attempt(s). Latest diagnostics: $lastDiagnosticsDir"
}

throw "OpenClaw install failed after $maxAttempts attempt(s)."
