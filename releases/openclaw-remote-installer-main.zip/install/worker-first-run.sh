#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
. "$SCRIPT_DIR/common.sh"

REPO_REGISTRY_DIR="$REPO_ROOT/registry/instances"
RUNTIME_INSTANCE_DIR="$OPENCLAW_REGISTRY_DIR"
INSTANCE_ID="$(machine_id)"
INSTANCE_FILE_NAME="$INSTANCE_ID.yaml"
RUNTIME_INSTANCE_FILE="$RUNTIME_INSTANCE_DIR/$INSTANCE_FILE_NAME"
REPO_INSTANCE_FILE="$REPO_REGISTRY_DIR/$INSTANCE_FILE_NAME"
CONFIG_FILE="$(openclaw_config_file)"
SUMMARY_FILE="$OPENCLAW_INSTALL_SUMMARY_FILE"
REGISTRY_SYNC_STATUS="skipped"

channel_status() {
  if [ "$OPENCLAW_CHANNEL" = "qq" ] && qq_status_connected; then
    printf 'connected\n'
    return
  fi

  if [ "$OPENCLAW_CHANNEL" = "pending" ] || [ -z "$OPENCLAW_CHANNEL" ]; then
    printf 'not-configured\n'
    return
  fi

  printf 'pending\n'
}

write_install_summary() {
  local summary_status="$1"
  local channel_state="$2"
  local registry_sync_state="$3"
  local now

  now="$(timestamp_utc)"
  ensure_dir "$(dirname "$SUMMARY_FILE")"

  cat >"$SUMMARY_FILE" <<EOF
{
  "status": $(json_string "$summary_status"),
  "completed_at": $(json_string "$now"),
  "machine_id": $(json_string "$INSTANCE_ID"),
  "machine_name": $(json_string "$(machine_name)"),
  "os": $(json_string "$(os_label)"),
  "arch": $(json_string "$(arch_label)"),
  "openclaw_version": $(json_string "$(openclaw_version)"),
  "worker_model": $(json_string "$OPENCLAW_WORKER_MODEL"),
  "provider_id": $(json_string "$OPENCLAW_PROVIDER_ID"),
  "provider_model_id": $(json_string "$OPENCLAW_PROVIDER_MODEL_ID"),
  "install_source": $(json_string "${OPENCLAW_INSTALL_SOURCE:-repo-local}"),
  "installer_env_file": $(json_string "$OPENCLAW_INSTALLER_ENV_FILE"),
  "channel": $(json_string "$OPENCLAW_CHANNEL"),
  "channel_status": $(json_string "$channel_state"),
  "registry_sync_status": $(json_string "$registry_sync_state"),
  "config_file": $(json_string "$CONFIG_FILE"),
  "runtime_registry_file": $(json_string "$RUNTIME_INSTANCE_FILE"),
  "repo_registry_file": $(json_string "$REPO_INSTANCE_FILE")
}
EOF
}

write_registry_instance() {
  local destination="$1"
  local current_channel_status="$2"
  local issue_line=""
  local now
  local installed_at

  now="$(timestamp_utc)"
  installed_at="$now"
  ensure_dir "$(dirname "$destination")"

  if [ -f "$destination" ]; then
    installed_at="$(sed -n "s/^installed_at: '\(.*\)'$/\1/p" "$destination" | sed -n '1p')"
  fi

  if [ -z "$installed_at" ]; then
    installed_at="$now"
  fi

  if [ "$current_channel_status" = "pending" ]; then
    issue_line="  - 'Channel setup pending'"
  fi

  {
    printf 'customer_id: %s\n' "$(yaml_quote "$INSTANCE_ID")"
    printf 'name: %s\n' "$(yaml_quote "${OPENCLAW_CUSTOMER_NAME:-}")"
    printf 'contact: %s\n' "$(yaml_quote "${OPENCLAW_CUSTOMER_CONTACT:-}")"
    printf 'remote_tool: %s\n' "$(yaml_quote "${OPENCLAW_REMOTE_TOOL:-}")"
    printf 'remote_id: %s\n' "$(yaml_quote "${OPENCLAW_REMOTE_ID:-}")"
    printf 'install_source: %s\n' "$(yaml_quote "${OPENCLAW_INSTALL_SOURCE:-repo-local}")"
    printf 'os: %s\n' "$(yaml_quote "$(os_label)")"
    printf 'arch: %s\n' "$(yaml_quote "$(arch_label)")"
    printf 'machine_name: %s\n' "$(yaml_quote "$(machine_name)")"
    printf 'openclaw_version: %s\n' "$(yaml_quote "$(openclaw_version)")"
    printf 'edition: %s\n' "$(yaml_quote "operations")"
    printf 'channel: %s\n' "$(yaml_quote "$OPENCLAW_CHANNEL")"
    printf 'channel_status: %s\n' "$(yaml_quote "$current_channel_status")"
    printf 'worker_model: %s\n' "$(yaml_quote "$OPENCLAW_WORKER_MODEL")"
    printf 'provider_id: %s\n' "$(yaml_quote "$OPENCLAW_PROVIDER_ID")"
    printf 'provider_model_id: %s\n' "$(yaml_quote "$OPENCLAW_PROVIDER_MODEL_ID")"
    printf 'config_file: %s\n' "$(yaml_quote "$CONFIG_FILE")"
    printf 'registry_generated_at: %s\n' "$(yaml_quote "$now")"
    printf 'installed_at: %s\n' "$(yaml_quote "$installed_at")"
    printf 'last_maintained_at: %s\n' "$(yaml_quote "$now")"
    printf 'installed_skills:\n'
    for skill in "${REQUIRED_SKILLS[@]}"; do
      printf '  - %s\n' "$(yaml_quote "$skill")"
    done
    printf 'notes:\n'
    printf '  - %s\n' "$(yaml_quote "Worker first-run generated this record.")"
    printf '  - %s\n' "$(yaml_quote "Channel status: $OPENCLAW_CHANNEL / $current_channel_status")"
    if [ -n "$issue_line" ]; then
      printf 'known_issues:\n'
      printf '%s\n' "$issue_line"
    else
      printf 'known_issues: []\n'
    fi
    printf 'maintenance_log:\n'
    printf '  - %s\n' "$(yaml_quote "$now worker-first-run self-check completed with channel_status=$current_channel_status")"
  } >"$destination"
}

echo "[Worker Agent] first run starting..."

echo "[1/7] Verify OpenClaw command"
command -v openclaw >/dev/null 2>&1 || { echo "OpenClaw not found"; exit 1; }

echo "[2/8] Verify browser capability command"
BROWSER_CHECK_ATTEMPTS="${OPENCLAW_BROWSER_READY_ATTEMPTS:-3}"
BROWSER_CHECK_DELAY_SECONDS="${OPENCLAW_BROWSER_READY_DELAY_SECONDS:-4}"
GATEWAY_RESTART_TIMEOUT_SECONDS="${OPENCLAW_GATEWAY_START_TIMEOUT_SECONDS:-45}"
ensure_browser_ready "$BROWSER_CHECK_ATTEMPTS" "$BROWSER_CHECK_DELAY_SECONDS" "$GATEWAY_RESTART_TIMEOUT_SECONDS" || {
  echo "Browser capability check failed"
  exit 1
}

echo "[3/8] Verify required skills installation"
for skill in "${REQUIRED_SKILLS[@]}"; do
  if ! skill_installed "$skill"; then
    echo "Missing skill: $skill"
    exit 1
  fi
done

echo "[4/8] Verify runtime config application"
test -f "$OPENCLAW_RUNTIME_DIR/applied-worker-config.json" || {
  echo "Applied worker config marker missing"
  exit 1
}

if [ "$OPENCLAW_REQUIRE_PROVIDER_CONFIG" = "true" ] && ! grep -Eq '"provider_configured"[[:space:]]*:[[:space:]]*true' "$OPENCLAW_RUNTIME_DIR/applied-worker-config.json"; then
  echo "Worker provider config missing"
  exit 1
fi

test -f "$CONFIG_FILE" || {
  echo "OpenClaw config file missing: $CONFIG_FILE"
  exit 1
}

openclaw config validate >/dev/null 2>&1 || {
  echo "OpenClaw config validate failed"
  exit 1
}

openclaw doctor --non-interactive >/dev/null 2>&1 || {
  echo "OpenClaw doctor check failed"
  exit 1
}

echo "[5/8] Verify gateway status"
openclaw status >/dev/null 2>&1 || openclaw gateway status >/dev/null 2>&1 || {
  echo "OpenClaw gateway status check failed"
  exit 1
}

echo "[6/8] Verify documentation and registry template exist"
test -f "$REPO_ROOT/docs/qq-onboarding.md" || {
  echo "QQ onboarding doc missing"
  exit 1
}

test -f "$REPO_ROOT/registry/customer-template.yaml" || {
  echo "Customer registry template missing"
  exit 1
}

CURRENT_CHANNEL_STATUS="$(channel_status)"

echo "[7/8] Generate customer registry instance"
write_registry_instance "$RUNTIME_INSTANCE_FILE" "$CURRENT_CHANNEL_STATUS"
write_registry_instance "$REPO_INSTANCE_FILE" "$CURRENT_CHANNEL_STATUS"

if [ -n "$OPENCLAW_REGISTRY_GIT_URL" ]; then
  if bash "$REPO_ROOT/install/sync-customer-registry.sh" "$RUNTIME_INSTANCE_FILE"; then
    REGISTRY_SYNC_STATUS="synced"
  else
    REGISTRY_SYNC_STATUS="failed"
    if [ "$OPENCLAW_REGISTRY_SYNC_REQUIRED" = "true" ]; then
      echo "Customer registry sync is required but failed."
      exit 1
    fi
  fi
fi

echo "[8/8] Write install completion summary"
write_install_summary "ready" "$CURRENT_CHANNEL_STATUS" "$REGISTRY_SYNC_STATUS"
touch "$OPENCLAW_INSTALLED_MARKER_FILE"

echo "[Worker Agent] first run complete."
