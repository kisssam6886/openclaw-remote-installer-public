$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

Write-Host '[Installer] installing required skills...'

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    throw 'npm not found. Please install Node.js first.'
}

Ensure-Directory -Path $env:OPENCLAW_SHARED_SKILLS_DIR

foreach ($skill in $script:RequiredSkills) {
    if (Test-SkillInstalled -Skill $skill) {
        Write-Host "Skill already available: $skill -> $(Get-SkillPath -Skill $skill)"
        continue
    }

    Write-Host "Installing skill: $skill"

    if (Get-Command clawhub -ErrorAction SilentlyContinue) {
        & clawhub install $skill --workdir $env:OPENCLAW_STATE_DIR --force --no-input | Out-Null
    }
    else {
        & npx -y clawhub install $skill --workdir $env:OPENCLAW_STATE_DIR --force --no-input | Out-Null
    }

    if (-not (Test-SkillInstalled -Skill $skill)) {
        throw "Missing skill after install: $skill"
    }

    Write-Host "Skill ready: $skill -> $(Get-SkillPath -Skill $skill)"
}

Write-Host '[Installer] required skills install step complete.'
