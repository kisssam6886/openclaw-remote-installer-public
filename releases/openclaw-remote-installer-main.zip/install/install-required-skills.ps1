$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

$skillInstallMaxAttempts = if ($env:SKILL_INSTALL_MAX_ATTEMPTS) { [int]$env:SKILL_INSTALL_MAX_ATTEMPTS } else { 3 }
$skillInstallRetryDelay = if ($env:SKILL_INSTALL_RETRY_DELAY) { [int]$env:SKILL_INSTALL_RETRY_DELAY } else { 3 }

Write-Host '[Installer] installing required skills...'

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    throw 'npm not found. Please install Node.js first.'
}

Ensure-Directory -Path $env:OPENCLAW_SHARED_SKILLS_DIR

if (-not (Get-Command clawhub -ErrorAction SilentlyContinue)) {
    try { & npm install -g clawhub | Out-Null } catch { }
}

function Install-SkillOnce {
    param([string]$Skill)

    if (Get-Command clawhub -ErrorAction SilentlyContinue) {
        try { & clawhub install $Skill --workdir $env:OPENCLAW_STATE_DIR --force --no-input | Out-Null } catch { }
    }
    else {
        try { & npx -y clawhub install $Skill --workdir $env:OPENCLAW_STATE_DIR --force --no-input | Out-Null } catch { }
    }

    if (-not (Test-SkillInstalled -Skill $Skill)) {
        try { & npx -y skills add $Skill | Out-Null } catch { }
    }
}

foreach ($skill in $script:RequiredSkills) {
    if (Test-SkillInstalled -Skill $skill) {
        Write-Host "Skill already available: $skill -> $(Get-SkillPath -Skill $skill)"
        continue
    }

    Write-Host "Installing skill: $skill"

    for ($attempt = 1; $attempt -le $skillInstallMaxAttempts; $attempt++) {
        Install-SkillOnce -Skill $skill

        if (Test-SkillInstalled -Skill $skill) {
            break
        }

        if ($attempt -lt $skillInstallMaxAttempts) {
            Write-Host "Skill not ready yet: $skill (attempt $attempt/$skillInstallMaxAttempts), retrying in ${skillInstallRetryDelay}s..."
            Start-Sleep -Seconds $skillInstallRetryDelay
        }
    }

    if (-not (Test-SkillInstalled -Skill $skill)) {
        throw "Missing skill after install retries: $skill"
    }

    Write-Host "Skill ready: $skill -> $(Get-SkillPath -Skill $skill)"
}

Write-Host '[Installer] required skills install step complete.'
