$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

function Resolve-CommandPath {
    param([string[]]$Candidates)

    foreach ($candidate in $Candidates) {
        if ([string]::IsNullOrWhiteSpace($candidate)) { continue }

        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($command -and $command.Source) {
            return $command.Source
        }

        if (Test-Path $candidate) {
            return (Resolve-Path $candidate).Path
        }
    }

    return $null
}

function Ensure-PathEntry {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return }

    $parts = @()
    if ($env:Path) { $parts = $env:Path -split ';' }
    if ($parts | Where-Object { $_ -ieq $Path }) { return }

    $env:Path = if ($env:Path) { "$Path;$env:Path" } else { $Path }
}

function Ensure-UserPathEntry {
    param([string]$Path)

    if ([string]::IsNullOrWhiteSpace($Path)) { return }

    $userPath = [Environment]::GetEnvironmentVariable('Path', 'User')
    $parts = @()
    if ($userPath) { $parts = $userPath -split ';' }
    if ($parts | Where-Object { $_ -ieq $Path }) { return }

    $newUserPath = if ($userPath) { "$userPath;$Path" } else { $Path }
    [Environment]::SetEnvironmentVariable('Path', $newUserPath, 'User')
}

function Get-NpmCommandPath {
    $candidates = @(
        $env:OPENCLAW_NPM_CMD,
        $(if ($env:OPENCLAW_NODE_HOME) { Join-Path $env:OPENCLAW_NODE_HOME 'npm.cmd' }),
        $(if ($env:OPENCLAW_NODE_HOME) { Join-Path $env:OPENCLAW_NODE_HOME 'npm.exe' }),
        $(if ($env:ProgramFiles) { Join-Path $env:ProgramFiles 'nodejs\npm.cmd' }),
        $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} 'nodejs\npm.cmd' }),
        $(if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Programs\nodejs\npm.cmd' }),
        'npm.cmd',
        'npm.exe',
        'npm'
    )

    $path = Resolve-CommandPath -Candidates $candidates
    if (-not $path) {
        throw 'npm not found. Please install Node.js first.'
    }

    return $path
}

function Get-OpenClawCommandPath {
    $prefix = $env:OPENCLAW_NPM_GLOBAL_PREFIX
    $candidates = @(
        $(if ($env:OPENCLAW_CMD) { $env:OPENCLAW_CMD }),
        $(if ($prefix) { Join-Path $prefix 'openclaw.cmd' }),
        $(if ($prefix) { Join-Path $prefix 'openclaw.exe' }),
        $(if ($prefix) { Join-Path $prefix 'openclaw' }),
        'openclaw.cmd',
        'openclaw.exe',
        'openclaw'
    )

    return (Resolve-CommandPath -Candidates $candidates)
}

function Invoke-NpmWithInstallerEnv {
    param([string[]]$Arguments)

    $npmCommand = Get-NpmCommandPath
    Ensure-Directory -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX
    Ensure-PathEntry -Path $env:OPENCLAW_NPM_GLOBAL_PREFIX

    $previous = @{
        NPM_CONFIG_PREFIX = $env:NPM_CONFIG_PREFIX
        NPM_CONFIG_SCRIPT_SHELL = $env:NPM_CONFIG_SCRIPT_SHELL
        NPM_CONFIG_LOGLEVEL = $env:NPM_CONFIG_LOGLEVEL
        NPM_CONFIG_UPDATE_NOTIFIER = $env:NPM_CONFIG_UPDATE_NOTIFIER
        NPM_CONFIG_FUND = $env:NPM_CONFIG_FUND
        NPM_CONFIG_AUDIT = $env:NPM_CONFIG_AUDIT
        NODE_LLAMA_CPP_SKIP_DOWNLOAD = $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD
    }

    $env:NPM_CONFIG_PREFIX = $env:OPENCLAW_NPM_GLOBAL_PREFIX
    $env:NPM_CONFIG_SCRIPT_SHELL = 'cmd.exe'
    $env:NPM_CONFIG_LOGLEVEL = 'error'
    $env:NPM_CONFIG_UPDATE_NOTIFIER = 'false'
    $env:NPM_CONFIG_FUND = 'false'
    $env:NPM_CONFIG_AUDIT = 'false'
    $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD = '1'

    try {
        $output = & $npmCommand @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $env:NPM_CONFIG_PREFIX = $previous.NPM_CONFIG_PREFIX
        $env:NPM_CONFIG_SCRIPT_SHELL = $previous.NPM_CONFIG_SCRIPT_SHELL
        $env:NPM_CONFIG_LOGLEVEL = $previous.NPM_CONFIG_LOGLEVEL
        $env:NPM_CONFIG_UPDATE_NOTIFIER = $previous.NPM_CONFIG_UPDATE_NOTIFIER
        $env:NPM_CONFIG_FUND = $previous.NPM_CONFIG_FUND
        $env:NPM_CONFIG_AUDIT = $previous.NPM_CONFIG_AUDIT
        $env:NODE_LLAMA_CPP_SKIP_DOWNLOAD = $previous.NODE_LLAMA_CPP_SKIP_DOWNLOAD
    }

    foreach ($line in $output) {
        Write-Host $line
    }

    return $exitCode
}

Write-Host '[Installer] OpenClaw install starting...'

Write-Host '[1/6] Install or update OpenClaw CLI'
$packageSpec = if ($env:OPENCLAW_CLI_PACKAGE) { $env:OPENCLAW_CLI_PACKAGE } else { 'openclaw' }
$openclawCommand = Get-OpenClawCommandPath
$skipCliInstall = $false

if ($env:OPENCLAW_FORCE_CLI_INSTALL -ne 'true' -and $openclawCommand) {
    try {
        & $openclawCommand --version | Out-Null
        $skipCliInstall = $true
        Write-Host '[Installer] OpenClaw CLI already available; skipping reinstall.'
    }
    catch {
        $skipCliInstall = $false
    }
}

if (-not $skipCliInstall) {
    $installArgs = @('install', '-g', $packageSpec)
    $exitCode = Invoke-NpmWithInstallerEnv -Arguments $installArgs
    if ($exitCode -ne 0 -and $env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL) {
        Write-Host "[Installer] Default npm registry failed; retrying with mirror: $($env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL)"
        $installArgs = @('install', '-g', $packageSpec, '--registry', $env:OPENCLAW_NPM_REGISTRY_FALLBACK_URL)
        $exitCode = Invoke-NpmWithInstallerEnv -Arguments $installArgs
    }
    if ($exitCode -ne 0) {
        throw "OpenClaw CLI install failed with exit code $exitCode"
    }

    $openclawCommand = Get-OpenClawCommandPath
    if (-not $openclawCommand) {
        throw 'OpenClaw command not found after npm install.'
    }
}

$openclawBinDir = Split-Path -Parent $openclawCommand
Ensure-PathEntry -Path $openclawBinDir
Ensure-UserPathEntry -Path $openclawBinDir
$env:OPENCLAW_CMD = $openclawCommand

Write-Host '[2/6] Verify OpenClaw command'
& $openclawCommand --version

Write-Host '[3/6] Install required skills'
& (Join-Path $PSScriptRoot 'install-required-skills.ps1')

Write-Host '[4/6] Prepare installer runtime directories'
Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR
Ensure-Directory -Path $env:OPENCLAW_REGISTRY_DIR

Write-Host '[5/6] Continue to worker handoff'
& (Join-Path $PSScriptRoot 'handoff-to-worker.ps1')

Write-Host '[6/6] Run post-install actions'
try { & (Join-Path $PSScriptRoot 'post-install-actions.ps1') } catch { Write-Host '[Post Install] failed; continuing.' }

Write-Host '[Installer] OpenClaw install complete.'
