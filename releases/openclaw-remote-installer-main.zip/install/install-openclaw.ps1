$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'common.ps1')

Write-Host '[Installer] OpenClaw install starting...'

if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    throw 'npm not found. Please install Node.js first.'
}

Write-Host '[1/5] Install or update OpenClaw CLI'
& npm install -g openclaw | Out-Null

Write-Host '[2/5] Verify OpenClaw command'
& openclaw --version

Write-Host '[3/5] Install required skills'
& (Join-Path $PSScriptRoot 'install-required-skills.ps1')

Write-Host '[4/5] Prepare installer runtime directories'
Ensure-Directory -Path $env:OPENCLAW_RUNTIME_DIR
Ensure-Directory -Path $env:OPENCLAW_REGISTRY_DIR

Write-Host '[5/5] Continue to worker handoff'
& (Join-Path $PSScriptRoot 'handoff-to-worker.ps1')

Write-Host '[Installer] OpenClaw install complete.'
