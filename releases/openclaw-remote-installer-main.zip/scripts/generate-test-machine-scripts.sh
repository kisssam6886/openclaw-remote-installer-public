#!/usr/bin/env bash
set -euo pipefail

PUBLIC_REPO_URL_DEFAULT="https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main"
PUBLIC_REPO_URL="${OPENCLAW_PUBLIC_INSTALL_BASE_URL:-$PUBLIC_REPO_URL_DEFAULT}"
CACHE_BUSTER="${OPENCLAW_PUBLIC_INSTALL_CACHE_BUSTER:-$(date +%s)}"
OUTPUT_DIR_DEFAULT="$(cd "$(dirname "$0")/.." && pwd)/.generated/test-machine-scripts"
OUTPUT_DIR="${OPENCLAW_TEST_SCRIPT_OUTPUT_DIR:-$OUTPUT_DIR_DEFAULT}"
CUSTOMER_NAME=""
REMOTE_ID=""
PROVIDER_API_KEY=""
INCLUDE_PROVIDER_KEY="false"

usage() {
  cat <<'USAGE'
用法：
  bash scripts/generate-test-machine-scripts.sh [选项]

选项：
  --customer-name <名称>         测试机名称
  --remote-id <ID>              AnyDesk ID
  --provider-api-key <KEY>      NVIDIA key
  --include-provider-key        把 key 直接写进脚本
  --help                        显示帮助
USAGE
}

shell_quote() {
  printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\''/g")"
}

sanitize_file_part() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9._-]+/-/g; s/^-+//; s/-+$//; s/-+/-/g'
}

prompt_if_missing() {
  if [ -z "$CUSTOMER_NAME" ]; then
    printf '测试机名称: '
    IFS= read -r CUSTOMER_NAME
  fi

  if [ -z "$REMOTE_ID" ]; then
    printf 'AnyDesk ID: '
    IFS= read -r REMOTE_ID
  fi

  if [ "$INCLUDE_PROVIDER_KEY" = 'true' ] && [ -z "$PROVIDER_API_KEY" ]; then
    printf 'NVIDIA key: '
    IFS= read -r PROVIDER_API_KEY
  fi
}

while [ $# -gt 0 ]; do
  case "$1" in
    --customer-name)
      CUSTOMER_NAME="${2:-}"
      shift 2
      ;;
    --remote-id)
      REMOTE_ID="${2:-}"
      shift 2
      ;;
    --provider-api-key)
      PROVIDER_API_KEY="${2:-}"
      shift 2
      ;;
    --include-provider-key)
      INCLUDE_PROVIDER_KEY='true'
      shift
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "未知参数: $1"
      usage
      exit 1
      ;;
  esac
done

prompt_if_missing

[ -n "$CUSTOMER_NAME" ] || { echo '测试机名称不能为空'; exit 1; }
[ -n "$REMOTE_ID" ] || { echo 'AnyDesk ID 不能为空'; exit 1; }

CUSTOMER_NAME_QUOTED="$(shell_quote "$CUSTOMER_NAME")"
REMOTE_ID_QUOTED="$(shell_quote "$REMOTE_ID")"
PROVIDER_KEY_VALUE='替换成你的NVIDIA key'
if [ "$INCLUDE_PROVIDER_KEY" = 'true' ] && [ -n "$PROVIDER_API_KEY" ]; then
  PROVIDER_KEY_VALUE="$PROVIDER_API_KEY"
fi
PROVIDER_KEY_QUOTED="$(shell_quote "$PROVIDER_KEY_VALUE")"

FILE_STEM="$(sanitize_file_part "$CUSTOMER_NAME")-$(sanitize_file_part "$REMOTE_ID")"
TARGET_DIR="$OUTPUT_DIR/$FILE_STEM"
mkdir -p "$TARGET_DIR"

MAC_INSTALL_FILE="$TARGET_DIR/install-mac.command"
MAC_RECOVER_FILE="$TARGET_DIR/recover-mac.command"
WIN_INSTALL_FILE="$TARGET_DIR/install-win.ps1"
WIN_RECOVER_FILE="$TARGET_DIR/recover-win.ps1"
README_FILE="$TARGET_DIR/README.md"

cat > "$MAC_INSTALL_FILE" <<MAC
#!/usr/bin/env bash
set -euo pipefail
curl -fsSL '${PUBLIC_REPO_URL}/bootstrap/remote-install.sh?v=${CACHE_BUSTER}' | OPENCLAW_KEEP_INSTALLER_WORKDIR='true' OPENCLAW_CUSTOMER_NAME=${CUSTOMER_NAME_QUOTED} OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID=${REMOTE_ID_QUOTED} OPENCLAW_PROVIDER_BASE_URL='https://integrate.api.nvidia.com/v1' OPENCLAW_WORKER_MODEL='nvidia/moonshotai/kimi-k2.5' OPENCLAW_PROVIDER_API_KEY=${PROVIDER_KEY_QUOTED} bash
printf '\n[Next] openclaw gateway restart || openclaw gateway start\n'
printf '[Next] openclaw gateway probe\n'
printf '[Next] openclaw status\n'
printf '[Next] openclaw dashboard --no-open\n'
MAC
chmod +x "$MAC_INSTALL_FILE"

cat > "$MAC_RECOVER_FILE" <<'MAC'
#!/usr/bin/env bash
set -euo pipefail
openclaw gateway restart || openclaw gateway start
openclaw gateway probe || true
openclaw status
openclaw dashboard --no-open
MAC
chmod +x "$MAC_RECOVER_FILE"

cat > "$WIN_INSTALL_FILE" <<WIN
Set-ExecutionPolicy Bypass -Scope Process -Force
\$ErrorActionPreference = 'Stop'
\$installFailed = \$false
\$env:OPENCLAW_KEEP_INSTALLER_WORKDIR='true'
\$env:OPENCLAW_CUSTOMER_NAME=${CUSTOMER_NAME_QUOTED}
\$env:OPENCLAW_REMOTE_TOOL='anydesk'
\$env:OPENCLAW_REMOTE_ID=${REMOTE_ID_QUOTED}
\$env:OPENCLAW_PROVIDER_BASE_URL='https://integrate.api.nvidia.com/v1'
\$env:OPENCLAW_WORKER_MODEL='nvidia/moonshotai/kimi-k2.5'
\$env:OPENCLAW_PROVIDER_API_KEY=${PROVIDER_KEY_QUOTED}
try {
    Invoke-RestMethod '${PUBLIC_REPO_URL}/bootstrap/remote-install.ps1?v=${CACHE_BUSTER}' | Invoke-Expression
}
catch {
    \$installFailed = \$true
    Write-Warning (\$_.Exception.Message)
}
if (-not (Get-Command openclaw -ErrorAction SilentlyContinue)) {
    throw 'OpenClaw command not found after install.'
}
try { openclaw gateway restart | Out-Null } catch { try { openclaw gateway start | Out-Null } catch { } }
try { openclaw gateway probe } catch { }
openclaw status
openclaw dashboard --no-open
if (\$installFailed) {
    Write-Warning 'Installer reported failure, but OpenClaw is present. Review the status output above.'
}
WIN

cat > "$WIN_RECOVER_FILE" <<'WIN'
Set-ExecutionPolicy Bypass -Scope Process -Force
$ErrorActionPreference = 'Stop'
if (-not (Get-Command openclaw -ErrorAction SilentlyContinue)) {
    throw 'OpenClaw command not found. Install first.'
}
try { openclaw gateway restart | Out-Null } catch { openclaw gateway start | Out-Null }
try { openclaw gateway probe } catch { }
openclaw status
openclaw dashboard --no-open
WIN

cat > "$README_FILE" <<README
# 测试机脚本

- 测试机名称：$CUSTOMER_NAME
- AnyDesk ID：$REMOTE_ID
- 生成时间：$(date '+%Y-%m-%d %H:%M:%S')
- 输出目录：$TARGET_DIR

## 文件

- $MAC_INSTALL_FILE
- $MAC_RECOVER_FILE
- $WIN_INSTALL_FILE
- $WIN_RECOVER_FILE

## 说明

- 安装脚本默认带 \`OPENCLAW_KEEP_INSTALLER_WORKDIR='true'\`，方便你做恢复测试。
- 恢复脚本走的是轻恢复：
  - \`openclaw gateway restart\`
  - \`openclaw gateway probe\`
  - \`openclaw status\`
  - \`openclaw dashboard --no-open\`
- 如果你没把 key 写进脚本，先把占位符改掉再运行。
README

printf '已生成测试机脚本目录：%s\n' "$TARGET_DIR"
printf '  - %s\n' "$MAC_INSTALL_FILE"
printf '  - %s\n' "$MAC_RECOVER_FILE"
printf '  - %s\n' "$WIN_INSTALL_FILE"
printf '  - %s\n' "$WIN_RECOVER_FILE"
