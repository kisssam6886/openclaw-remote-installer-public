#!/usr/bin/env bash
set -euo pipefail

PUBLIC_REPO_URL_DEFAULT="https://raw.githubusercontent.com/kisssam6886/openclaw-remote-installer-public/main"
PUBLIC_REPO_URL="${OPENCLAW_PUBLIC_INSTALL_BASE_URL:-$PUBLIC_REPO_URL_DEFAULT}"
CACHE_BUSTER="${OPENCLAW_PUBLIC_INSTALL_CACHE_BUSTER:-$(date +%s)}"
OUTPUT_DIR_DEFAULT="$(cd "$(dirname "$0")/.." && pwd)/.generated/customer-delivery-commands"
OUTPUT_DIR="${OPENCLAW_COMMAND_OUTPUT_DIR:-$OUTPUT_DIR_DEFAULT}"
REMOTE_TOOL="anydesk"
CUSTOMER_NAME=""
REMOTE_ID=""
PROVIDER_API_KEY=""
INCLUDE_PROVIDER_KEY="false"
COPY_TO_CLIPBOARD="false"
PLATFORM="both"
INTERACTIVE_STDIN="false"

if [ -t 0 ]; then
  INTERACTIVE_STDIN="true"
fi

usage() {
  cat <<'USAGE'
用法：
  bash scripts/generate-customer-command.sh [选项]

选项：
  --customer-name <名称>         客户名称
  --remote-id <ID>              AnyDesk ID
  --provider-api-key <KEY>      NVIDIA key
  --include-provider-key        把 key 直接写进生成命令
  --platform <mac|windows|both> 生成指定平台命令，默认 both
  --copy                        生成后自动复制到剪贴板（macOS 优先）
  --help                        显示帮助

说明：
  1. 默认不会把 NVIDIA key 写进命令，避免泄露。
  2. AnyDesk 密码不要写进命令。
  3. 如未传参，会进入交互输入模式。
USAGE
}

shell_quote() {
  printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\''/g")"
}

sanitize_file_part() {
  printf '%s' "$1" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9._-]+/-/g; s/^-+//; s/-+$//; s/-+/-/g'
}

prompt_if_missing() {
  if [ -z "$CUSTOMER_NAME" ]; then
    printf '客户名称: '
    IFS= read -r CUSTOMER_NAME
  fi

  if [ -z "$REMOTE_ID" ]; then
    printf 'AnyDesk ID: '
    IFS= read -r REMOTE_ID
  fi

  if [ -z "$PLATFORM" ] || [ "$PLATFORM" = "both" ]; then
    :
  fi

  if [ "$INCLUDE_PROVIDER_KEY" != "true" ] && [ -z "$PROVIDER_API_KEY" ] && [ "$INTERACTIVE_STDIN" = "true" ]; then
    printf '是否把 NVIDIA key 直接写进命令？(y/N): '
    local answer
    IFS= read -r answer
    case "$answer" in
      y|Y|yes|YES)
        INCLUDE_PROVIDER_KEY="true"
        printf 'NVIDIA key: '
        IFS= read -r PROVIDER_API_KEY
        ;;
    esac
  elif [ "$INCLUDE_PROVIDER_KEY" = "true" ] && [ -z "$PROVIDER_API_KEY" ]; then
    printf 'NVIDIA key: '
    IFS= read -r PROVIDER_API_KEY
  fi
}

while [ $# -gt 0 ]; do
  case "$1" in
    --customer-name)
      CUSTOMER_NAME="${2:-}"
      shift 2
      ;;
    --remote-id)
      REMOTE_ID="${2:-}"
      shift 2
      ;;
    --provider-api-key)
      PROVIDER_API_KEY="${2:-}"
      shift 2
      ;;
    --include-provider-key)
      INCLUDE_PROVIDER_KEY="true"
      shift
      ;;
    --platform)
      PLATFORM="${2:-both}"
      shift 2
      ;;
    --copy)
      COPY_TO_CLIPBOARD="true"
      shift
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "未知参数: $1"
      usage
      exit 1
      ;;
  esac
done

prompt_if_missing

[ -n "$CUSTOMER_NAME" ] || { echo '客户名称不能为空'; exit 1; }
[ -n "$REMOTE_ID" ] || { echo 'AnyDesk ID 不能为空'; exit 1; }
case "$PLATFORM" in
  mac|windows|both) ;;
  *) echo 'platform 只能是 mac / windows / both'; exit 1 ;;
esac

CUSTOMER_NAME_QUOTED="$(shell_quote "$CUSTOMER_NAME")"
REMOTE_ID_QUOTED="$(shell_quote "$REMOTE_ID")"
MAC_BASE_CMD="curl -fsSL ${PUBLIC_REPO_URL}/bootstrap/remote-install.sh?v=${CACHE_BUSTER} | OPENCLAW_CUSTOMER_NAME=${CUSTOMER_NAME_QUOTED} OPENCLAW_REMOTE_TOOL='anydesk' OPENCLAW_REMOTE_ID=${REMOTE_ID_QUOTED}"
WIN_BASE_CMD_1="\$env:OPENCLAW_CUSTOMER_NAME=${CUSTOMER_NAME_QUOTED}"
WIN_BASE_CMD_2="\$env:OPENCLAW_REMOTE_TOOL='anydesk'"
WIN_BASE_CMD_3="\$env:OPENCLAW_REMOTE_ID=${REMOTE_ID_QUOTED}"
WIN_BASE_CMD_5="irm ${PUBLIC_REPO_URL}/bootstrap/remote-install.ps1?v=${CACHE_BUSTER} | iex"

if [ "$INCLUDE_PROVIDER_KEY" = "true" ] && [ -n "$PROVIDER_API_KEY" ]; then
  PROVIDER_KEY_QUOTED="$(shell_quote "$PROVIDER_API_KEY")"
  MAC_CMD="${MAC_BASE_CMD} OPENCLAW_PROVIDER_API_KEY=${PROVIDER_KEY_QUOTED} bash"
  WIN_BASE_CMD_4="\$env:OPENCLAW_PROVIDER_API_KEY=${PROVIDER_KEY_QUOTED}"
else
  MAC_CMD="${MAC_BASE_CMD} OPENCLAW_PROVIDER_API_KEY='替换成你的NVIDIA key' bash"
  WIN_BASE_CMD_4="\$env:OPENCLAW_PROVIDER_API_KEY='替换成你的NVIDIA key'"
fi

TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
FILE_STEM="$(sanitize_file_part "$CUSTOMER_NAME")-${REMOTE_TOOL}-$(sanitize_file_part "$REMOTE_ID")-${TIMESTAMP}"
OUTPUT_FILE="$OUTPUT_DIR/${FILE_STEM}.md"
mkdir -p "$OUTPUT_DIR"

{
  printf '# 客户交付命令\n\n'
  printf -- '- 客户名称：%s\n' "$CUSTOMER_NAME"
  printf -- '- 远程工具：%s\n' "$REMOTE_TOOL"
  printf -- '- AnyDesk ID：%s\n' "$REMOTE_ID"
  printf -- '- 生成时间：%s\n\n' "$(date '+%Y-%m-%d %H:%M:%S')"

  if [ "$PLATFORM" = "mac" ] || [ "$PLATFORM" = "both" ]; then
    printf '## Mac\n\n'
    printf '```bash\n%s\n```\n\n' "$MAC_CMD"
  fi

  if [ "$PLATFORM" = "windows" ] || [ "$PLATFORM" = "both" ]; then
    printf '## Windows\n\n'
    printf '```powershell\n%s\n%s\n%s\n%s\n%s\n```\n\n' "$WIN_BASE_CMD_1" "$WIN_BASE_CMD_2" "$WIN_BASE_CMD_3" "$WIN_BASE_CMD_4" "$WIN_BASE_CMD_5"
  fi

  printf '## 注意\n\n'
  printf -- '- AnyDesk 密码不要写进命令。\n'
  printf -- '- 这些命令是在客户机终端运行，不是在你本机运行。\n'
  printf -- '- 如果你以后换镜像域名，可改环境变量 OPENCLAW_PUBLIC_INSTALL_BASE_URL。\n'
  printf -- '- 当前命令默认带缓存绕过参数 v=%s。\n' "$CACHE_BUSTER"
} > "$OUTPUT_FILE"

printf '已生成：%s\n\n' "$OUTPUT_FILE"

if [ "$PLATFORM" = "mac" ] || [ "$PLATFORM" = "both" ]; then
  printf '===== Mac 命令 =====\n%s\n\n' "$MAC_CMD"
fi

if [ "$PLATFORM" = "windows" ] || [ "$PLATFORM" = "both" ]; then
  printf '===== Windows 命令 =====\n%s\n%s\n%s\n%s\n%s\n\n' "$WIN_BASE_CMD_1" "$WIN_BASE_CMD_2" "$WIN_BASE_CMD_3" "$WIN_BASE_CMD_4" "$WIN_BASE_CMD_5"
fi

if [ "$COPY_TO_CLIPBOARD" = "true" ]; then
  if command -v pbcopy >/dev/null 2>&1; then
    if [ "$PLATFORM" = "mac" ]; then
      printf '%s' "$MAC_CMD" | pbcopy
      printf '已复制 Mac 命令到剪贴板。\n'
    elif [ "$PLATFORM" = "windows" ]; then
      printf '%s\n%s\n%s\n%s\n%s' "$WIN_BASE_CMD_1" "$WIN_BASE_CMD_2" "$WIN_BASE_CMD_3" "$WIN_BASE_CMD_4" "$WIN_BASE_CMD_5" | pbcopy
      printf '已复制 Windows 命令到剪贴板。\n'
    else
      cat "$OUTPUT_FILE" | pbcopy
      printf '已复制完整命令文档到剪贴板。\n'
    fi
  else
    printf '当前环境没有 pbcopy，未自动复制。\n'
  fi
fi
